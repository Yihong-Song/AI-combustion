import os

import numpy as np
import pandas as pd
from scipy.interpolate import interpn
import cantera as ct
import h5py
import oyaml as yaml

import matplotlib.pyplot as plt
from matplotlib.colors import Normalize 
from matplotlib import cm
from matplotlib import animation

import seaborn as sns

import ai_reacting_flows.tools.utilities as utils

sns.set_style("darkgrid")

class StochDatabase(object):
    
    def __init__(self, stoch_dtb_folder, save_folder, with_traj=True):
        
        self.stoch_dtb_folder = stoch_dtb_folder

        # By default, no 
        self.add_0D_ignition_archetype = False
        self.add_1D_premixed_archetype = False

        # Loading database: concatenation of each data in h5 file
        h5file_r = h5py.File(self.stoch_dtb_folder + "/solutions.h5", 'r')
        names = h5file_r.keys()
        self.nb_solutions = len(names)
        h5file_r.close()
        self.get_all_states()

        if with_traj:
            # Loading trajectories
            traj_data = stoch_dtb_folder + "/mean_trajectories.h5"
            f = h5py.File(traj_data,"r")
            #
            traj_dataset = f['TRAJECTORIES']
            nb_inlets = 0 # number of inlets
            self.inlets_data_list = {}  # dictionary for storing data
            for inlet in traj_dataset.keys():
                i = int(inlet.split()[-1])   # Dataset names: "INLET <i>"
                self.inlets_data_list[i] = np.asarray(traj_dataset[inlet])
                nb_inlets += 1
            #
            # Getting number of states variable
            # Columns of trajectories: time, T, P, Yk, Z, phi, progress variable
            self.nb_state_vars = self.inlets_data_list[1].shape[1] - 4  # T, P and Yk (all except time, Z, phi and progress variable)
            # 
            f.close()

        # Additional post_processing
        self.compute_additional_postpros()

        # Saving folder
        if not os.path.isdir(save_folder):
            os.mkdir(save_folder)
        self.save_folder = save_folder


    #--------------------------------------------------------
    # READING H5 SOLUTION FILES
    #--------------------------------------------------------

    def get_all_states(self):

        # Reading file
        h5file_r = h5py.File(self.stoch_dtb_folder + "/solutions.h5", 'r')

        # Solution 0 read to get columns names
        col_names = h5file_r["ITERATION_00000/all_states"].attrs["cols"]

        # Loop on solutions
        list_df = []
        for i in range(self.nb_solutions):

            if i%100==0:
                print(f"Opening solution: {i} / {self.nb_solutions}")

            data = h5file_r.get(f"ITERATION_{i:05d}/all_states")[()]

            list_df.append(pd.DataFrame(data=data, columns=col_names))
        
        self.df = pd.concat(list_df, ignore_index=True)

        h5file_r.close()
        
    #--------------------------------------------------------
    # CANONICAL FLAMES CALCULATION
    #--------------------------------------------------------

    def compute_0D_ignition(self, phi, p, T0, fuel, mech_file):

        self.add_0D_ignition_archetype = True
        
        # Compute flame
        self.T_cano_0D, self.Y_cano_dict_0D = utils.compute_0D_reactor(fuel, mech_file, phi, T0, p)

    def compute_1D_premixed(self, phi, p, T0, fuel, mech_file, diffusion_model):

        self.add_1D_premixed_archetype = True

        # Compute flame
        self.T_cano_1D, self.Y_cano_dict_1D = utils.compute_adiabatic(fuel, mech_file, phi, T0, p, diffusion_model)

    #--------------------------------------------------------
    # ADDITIONAL CALCULATIONS
    #--------------------------------------------------------

    def compute_additional_postpros(self):

        self.df["abs_HRR"] = np.abs(self.df["HRR"])
        self.df["log_abs_HRR"] = np.log(self.df["abs_HRR"])

    #--------------------------------------------------------
    # SCATTER PLOTS: ALL STATES
    #--------------------------------------------------------

    def plot_T_Z(self):

        # Creating axis
        fig, ax = plt.subplots()

        self.df.plot.scatter(x='Mix_frac', y='Temperature', ax=ax, c='Time', colormap='viridis')
        ax.set_xlabel(r"$Z$ $[-]$")
        ax.set_ylabel(r"$T$ $[K]$")

        ax.set_xlim([0.9*self.df['Mix_frac'].min(), 1.1*self.df['Mix_frac'].max()])

        fig.tight_layout()

        # Save
        fig.savefig(self.save_folder + "/dtb_TZ_plot.png", dpi=300)

    def plot_Z_Yk(self, species_to_plot):

        for spec in species_to_plot:
            
            fig, ax = plt.subplots()
            
            self.df.plot.scatter(x='Mix_frac', y=spec, ax=ax, c='Time', colormap='viridis')
            ax.set_xlabel(r"$Z$ $[-]$")
            ax.set_ylabel(f"${spec}$ mass fraction $[-]$")
            
            ax.set_xlim([0.9*self.df['Mix_frac'].min(), 1.1*self.df['Mix_frac'].max()])
            
            fig.tight_layout()
            
            # Save
            fig.savefig(self.save_folder + f"/dtb_{spec}_Z_plot.png", dpi=300)

    def plot_T_Yk(self, species_to_plot):

        # Creating axis
        for spec in species_to_plot:
            
            fig, ax = plt.subplots()
            
            self.df.plot.scatter(x='Temperature', y=spec, ax=ax, c='Time', colormap='viridis')
            
            # Canonical flame structures
            if self.add_1D_premixed_archetype:
                ax.plot(self.T_cano_1D, self.Y_cano_dict_1D[spec], color='r', lw=3, ls='--', label="Laminar")
                
            if self.add_0D_ignition_archetype:
                ax.plot(self.T_cano_0D, self.Y_cano_dict_0D[spec], color='b', lw=3, ls='--', label="Ignition")
            
            ax.set_xlabel(r"$T$ $[K]$")
            ax.set_ylabel(f"${spec}$ mass fraction $[-]$")
            ax.legend()
            
            ax.set_xlim([0.9*self.df['Temperature'].min(), 1.1*self.df['Temperature'].max()])
            
            fig.tight_layout()
            
            plt.show()

            # Save
            fig.savefig(self.save_folder + f"/dtb_T_{spec}_plot.png", dpi=300)

    # Generic plotting function

    def plot_generic(self, var_x, var_y, var_c):

        # Creating axis
        fig, ax = plt.subplots()

        self.df.plot.scatter(x=var_x, y=var_y, ax=ax, c=var_c, colormap='viridis')
        ax.set_xlabel(var_x)
        ax.set_ylabel(var_y)

        ax.set_xlim([0.9*self.df[var_x].min(), 1.1*self.df[var_x].max()])

        fig.tight_layout()

        # Save
        fig.savefig(self.save_folder + f"/dtb_x{var_x}_y{var_y}_c{var_c}_plot.png", dpi=300)

    #--------------------------------------------------------
    # SCATTER PLOTS: ONE SOLUTION
    #--------------------------------------------------------

    def plot_T_Z_indiv(self, iteration):

        # Loading solution at given iteration
        h5file_r = h5py.File(self.stoch_dtb_folder + "/solutions.h5", 'r')
        data = h5file_r.get(f"ITERATION_{iteration:05d}/all_states")[()]
        col_names = h5file_r[f"ITERATION_{iteration:05d}/all_states"].attrs["cols"]
        h5file_r.close()
        df = pd.DataFrame(data=data, columns=col_names)

        # Creating axis
        fig, ax = plt.subplots()

        df.plot.scatter(x='Mix_frac', y='Temperature', ax=ax, c='Time', colormap='viridis')
        ax.set_xlabel(r"$Z$ $[-]$")
        ax.set_ylabel(r"$T$ $[K]$")

        ax.set_xlim([0.9*df['Mix_frac'].min(), 1.1*df['Mix_frac'].max()])

        fig.tight_layout()

        # Save
        fig.savefig(self.save_folder + f"/dtb_TZ_plot_iteration{iteration:05d}.png", dpi=300)

    def plot_Z_Yk_indiv(self, species_to_plot, iteration):

        # Loading solution at given iteration
        h5file_r = h5py.File(self.stoch_dtb_folder + "/solutions.h5", 'r')
        data = h5file_r.get(f"ITERATION_{iteration:05d}/all_states")[()]
        col_names = h5file_r[f"ITERATION_{iteration:05d}/all_states"].attrs["cols"]
        h5file_r.close()
        df = pd.DataFrame(data=data, columns=col_names)

        for spec in species_to_plot:
            
            fig, ax = plt.subplots()
            
            df.plot.scatter(x='Mix_frac', y=spec, ax=ax, c='Time', colormap='viridis')
            ax.set_xlabel(r"$Z$ $[-]$")
            ax.set_ylabel(f"${spec}$ mass fraction $[-]$")
            
            ax.set_xlim([0.9*df['Mix_frac'].min(), 1.1*df['Mix_frac'].max()])
            
            fig.tight_layout()
            
            # Save
            fig.savefig(self.save_folder + f"/dtb_{spec}_Z_plot_iteration{iteration:05d}.png", dpi=300)

    def plot_T_Yk_indiv(self, species_to_plot, iteration):

        # Loading solution at given iteration
        h5file_r = h5py.File(self.stoch_dtb_folder + "/solutions.h5", 'r')
        data = h5file_r.get(f"ITERATION_{iteration:05d}/all_states")[()]
        col_names = h5file_r[f"ITERATION_{iteration:05d}/all_states"].attrs["cols"]
        h5file_r.close()
        df = pd.DataFrame(data=data, columns=col_names)

        # Creating axis
        for spec in species_to_plot:
            
            fig, ax = plt.subplots()
            
            df.plot.scatter(x='Temperature', y=spec, ax=ax, c='Time', colormap='viridis')
            
            # Canonical flame structures
            if self.add_1D_premixed_archetype:
                ax.plot(self.T_cano, self.Y_cano_dict[spec], color='r', lw=3, ls='--', label="Laminar")
                
            if self.add_0D_ignition_archetype:
                ax.plot(self.T_cano_0D, self.Y_cano_dict_0D[spec], color='b', lw=3, ls='--', label="Ignition")
            
            ax.set_xlabel(r"$T$ $[K]$")
            ax.set_ylabel(f"${spec}$ mass fraction $[-]$")
            ax.legend()
            
            ax.set_xlim([0.9*df['Temperature'].min(), 1.1*df['Temperature'].max()])
            
            fig.tight_layout()
            
            plt.show()

            # Save
            fig.savefig(self.save_folder + f"/dtb_T_{spec}_plot_{iteration:05d}.png", dpi=300)

    # Generic plotting function

    def plot_generic_indiv(self, var_x, var_y, var_c, iteration):

        # Loading solution at given iteration
        h5file_r = h5py.File(self.stoch_dtb_folder + "/solutions.h5", 'r')
        data = h5file_r.get(f"ITERATION_{iteration:05d}/all_states")[()]
        col_names = h5file_r[f"ITERATION_{iteration:05d}/all_states"].attrs["cols"]
        h5file_r.close()
        df = pd.DataFrame(data=data, columns=col_names)

        # Creating axis
        fig, ax = plt.subplots()

        df.plot.scatter(x=var_x, y=var_y, ax=ax, c=var_c, colormap='viridis')
        ax.set_xlabel(var_x)
        ax.set_ylabel(var_y)

        ax.set_xlim([0.9*df[var_x].min(), 1.1*df[var_x].max()])

        fig.tight_layout()

        # Save
        fig.savefig(self.save_folder + f"/dtb_x{var_x}_y{var_y}_c{var_c}_plot_{iteration:05d}.png", dpi=300)

    #--------------------------------------------------------
    # ANIMATIONS
    #--------------------------------------------------------

    def plot_animation(self, var1, var2, var_color, iterations=None, step=100, interval=300, save_path=None, fps=5):
        """
        Animate the evolution of the T-Z scatter plot across iterations.

        Parameters
        ----------
        var1: str
            Variable to plot on x.
        var2: str
            Variable to plot on y.
        var_color: str
            Variable to use to color plot.
        iterations : list[int] or None
            Iterations to include. If None, all iterations found in the H5 file are used.
        step : int
            Keep only every `step`-th iteration (e.g. step=100 keeps iterations 0, 100, 200, ...).
            Ignored if `iterations` is explicitly provided.
        interval : int
            Delay between frames in milliseconds (for on-screen display).
        save_path : str or None
            If given, path to save the animation (.mp4 or .gif). If None, defaults to
            self.save_folder + "/dtb_TZ_animation.mp4".
        fps : int
            Frames per second when saving.
        """

        h5file_r = h5py.File(self.stoch_dtb_folder + "/solutions.h5", 'r')

        # Discover iterations if not provided
        if iterations is None:
            iter_keys = sorted(
                [k for k in h5file_r.keys() if k.startswith("ITERATION_")],
                key=lambda k: int(k.split("_")[1])
            )
            all_iterations = [int(k.split("_")[1]) for k in iter_keys]
            iterations = all_iterations[::step]

        # First pass: load all dataframes and compute global limits
        dfs = []
        var1_min, var1_max = np.inf, -np.inf
        var2_min, var2_max = np.inf, -np.inf
        var_color_min, var_color_max = np.inf, -np.inf

        for it in iterations:
            data = h5file_r.get(f"ITERATION_{it:05d}/all_states")[()]
            col_names = h5file_r[f"ITERATION_{it:05d}/all_states"].attrs["cols"]
            df = pd.DataFrame(data=data, columns=col_names)
            dfs.append(df)

            var1_min = min(var1_min, df[var1].min())
            var1_max = max(var1_max, df[var1].max())
            var2_min = min(var2_min, df[var2].min())
            var2_max = max(var2_max, df[var2].max())
            var_color_min = min(var_color_min, df[var_color].min())
            var_color_max = max(var_color_max, df[var_color].max())

        h5file_r.close()

        # Creating axis
        fig, ax = plt.subplots()

        scat = ax.scatter([], [], c=[], cmap='viridis', vmin=var_color_min, vmax=var_color_max)
        cbar = fig.colorbar(scat, ax=ax)
        cbar.set_label(var_color)

        ax.set_xlabel(fr"{var1}")
        ax.set_ylabel(fr"{var2}")
        ax.set_xlim([0.9 * var1_min, 1.1 * var1_max])
        ax.set_ylim([0.9 * var2_min, 1.1 * var2_max])

        title = ax.set_title("")

        fig.tight_layout()

        def update(frame_idx):
            df = dfs[frame_idx]
            it = iterations[frame_idx]

            scat.set_offsets(np.column_stack([df[var1], df[var2]]))
            scat.set_array(df[var_color])
            title.set_text(f"Iteration {it:05d}")

            return scat, title

        anim = animation.FuncAnimation(
            fig, update, frames=len(iterations), interval=interval, blit=False
        )

        save_path = self.save_folder + "/dtb_animation.mp4"

        anim.save(save_path, fps=fps, dpi=300)
        plt.close(fig)

        return anim

    #--------------------------------------------------------
    # TRAJECTORIES PLOTS
    #--------------------------------------------------------

    def plot_traj_T_Z(self):

        # styles
        linestyles = ["--", "-", "-.", ":"]

        fig, ax = plt.subplots()

        j = 0   
        for i in self.inlets_data_list.keys():
            ax.plot(self.inlets_data_list[i][:,self.nb_state_vars+1], self.inlets_data_list[i][:, 1], color="k", linestyle=linestyles[j % len(linestyles)], lw=2, label=f"Inlet {i:d}")
            j += 1    
            
        ax.set_xlabel(r"$Z$ $[-]$")
        ax.set_ylabel(r"$T$ $[K]$")

        ax.set_xlim([0.9*np.min(self.inlets_data_list[i][:,self.nb_state_vars+1]), 1.1*np.max(self.inlets_data_list[i][:,self.nb_state_vars+1])])

        ax.legend()

        fig.tight_layout()

        # Save
        fig.savefig(self.save_folder + "/traj_TZ_plot.png", dpi=300)

    def plot_traj_T_time(self):

        # styles
        linestyles = ["--", "-", "-.", ":"]

        fig, ax = plt.subplots()

        j = 0   
        for i in self.inlets_data_list.keys():
            ax.plot(self.inlets_data_list[i][:,0], self.inlets_data_list[i][:, 1], color="k", linestyle=linestyles[j % len(linestyles)], lw=2, label=f"Inlet {i:d}")
            j += 1    
            
        ax.set_xlabel(r"$t$ $[s]$")
        ax.set_ylabel(r"$T$ $[K]$")

        ax.legend()

        fig.tight_layout()

        # Save
        fig.savefig(self.save_folder + "/traj_T_time_plot.png", dpi=300)

    def plot_traj_Yk_time(self, species_to_plot, mech_file):

        # To get species index, maybe to be put in __init__ at some point
        gas = ct.Solution(mech_file)

        # styles
        linestyles = ["--", "-", "-.", ":"]

        for spec in species_to_plot:
    
            fig, ax = plt.subplots()
            
            j = 0   
            for i in self.inlets_data_list.keys():
                ax.plot(self.inlets_data_list[i][:,0], self.inlets_data_list[i][:, 3+gas.species_index(spec)], color="k", lw=2, linestyle=linestyles[j % len(linestyles)], label=f"Inlet {i:d}")
                j += 1
                
            ax.set_xlabel(r"$t$ $[s]$")
            ax.set_ylabel(f"${spec}$ mass fraction $[-]$")
            
            ax.legend()
            
            fig.tight_layout()
            
            # Save
            fig.savefig(self.save_folder + f"/traj_{spec}_time_plot.png", dpi=300)

    #--------------------------------------------------------
    # INDIVIDUAL PARTICLES TRACKING
    #--------------------------------------------------------

    def plot_indiv_traj(self, inlet_nb, var):

        # Filter only desired inlet 
        inlet_df = self.df[self.df["Inlet_number"]==inlet_nb]

        # Get list of dataframes for each particle
        df_part_list = list(inlet_df.groupby('Particle_number'))

        # Create figure
        fig, ax = plt.subplots()

        for item in df_part_list:
            
            df_part = item[1]
            
            ax.plot(df_part["Time"], df_part[var], alpha=0.2, color="purple")

        fig.tight_layout()

        # Save
        fig.savefig(self.save_folder + "/indiv_rajectory.png", dpi=300)

    #--------------------------------------------------------
    # DISTRIBUTIONS
    #--------------------------------------------------------


    def plot_pdf_inst(self, var, iteration):    

        # Loading solution at given iteration
        h5file_r = h5py.File(self.stoch_dtb_folder + "/solutions.h5", 'r')
        data = h5file_r.get(f"ITERATION_{iteration:05d}/all_states")[()]
        col_names = h5file_r[f"ITERATION_{iteration:05d}/all_states"].attrs["cols"]
        h5file_r.close()
        df = pd.DataFrame(data=data, columns=col_names)

        # Smart binwidth via Freedman-Diaconis rule
        binwidth = utils.smart_binwidth(df[var])
            
        # Temperature histogram
        fig, ax = plt.subplots()
        
        sns.histplot(data=df, x=var, ax=ax, stat="probability",
                     binwidth=binwidth, kde=True)

        fig.tight_layout()
            
        fig.savefig(self.save_folder + f"/PDF_{var}_plot_iteration{iteration:05d}.png")
            

    def plot_pdf_all(self, var): 
            
        # Temperature histogram
        fig, ax = plt.subplots()

        # Smart binwidth via Freedman-Diaconis rule
        binwidth = utils.smart_binwidth(self.df[var])
        
        sns.histplot(data=self.df, x=var, ax=ax, stat="probability",
                     binwidth=binwidth, kde=True)

        fig.tight_layout()
            
        fig.savefig(self.save_folder + f"/PDF_{var}_plot.png")
    

    #--------------------------------------------------------
    # Age of the particles
    #--------------------------------------------------------

    def plot_age_time(self):
        """Evolution of the mean and standard deviation of the age [s] of the active particles, with the constant
        residence time residence_time [s] of dtb_params.yaml (dashed line), if there is one."""

        stats = self.df.groupby("Time")["Age"].agg(["mean", "std"])

        fig, ax = plt.subplots()
        ax.plot(stats.index, stats["mean"], color="k", label="mean")
        ax.plot(stats.index, stats["std"], color="b", label="std")

        # Residence time (none in a closed reactor)
        with open(self.stoch_dtb_folder + "/dtb_params.yaml", "r") as file:
            residence_time = yaml.safe_load(file).get("residence_time")

        if residence_time is not None:
            ax.axhline(float(residence_time), color="r", ls="--", label=r"$\tau_{res}$")

        ax.set_xlabel(r"$t$ $[s]$")
        ax.set_ylabel(r"$a$ $[s]$")
        ax.legend()

        fig.tight_layout()

        fig.savefig(self.save_folder + "/age_time_plot.png")


    #--------------------------------------------------------
    # Points density
    #--------------------------------------------------------

    def density_scatter(self, var_x , var_y, sort = True, bins = 100):
        # Functions from https://stackoverflow.com/questions/20105364/how-can-i-make-a-scatter-plot-colored-by-density-in-matplotlib

        x = self.df[var_x]
        y = self.df[var_y]

        fig , ax = plt.subplots()
        data , x_e, y_e = np.histogram2d( x, y, bins = bins, density = True )
        z = interpn( ( 0.5*(x_e[1:] + x_e[:-1]) , 0.5*(y_e[1:]+y_e[:-1]) ) , data , np.vstack([x,y]).T , method = "splinef2d", bounds_error = False)

        #To be sure to plot all data
        z[np.where(np.isnan(z))] = 0.0

        # Sort the points by density, so that the densest points are plotted last
        if sort :
            idx = z.argsort()
            x, y, z = x[idx], y[idx], z[idx]

        ax.scatter(x, y, c=z)

        norm = Normalize(vmin = np.min(z), vmax = np.max(z))
        cbar = fig.colorbar(cm.ScalarMappable(norm = norm), ax=ax)
        cbar.ax.set_ylabel('Density')

        fig.tight_layout()

        fig.savefig(self.save_folder + f"/pnts_density_x{var_x}_y{var_y}_plot.png")