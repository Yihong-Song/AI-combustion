"""Database processing utilities for AI reacting flows.

This module exposes the :class:`LearningDatabase` class used to read raw
stochastic/flamelet databases, apply filtering, clustering, resampling and
produce machine‑learning ready train/validation datasets.
"""

import os
import sys
import shutil
import pickle

import oyaml as yaml
import joblib
import pandas as pd
import numpy as np
from scipy.interpolate import interpn
from scipy.stats import boxcox_normmax, skew, kurtosis
# from scipy.interpolate import interp1d
# from scipy.stats.kde import gaussian_kde
import h5py

# import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize 
from matplotlib import cm

import seaborn as sns

from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler #, MinMaxScaler
from sklearn.model_selection import train_test_split

import ai_reacting_flows.tools.utilities as utils
import ai_reacting_flows.tools.transforms as transforms
from ai_reacting_flows.databases_processing.processing_parameters import write_processing_parameters
from ai_reacting_flows.databases_processing.read_solutions import read_solutions
from ai_reacting_flows.tools.loss_weighting import increment_norm

sns.set_style("darkgrid")


class LearningDatabase(object):
    """Main entry point for database processing.

    The class reads raw HDF5 databases, optionally applies temperature
    thresholds, clustering and resampling, and finally produces
    train/validation datasets along with scalers and diagnostic plots.
    """

    def __init__(self):

        # Input parameters
        self.run_folder = os.getcwd()
        with open(os.path.join(self.run_folder, "dtb_processing.yaml"), "r") as file:
            dtb_processing_parameters = yaml.safe_load(file)

        database_params = dtb_processing_parameters["database_params"]
        self.database_type = database_params["database_type"]
        self.database_name = database_params["database_name"]
        self.input_dtb_file = database_params["dtb_file"]
        self.dt_var = database_params['dt_var']
        self.rollout = database_params.get("rollout", False)   # Database from time_step_type: rollout (generate_var_dt_dtb.py)
        self.detailed_mechanism  = database_params["mech_file"]
        self.fuel  = database_params["fuel"]

        data_processing = dtb_processing_parameters["data_processing"]
        self.log_transform_X  = data_processing["log_transform_X"]
        self.log_transform_Y  = data_processing["log_transform_Y"]
        self.threshold  = data_processing["threshold"]
        self.T_threshold  = data_processing["T_threshold"]
        self.output_omegas  = data_processing["output_omegas"]
        self.with_N_chemistry = data_processing["with_N_chemistry"]
        self.lambda_bct = data_processing.get("lambda_bct", 0.1)   # Box-Cox parameter (same default in NN_manager and NNTesting)

        # Optional list of species to keep on the original (linear) scale
        # even when log/Box–Cox transforms are active. This generalizes the
        # previous hard-coded N2 behavior.
        self.log_excluded_species = data_processing.get("log_excluded_species", [])

        data_clustering = dtb_processing_parameters["data_clustering"]
        self.clusterize_on = data_clustering['clusterize_on']
        self.clustering_method = data_clustering["clustering_method"]

        self.train_set_size = dtb_processing_parameters['train_set_size']

        self.nb_clusters = 1  # default value before clustering
        self.nb_clusters_input = data_clustering["nb_clusters"] # storing for later, if clustering is actually called

        if self.database_type not in ["stoch", "flamelets", "merged"]:
            sys.exit("Error on database_type. It should be 'stoch', 'flamelets' or 'merged'")

        # Parameters depending on database type
        if self.database_type=="stoch":
            folder_prefix = "STOCH"
        elif self.database_type=="flamelets":
            folder_prefix = "FLAMELETS"
        elif self.database_type=="merged":
            folder_prefix = "MERGED"    # merge_databases.py: read as a stochastic database (all iterations)
        
        # Folder where results are stored
        self.dtb_folder = f"{self.run_folder:s}/{folder_prefix}_DTB_" + database_params["dtb_folder_suffix"]


        # Check if mechanism is in YAML format
        if not self.detailed_mechanism.endswith("yaml"):
            sys.exit("ERROR: chemical mechanism should be in yaml format !")

        # Read H5 files to get databases in pandas format
        self.get_database_from_h5()

        # Extracting some information
        self.species_names = self.X.columns[2:-2] # -2 because progvar and HRR
        print(f" >> species names: {self.species_names}")
        self.nb_species = len(self.species_names)

        # Saving folder: by default the model is saved in cluster0
        if os.path.isdir(self.dtb_folder + "/" + self.database_name):
            print(f">> Processed dataset {self.database_name} already exists => deleting")
            shutil.rmtree(self.dtb_folder + "/" + self.database_name)  # We remove previous generated case if still here
        os.mkdir(self.dtb_folder + "/" + self.database_name)

        # By default, we attribute cluster 0 to everyone
        self.X["cluster"] = 0.0

        # Clusterized datasets
        self.clusterized_dataset = False

        # Flag to check if database has already been processed
        self.is_processed = False

        # Saving detailed mechanism in database folder
        shutil.copy(self.detailed_mechanism, self.dtb_folder + "/" + self.database_name + "/mech_detailed.yaml")
        shutil.copy(os.path.join(self.run_folder, "dtb_processing.yaml"), self.dtb_folder + "/" + self.database_name + "/dtb_processing.yaml")

        # self.is_reduced = False
        self.is_resampled = False

        self.is_pca_computed = False

        self.check_inputs()

    
    def get_database_from_h5(self):

        file_h5 = os.path.join(self.dtb_folder, self.input_dtb_file)
        print(f">> Reading database in file {file_h5}")

        X, self.col_names_X, Y, self.col_names_Y, dt_array = read_solutions(file_h5)
        self.X = pd.DataFrame(data=X, columns=self.col_names_X)

        # Multi-dt: one output per dt, shape (n, n_var, n_dt) (3D array cannot be stored in pandas dataframe)
        if self.dt_var:
            self.Y = Y
            self.dt_array = dt_array

        else:

            # Y is the first step (usual X, Y pairs), Y_rollout all steps, shape (n, n_steps, n_var)
            if self.rollout:
                self.Y = pd.DataFrame(data=Y[:, :, 0], columns=self.col_names_Y)
                self.Y_rollout = np.moveaxis(Y, 2, 1)

            # One step
            else:
                self.Y = pd.DataFrame(data=Y, columns=self.col_names_Y)

        print("End of reading ! \n")


    def database_to_h5(self, file_path, file_name):
        """Export current X/Y to a single-iteration HDF5 file.

        Parameters
        ----------
        file_path : str
            Directory where the file should be created.
        file_name : str
            Name of the HDF5 file to create.
        """

        # Read column names from the original database
        with h5py.File(os.path.join(self.dtb_folder, self.input_dtb_file), 'r') as h5file_r:
            col_names_X = h5file_r["ITERATION_00000/X"].attrs["cols"]
            col_names_Y = h5file_r["ITERATION_00000/Y"].attrs["cols"]

        # Create output file
        with h5py.File(os.path.join(file_path, file_name), 'w') as h5file_w:
            grp = h5file_w.create_group(f"ITERATION_{0:05d}")

            # Drop internal columns (cluster label, PCA coordinates) if present.
            cols_to_drop = [c for c in ["cluster", "PC1", "PC2"] if c in self.X.columns]
            dset_X = grp.create_dataset('X', data=self.X.drop(columns=cols_to_drop))
            dset_X.attrs['cols'] = col_names_X

            dset_Y = grp.create_dataset('Y', data=self.Y)
            dset_Y.attrs['cols'] = col_names_Y

        print("\n H5PY dataset created")


    def apply_temperature_threshold(self):
        """
        Filter X and Y to keep only samples where Temperature exceeds T_threshold.
        Must be called before clustering.
        """

        if self.clusterized_dataset:
            raise RuntimeError("Temperature threshold should be performed before clustering")

        # Mask
        is_above_temp = self.X["Temperature"]>self.T_threshold

        if not is_above_temp.any():
            raise ValueError(f"No samples remain above T_threshold={self.T_threshold}")

         # Apply mask
        self.X = self.X[is_above_temp].reset_index(drop=True)

        if self.dt_var:
            self.Y = self.Y[is_above_temp.values, :]
            self.dt_array = self.dt_array[is_above_temp.values]
        else:
            self.Y = self.Y[is_above_temp].reset_index(drop=True)

        if self.rollout:
            self.Y_rollout = self.Y_rollout[is_above_temp.values]


    def clusterize_dataset(self, c_bounds=None):

        # Avoid mutable default for c_bounds
        if c_bounds is None:
            c_bounds = []

        self.clusterized_dataset = True

        # updated from 1 (before clustering) to its actually value read from inputs
        self.nb_clusters = self.nb_clusters_input

        # if self.clusterize_on == 'double':
        #     nb_clusters_phys, nb_clusters_time = self.nb_clusters
        #     self.nb_clusters_tot = nb_clusters_phys * nb_clusters_time
        # else :
        # self.nb_clusters_tot = self.nb_clusters

        assert (not self.is_processed)

        if self.clustering_method=="progvar":

            # assert self.clusterize_on != 'double'
            assert self.nb_clusters == len(c_bounds) - 1

            # Saving bounds for progress variables
            with open(self.dtb_folder + "/" + self.database_name + "/c_bounds.pkl", 'wb') as f:
                pickle.dump(c_bounds, f)

            # Assigning cluster can be made using pd.cut. Progress variable clipped to [0, 1] as in
            # NNTesting.compute_progvar (otherwise points outside c_bounds get no cluster and are lost)
            self.X["cluster"] = pd.cut(
                                    self.X["Prog_var"].clip(0.0, 1.0),
                                    bins=c_bounds,
                                    labels=False,
                                    include_lowest=True,
                                    )

        elif self.clustering_method=="kmeans":
            
            # Species used as features (N2 removed without N chemistry)
            species = [spec for spec in self.species_names if self.with_N_chemistry or spec != "N2"]

            # Clustering on the time step only makes sense with multiple dt
            clusterize_on = self.clusterize_on if self.dt_var else "phys"

            # ------------------------------------------------------------------
            # Build data matrix for clustering (transforms in tools/transforms.py, shared with inference)
            # ------------------------------------------------------------------

            # Flattened (state, dt) points with multiple dt
            if clusterize_on in ["dt", "all"]:
                X_kmeans, _, _ = self._flatten_multi_dt_arrays(self.X, self.Y, self.dt_array)
                dt_kmeans = X_kmeans["dt"].values

            # Physical states
            else:
                X_kmeans = self.X
                dt_kmeans = None

            data_kmeans = transforms.kmeans_features(X_kmeans["Temperature"].values, X_kmeans[species].values, dt_kmeans,
                                                     species, clusterize_on, self.log_transform_X, self.threshold,
                                                     self.lambda_bct, self.log_excluded_species)

            # ------------------------------------------------------------------
            # Normalize before k-means
            # ------------------------------------------------------------------

            # Normalizing states before k-means
            Xscaler = StandardScaler()
            Xscaler.fit(data_kmeans)
            data_kmeans = Xscaler.transform(data_kmeans)

            # ------------------------------------------------------------------
            # K-means
            # ------------------------------------------------------------------

            # Applying k-means clustering
            print(">> Performing k-means clustering")
            # if self.dt_var and self.clusterize_on == "double":
            #     print("Shape (phys):", data_kmeans_phys.shape)
            #     print("Shape (time):", data_kmeans_time.shape)
            # else:
            print("Shape:", data_kmeans.shape)
            
            # if self.dt_var and self.clusterize_on=='double':
            #     kmeans_phys = KMeans(n_clusters=nb_clusters_phys, random_state=42).fit(data_kmeans_phys)
            #     kmeans_time = KMeans(n_clusters=nb_clusters_time, random_state=42).fit(data_kmeans_time)
            # else :
            kmeans = KMeans(n_clusters=self.nb_clusters, random_state=42).fit(data_kmeans)

            # if self.dt_var and self.clusterize_on=='double':
            #     print(kmeans_phys.labels_)
            #     print('KMeans Phys Score : ', kmeans_phys.score(data_kmeans_phys))
            #     print('KMeans Time Score : ', kmeans_time.score(data_kmeans_time))
            # else:
            print('KMeans Score : ', kmeans.score(data_kmeans))

            # ------------------------------------------------------------------
            # Store labels
            # ------------------------------------------------------------------

            # Attributing cluster to data points
            # if self.dt_var and self.clusterize_on=='double':
            #     self.X["cluster_phys"] = kmeans_phys.labels_
            #     self.time_clusters = kmeans_time.labels_
            #     self.all_clusters = kmeans_phys.labels_ * nb_clusters_time + kmeans_time.labels_    #CM: BUG HERE array should be *n_dt  => to debug and double is OK
            if self.dt_var and self.clusterize_on=='dt':
                self.time_clusters = kmeans.labels_
            elif self.dt_var and self.clusterize_on=='all':
                self.all_clusters = kmeans.labels_
            else:  # constant dt or dt var with clusterize_on=phys
                self.X["cluster"] = kmeans.labels_

            # ------------------------------------------------------------------
            # Save model and normalization
            # ------------------------------------------------------------------

            # Saving K-means model
            with open(self.dtb_folder + "/" + self.database_name + "/kmeans_model.pkl", "wb") as f:
                pickle.dump(kmeans, f)

            # Saving scaler
            joblib.dump(Xscaler, self.dtb_folder + "/" + self.database_name + "/Xscaler_kmeans.pkl")

            # Saving normalization parameters and centroids
            np.savetxt(self.dtb_folder + "/" + self.database_name + '/kmeans_norm.dat', np.vstack([Xscaler.mean_, Xscaler.var_]).T)
            np.savetxt(self.dtb_folder + "/" + self.database_name + '/km_centroids.dat', kmeans.cluster_centers_.T)



    def visualize_clusters(self, var1, var2):

        # if self.dt_var and self.clusterize_on=="double":
        #     print("WARNING: double (physical, time) clustering is used; this function only shows the physical clustering.")
        #     cluster_var = "cluster_phys"
        # else:
        cluster_var = "cluster"

        if self.dt_var and (self.clusterize_on in ["dt", "all"]):
            raise ValueError("Current cluster visualization is only possible for physical clustering, 'all' and 'dt' are not allowed.")

        # If variables are PC1 and PC2, we compute the PCA
        if var1=="PC1" and var2=="PC2":
            if not self.is_pca_computed:
                self.compute_pca()

        fig, ax = plt.subplots()
        im = ax.scatter(self.X[var1], self.X[var2], c = self.X[cluster_var])
        fig.colorbar(im, ax=ax)
        ax.set_xlabel(var1, fontsize=16)
        ax.set_ylabel(var2, fontsize=16)
        fig.tight_layout()
        fig.savefig(self.dtb_folder + "/" + self.database_name + f"/cluster_{var1}_{var2}.png")


    # Re-sampling based on heat release rate
    def undersample_HRR(self, jpdf_var_1, jpdf_var_2, hrr_func, keep_low_c, n_samples, n_bins=100, seed=1991, plot_distrib=False):

        if self.clusterized_dataset and self.dt_var and self.clusterize_on in ("dt", "all"):
            raise NotImplementedError(
                "undersample_HRR does not currently support resampling after "
                "clustering on 'dt' or 'all' with dt_var=True, because the "
                "resulting cluster-label arrays would no longer match the "
                "resampled data. Cluster on 'phys' before resampling, or "
                "re-cluster after calling undersample_HRR."
            )
        
        # Save initial states for later use
        self.X_old = self.X.copy()
        self.Y_old = self.Y.copy()

        # If variables are PC1 and PC2, the re-sampling is done in (normalized) PC-space and we need to perform the PA
        if jpdf_var_1=="PC1" and jpdf_var_2=="PC2":
            if not self.is_pca_computed:
                self.compute_pca()

        # Dataset size
        n = self.X.shape[0]

        # Variable on which to take statistics
        a = np.abs(self.X["HRR"])
        a = (a-a.min())/(a.max()-a.min())
        a = hrr_func(a)

        # Setting a numpy seed
        np.random.seed(seed) 

        x = self.X[jpdf_var_1]
        y = self.X[jpdf_var_2]
        data, x_e, y_e = np.histogram2d(x, y, bins = n_bins, density = True)

        data_hrr, _, _ = np.histogram2d(x, y, bins = n_bins, density = True, weights=a)
        counts, _, _ = np.histogram2d(x, y, bins = n_bins, density = False)
        data_hrr = data_hrr / counts
        data_hrr[np.where(np.isnan(data_hrr))] = 0.0
        data_hrr[np.where(np.isinf(data_hrr))] = 0.0

        # Computing weighting function
        f_m = (data_hrr/data) #(n_samples/n) * (data_hrr/data) (factor n_samples/n useless as we normalize later)
        f_m[np.where(np.isnan(f_m))] = 0.0

        f_m_interp = interpn( ( 0.5*(x_e[1:] + x_e[:-1]) , 0.5*(y_e[1:]+y_e[:-1]) ) , f_m , np.vstack([x,y]).T , method = "linear", bounds_error = False)
        f_m_interp[np.where(np.isnan(f_m_interp))] = 0.0

        # random.choice needs probability (sum to 1)
        p = f_m_interp/f_m_interp.sum()


        # PLOTTING FOR PAPER----------------------------------------------------------------------------

        data_hrr_interp = interpn( ( 0.5*(x_e[1:] + x_e[:-1]) , 0.5*(y_e[1:]+y_e[:-1]) ) , data_hrr , np.vstack([x,y]).T , method = "linear", bounds_error = False)
        data_interp = interpn( ( 0.5*(x_e[1:] + x_e[:-1]) , 0.5*(y_e[1:]+y_e[:-1]) ) , data , np.vstack([x,y]).T , method = "linear", bounds_error = False)

        if plot_distrib:
            fig, (ax1,ax2,ax3) = plt.subplots(nrows=3)
            fig.set_size_inches(18.5, 10.5)

            plt.set_cmap('plasma')
            im = ax1.scatter(x, y, c=data_interp, s=4, vmin=0, vmax=0.1)
            cbar = fig.colorbar(im, ax=ax1)
            cbar.ax.set_ylabel(r'$f_s$ $[-]$', fontsize=16)
            fig.tight_layout()

            im = ax2.scatter(x, y, c=np.log(data_hrr_interp), s=4, vmin=-10, vmax=np.log(0.00004))
            cbar = fig.colorbar(im, ax=ax2)
            cbar.ax.set_ylabel(r'$\log(f_q)$ $[-]$', fontsize=16)
            fig.tight_layout()

            im = ax3.scatter(x, y, c=np.log(p), s=4, vmin=-20, vmax=-5)
            cbar = fig.colorbar(im, ax=ax3)
            cbar.ax.set_ylabel(r'$\log(f_m)$ $[-]$', fontsize=16)
            fig.tight_layout()

            ax1.xaxis.set_ticklabels([])
            ax2.xaxis.set_ticklabels([])
            for ax in [ax1,ax2,ax3]:
                ax.set_box_aspect(1)
                # ax.set_ylabel(r"$Y_{H_{2}O}$ $[-]$", fontsize=16)
                ax.set_ylabel(jpdf_var_2, fontsize=16)
            # ax3.set_xlabel(r"$T$ $[K]$", fontsize=16)
            ax3.set_xlabel(jpdf_var_1, fontsize=16)

            fig.tight_layout()
            fig.savefig(os.path.join(self.dtb_folder, "resampling_analysis.png"), dpi=400, bbox_inches="tight")

        # -------------------------------------------------------------------------------------------------

        # Copying X to manipulate weights
        X_save = self.X.copy()
        X_save["p"] = p

        # Setting probability of points with p=0.0 to a very small value, so that we are able to reach the original datasets for high values of samples
        # (smallest positive probability: the minimum of all p is 0)
        X_save.loc[X_save["p"]==0.0, 'p'] = X_save.loc[X_save["p"]>0.0, "p"].min()/1000.0

        # Imposing small progress variable values to stay in dataset (needed for ignition)
        if keep_low_c:
            X_save.loc[(X_save["Prog_var"]<0.2) & (X_save["Temperature"]>1000.0), 'p'] = 1.0

        # Normalizing
        p = X_save["p"]/X_save["p"].sum()

        # Performing the random choice of points
        choice = np.random.choice(range(n), replace=False, size=n_samples, p=p)

        # Performing the point selection in database
        self.X = self.X.iloc[choice]
        self.X = self.X.reset_index(drop=True)
        #
        if self.dt_var:
            self.Y = self.Y[choice, :]
            self.dt_array = self.dt_array[choice]
        else:
            self.Y = self.Y.iloc[choice]
            self.Y = self.Y.reset_index(drop=True)

        if self.rollout:
            self.Y_rollout = self.Y_rollout[choice]

        self.is_resampled = True

        # We recompute PCA because database has changed
        if jpdf_var_1=="PC1" and jpdf_var_2=="PC2":
            self.compute_pca()
    
        print(f"\n Number of points in undersampled dataset: {self.X.shape[0]} \n")
        print(f"    >> {100*self.X.shape[0]/n} % of the database is retained")


    def undersample_1D(self, var, seed=1991, min_count=1, plot_distrib=False):

        print("--- 1D BINS UNDERSAMPLING ---")

        # Dataset size
        n = self.X.shape[0]

        print(f"Initial number of samples: {n}")

        if var=="PC1" or var=="PC2":
            if not self.is_pca_computed:
                self.compute_pca()

        self.X_old = self.X.copy()
        self.Y_old = self.Y.copy()

        rng = np.random.default_rng(seed)

        v = self.X[var].values

        # Compute optimal bin width
        binwidth = utils.smart_binwidth(v)
        print("Computed binwidth is", binwidth)

        # Create bin edges
        edges = np.arange(v.min(), v.max() + binwidth, binwidth)

        # Histogram
        counts, _ = np.histogram(v, bins=edges)

        # Assign each point to a bin
        bin_id = np.digitize(v, edges[:-1], right=False)

        # Bins with enough samples get subsampled down to n_keep;
        # sparse bins are kept whole, untouched.
        occupied = counts > 0
        eligible_mask = occupied & (counts >= min_count)
        n_keep = counts[eligible_mask].min() if eligible_mask.any() else None

        n_sparse_bins = (occupied & ~eligible_mask).sum()
        n_sparse_points = counts[occupied & ~eligible_mask].sum()

        if n_sparse_bins > 0:
            print(f"Keeping {n_sparse_bins} sparse bins whole "
                f"({n_sparse_points} points, no subsampling applied).")

        if n_keep is not None:
            print(f"Subsampling to {n_keep} samples per eligible bin.")
        else:
            print("No bin reaches min_count; nothing will be subsampled.")

        selected = []

        for b in range(1, len(edges)):
            idx = np.where(bin_id == b)[0]

            if len(idx) == 0:
                continue

            if eligible_mask[b - 1]:
                chosen = rng.choice(idx, size=n_keep, replace=False)
                selected.extend(chosen)
            else:
                # Sparse bin: keep every point as-is
                selected.extend(idx)

        selected = np.array(selected)
        rng.shuffle(selected)

        self.X = self.X.iloc[selected].reset_index(drop=True)

        if self.dt_var:
            self.Y = self.Y[selected, :]
            self.dt_array = self.dt_array[selected]
        else:
            self.Y = self.Y.iloc[selected].reset_index(drop=True)

        if self.rollout:
            self.Y_rollout = self.Y_rollout[selected]

        self.is_resampled = True

        if plot_distrib:
            plt.figure(figsize=(6,4))
            plt.hist(v, bins=edges, alpha=0.5, density=True, label="Before")
            plt.hist(self.X[var], bins=edges, alpha=0.5, density=True, label="After")
            plt.legend()
            plt.xlabel(var)
            plt.ylabel("Density")
            plt.tight_layout()
            plt.show()


        print(f"\n Number of points in undersampled dataset: {self.X.shape[0]} \n")
        print(f"    >> {100*self.X.shape[0]/n} % of the database is retained")


    def undersample_Omega(self, Omega_min, seed=1991, min_count=1, plot_distrib=False):
        """1D undersampling (undersample_1D) on log10(Omega), with Omega [-] the norm of the scaled increments of the
        species of the network (the same quantity as the loss weights of tools/loss_weighting.py):

            Omega^2 = sum_k (omega_k / sigma_k)^2,   omega_k = f(Y_k(t+dt)) - f(Y_k(t))

        with f the transform of the outputs (log_transform_Y) and sigma_k the standard deviation of omega_k over the
        database. Bins of log10(Omega) then have the same number of points: all magnitudes of the increments, from the
        ignition to the burnt gases, are equally represented. Values below Omega_min [-] (equilibrium, solver noise)
        are gathered in the first bin. See docs/theory.md (Loss weighting).
        """

        if self.dt_var:
            raise NotImplementedError("undersample_Omega is not available for multi-dt databases (one increment per dt)")

        # Increments of the species of the network, with the transform of the outputs
        species = [spec for spec in self.species_names if self.with_N_chemistry or spec != "N2"]
        Y_t = transforms.transform_species(self.X[species].values, species, self.log_transform_Y, self.threshold,
                                           self.lambda_bct, self.log_excluded_species)
        Y_t_dt = transforms.transform_species(self.Y[species].values, species, self.log_transform_Y, self.threshold,
                                              self.lambda_bct, self.log_excluded_species)
        omega = Y_t_dt - Y_t

        Omega = increment_norm(omega, transforms.scaler_std(omega.var(axis=0)))
        print(f"Omega quantiles 1%/50%/99%: {np.quantile(Omega, 0.01):.3e}/{np.median(Omega):.3e}/{np.quantile(Omega, 0.99):.3e}")

        # Temporary column of the undersampling variable, removed afterwards
        self.X["log10_Omega"] = np.log10(np.maximum(Omega, Omega_min))
        self.undersample_1D("log10_Omega", seed=seed, min_count=min_count, plot_distrib=plot_distrib)

        self.X = self.X.drop(columns="log10_Omega")
        self.X_old = self.X_old.drop(columns="log10_Omega")


    def undersample_2D(self, var1, var2, seed=1991, min_count=1, plot_distrib=False):

        print("--- 2D BINS UNDERSAMPLING ---")
        
        # Dataset size
        n = self.X.shape[0]

        print(f"Initial number of samples: {n}")

        for var in (var1, var2):
            if var in ("PC1", "PC2") and not self.is_pca_computed:
                self.compute_pca()

        self.X_old = self.X.copy()
        self.Y_old = self.Y.copy()

        rng = np.random.default_rng(seed)

        v1 = self.X[var1].values
        v2 = self.X[var2].values

        # Compute optimal bin width for each axis
        binwidth1 = utils.smart_binwidth(v1)
        binwidth2 = utils.smart_binwidth(v2)
        print(f"Computed binwidths are {binwidth1} ({var1}) and {binwidth2} ({var2})")

        # Create bin edges for each axis
        edges1 = np.arange(v1.min(), v1.max() + binwidth1, binwidth1)
        edges2 = np.arange(v2.min(), v2.max() + binwidth2, binwidth2)

        # Assign each point to a bin along each axis
        bin_id1 = np.digitize(v1, edges1[:-1], right=False)
        bin_id2 = np.digitize(v2, edges2[:-1], right=False)

        # Combine into a single 2D bin identifier
        bin_id_2d = np.stack([bin_id1, bin_id2], axis=1)

        # Count occupancy per combined bin
        unique_bins, inverse, bin_counts = np.unique(
            bin_id_2d, axis=0, return_inverse=True, return_counts=True
        )

        # Bins with enough samples get subsampled down to n_keep;
        # sparse bins are kept whole, untouched.
        eligible_mask = bin_counts >= min_count
        n_keep = bin_counts[eligible_mask].min() if eligible_mask.any() else None

        n_sparse_bins = (~eligible_mask).sum()
        n_sparse_points = bin_counts[~eligible_mask].sum()

        if n_sparse_bins > 0:
            print(f"Keeping {n_sparse_bins} sparse bins whole "
                f"({n_sparse_points} points, no subsampling applied).")

        if n_keep is not None:
            print(f"Subsampling to {n_keep} samples per eligible 2D bin.")
        else:
            print("No bin reaches min_count; nothing will be subsampled.")

        selected = []

        for b in range(len(unique_bins)):
            idx = np.where(inverse == b)[0]

            if eligible_mask[b]:
                chosen = rng.choice(idx, size=n_keep, replace=False)
                selected.extend(chosen)
            else:
                # Sparse bin: keep every point as-is
                selected.extend(idx)

        selected = np.array(selected)
        rng.shuffle(selected)

        self.X = self.X.iloc[selected].reset_index(drop=True)

        if self.dt_var:
            self.Y = self.Y[selected, :]
            self.dt_array = self.dt_array[selected]
        else:
            self.Y = self.Y.iloc[selected].reset_index(drop=True)

        if self.rollout:
            self.Y_rollout = self.Y_rollout[selected]

        self.is_resampled = True

        if plot_distrib:
            fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharex=True, sharey=True)

            axes[0].hist2d(v1, v2, bins=[edges1, edges2], cmap="viridis")
            axes[0].set_title("Before")
            axes[0].set_xlabel(var1)
            axes[0].set_ylabel(var2)

            axes[1].hist2d(self.X[var1], self.X[var2], bins=[edges1, edges2], cmap="viridis")
            axes[1].set_title("After")
            axes[1].set_xlabel(var1)
            axes[1].set_ylabel(var2)

            plt.tight_layout()
            plt.show()

        print(f"\n Number of points in undersampled dataset: {self.X.shape[0]} \n")
        print(f"    >> {100*self.X.shape[0]/n} % of the database is retained")


    # Database final processing
    def process_database(self, plot_distributions = False, distribution_species=[], seed = 42):

        self.is_processed = True

        # Also writing all data in a h5 file which is easier to read than csv. CM: maybe remove csv ultimately
        h5file_w = h5py.File(os.path.join(self.dtb_folder,self.database_name,"training_data.h5"), 'w')

        # Processing parameters, read by training and testing (processing_parameters.py)
        write_processing_parameters(h5file_w, self._processing_parameters())

        # Pressure removed by default (can be changed later)
        remove_pressure_X = True
        remove_pressure_Y = True

        # If variable dt is used, self.X is of size (N,n_var) and self.Y is shape (N,n_var,n_dt)
        # We flatten arrays to get both self.X and self.Y of shapes (n_dt*N,n_var)
        # We can then use same lines of code as the non variable dt, it should have no impact on the scalers.
        if self.dt_var:

            X, Y, _ = self._flatten_multi_dt_arrays(self.X, self.Y, self.dt_array)

            # Appending cluster indices in cases where it only makes sense on flatted arrays
            if self.clusterized_dataset: 
                if self.clusterize_on=="dt":
                    X["cluster"] = self.time_clusters   #in this case clustering is made on dt only
                elif self.clusterize_on=="all": # or self.clusterize_on=="double":
                    X["cluster"] = self.all_clusters

        # Constant dt 
        else:
            X = self.X.copy()
            Y = self.Y.copy()

        for i_cluster in range(self.nb_clusters):
            
            print("", flush=True)
            print(f"CLUSTER {i_cluster}:", flush=True)

            # Isolate cluster i
            X_p = X[X["cluster"]==i_cluster]
            if self.dt_var:
                Y_p = Y.loc[X["cluster"]==i_cluster, :]
            else:
                Y_p = Y[X["cluster"]==i_cluster]

            # Reset indexes
            X_p = X_p.reset_index(drop=True)
            Y_p = Y_p.reset_index(drop=True)

            # Removing useless columns
            X_cols = X_p.columns.to_list()
            # if self.clusterized_dataset and self.dt_var and self.clusterize_on == 'double': 
            #     list_to_remove = ["Prog_var", "HRR", "cluster", "cluster_phys"]
            # else:
            list_to_remove = ["Prog_var", "HRR", "cluster"]
            
            if remove_pressure_X:
                list_to_remove.append('Pressure')
            if self.is_pca_computed:
                list_to_remove.append("PC1")
                list_to_remove.append("PC2")
            #
            [X_cols.remove(elt) for elt in list_to_remove]   
            X_p = X_p[X_cols] 
            #
            Y_cols = Y_p.columns.to_list()
            list_to_remove = ["Temperature", "Prog_var", "HRR"]
            
            if remove_pressure_Y:
                list_to_remove.append('Pressure')
            #
            [Y_cols.remove(elt) for elt in list_to_remove]   
            Y_p = Y_p[Y_cols] 
            

            # Species (and Temperature) columns to which the threshold/clip legitimately applies.
            # dt (if present) is excluded: it's a timestep, not a mass fraction, and must not be
            # floored to the same threshold as chemical species.
            if self.dt_var:
                clip_cols = X_cols[:-1]   # everything except trailing "dt" column
            else:
                clip_cols = X_cols

            # Applying transformation (log or Box–Cox) to species/Temperature.
            # Species listed in self.log_excluded_species are explicitly
            # excluded from the log/BCT, so they stay on the original
            # (linear) scale even when log_transform_* > 0.
            cols_to_log_X = [c for c in clip_cols[1:] if c not in self.log_excluded_species]
            cols_to_log_Y = [c for c in Y_cols if c not in self.log_excluded_species]

            # Clip before transformation (threshold for log, 0 for Box-Cox), as in tools/transforms.py
            # shared with training and inference. log_excluded_species are kept on their original scales.
            X_p[cols_to_log_X] = transforms.clip(X_p[cols_to_log_X], self.log_transform_X, self.threshold)
            Y_p[cols_to_log_Y] = transforms.clip(Y_p[cols_to_log_Y], self.log_transform_Y, self.threshold)

            # Rollout targets: states at t+k*dt, transformed as Y, never as differences nor scaled (the rollout loss
            # compares absolute states, see docs/theory.md). Y_N2: N2 at t, constant if not predicted, for cp in the
            # temperature update (0 if predicted, then not used).
            if self.rollout:
                in_cluster = (X["cluster"]==i_cluster).values
                species_network = [c for c in Y_cols if self.with_N_chemistry or c != "N2"]
                columns = [list(self.col_names_Y).index(c) for c in species_network]
                Y_rollout_p = np.stack([transforms.transform_species(self.Y_rollout[in_cluster, k][:, columns], species_network, self.log_transform_Y,
                                                                     self.threshold, self.lambda_bct, self.log_excluded_species)
                                        for k in range(self.Y_rollout.shape[1])], axis=1)
                Y_N2_p = np.zeros(in_cluster.sum()) if self.with_N_chemistry else X.loc[in_cluster, "N2"].values

            # If log transform at input and not at output and output_omega, we need to save un-transformed data
            if self.log_transform_X>0 and self.log_transform_Y==0 and self.output_omegas:
                if self.dt_var:
                    X_p_save = X_p.loc[:, X_cols[1:-1]] # dt should not be taken into account
                else:
                    X_p_save = X_p.loc[:, X_cols[1:]]

            # Log or Box-Cox transform
            X_p[cols_to_log_X] = transforms.forward(X_p[cols_to_log_X], self.log_transform_X, self.lambda_bct)
            Y_p[cols_to_log_Y] = transforms.forward(Y_p[cols_to_log_Y], self.log_transform_Y, self.lambda_bct)

            # dt gets its own log transform, unclipped by the species threshold
            if self.dt_var:
                X_p["dt"] = transforms.transform_dt(X_p["dt"])


            # If differences are considered
            if self.output_omegas:
                if self.log_transform_X>0 and self.log_transform_Y==0:  # Case where X has been logged but not Y
                    Y_p = Y_p.subtract(X_p_save.reset_index(drop=True))
                else:
                    if self.dt_var:
                        Y_p = Y_p.subtract(X_p.loc[:,X_cols[1:-1]].reset_index(drop=True))  # dt should not be taken into account
                    else:
                        Y_p = Y_p.subtract(X_p.loc[:,X_cols[1:]].reset_index(drop=True))

            # Renaming columns
            X_p.columns = [str(col) + '_X' for col in X_p.columns]
            Y_p.columns = [str(col) + '_Y' for col in Y_p.columns]

            if not self.with_N_chemistry:
                X_p = X_p.drop("N2_X", axis=1)
                Y_p = Y_p.drop("N2_Y", axis=1)


            # Train validation split
            if self.rollout:
                # Same draw for all arrays: rows stay aligned
                X_train, X_val, Y_train, Y_val, Y_rollout_train, Y_rollout_val, Y_N2_train, Y_N2_val = train_test_split(X_p, Y_p, Y_rollout_p, Y_N2_p, train_size=self.train_set_size, random_state=seed)
            else:
                X_train, X_val, Y_train, Y_val = train_test_split(X_p, Y_p, train_size=self.train_set_size, random_state=seed)

            # === SCALERS ===
            # NORMALIZING X
            Xscaler = StandardScaler()
            X_train_array = Xscaler.fit_transform(X_train)
            X_val_array = Xscaler.transform(X_val)

            X_train = pd.DataFrame(X_train_array, columns=X_train.columns, index=X_train.index)
            X_val = pd.DataFrame(X_val_array, columns=X_val.columns, index=X_val.index)
            
            # NORMALIZING Y
            Yscaler = StandardScaler()
            Y_train_array = Yscaler.fit_transform(Y_train)
            Y_val_array = Yscaler.transform(Y_val)

            Y_train = pd.DataFrame(Y_train_array, columns=Y_train.columns, index=Y_train.index)
            Y_val = pd.DataFrame(Y_val_array, columns=Y_val.columns, index=Y_val.index)
        

            print(">> Saving datasets", flush=True)

            # Saving in h5 format
            grp = h5file_w.create_group(f"CLUSTER_{i_cluster}")

            # Saving scalers
            Xscaler_array = np.column_stack([Xscaler.mean_, Xscaler.var_])
            dset_Xscaler = grp.create_dataset('Xscaler', data = Xscaler_array)
            dset_Xscaler.attrs['cols'] = np.array(["mean", "var"], dtype=object)
            #
            Yscaler_array = np.column_stack([Yscaler.mean_, Yscaler.var_])
            dset_Yscaler = grp.create_dataset('Yscaler', data = Yscaler_array)
            dset_Yscaler.attrs['cols'] = np.array(["mean", "var"], dtype=object)
            
            # Saving data
            dset_X_train = grp.create_dataset('X_train', data = X_train)
            dset_X_train.attrs['cols'] = np.array(X_train.columns, dtype=object)
            #
            dset_Y_train = grp.create_dataset('Y_train', data = Y_train)
            dset_Y_train.attrs['cols'] = np.array(Y_train.columns, dtype=object)
            #
            dset_X_val = grp.create_dataset('X_val', data = X_val)
            dset_X_val.attrs['cols'] = np.array(X_val.columns, dtype=object)
            #
            dset_Y_val = grp.create_dataset('Y_val', data = Y_val)
            dset_Y_val.attrs['cols'] = np.array(Y_val.columns, dtype=object)
            #
            if self.rollout:
                grp.create_dataset('Y_rollout_train', data = Y_rollout_train).attrs['cols'] = np.array(Y_train.columns, dtype=object)
                grp.create_dataset('Y_rollout_val', data = Y_rollout_val).attrs['cols'] = np.array(Y_val.columns, dtype=object)
                grp.create_dataset('Y_N2_train', data = Y_N2_train)
                grp.create_dataset('Y_N2_val', data = Y_N2_val)

            print(f">> Analyze statistics of database for cluster {i_cluster}")
            self.compute_statistical_analysis(X_train, Xscaler, i_cluster)

            # Saving datasets
            # print(">> Saving datasets")
            # X_train.to_csv(self.dtb_folder + "/" + self.database_name + f"/cluster{i_cluster}/X_train.csv", index=False)
            # X_val.to_csv(self.dtb_folder + "/" + self.database_name + f"/cluster{i_cluster}/X_val.csv", index=False)
            # Y_train.to_csv(self.dtb_folder + "/" + self.database_name + f"/cluster{i_cluster}/Y_train.csv", index=False)
            # Y_val.to_csv(self.dtb_folder + "/" + self.database_name + f"/cluster{i_cluster}/Y_val.csv", index=False)

            # Plotting distributions if necessary
            if plot_distributions:
                print(">> Plotting distributions", flush=True)
                for spec in distribution_species:
                   self.plot_distributions(X_train, X_val, Y_train, Y_val, spec, i_cluster)

        h5file_w.close()


    def _processing_parameters(self):
        """Parameters used to build the training data, written in training_data.h5 (see processing_parameters.py)."""

        # Progress variable species, from the generation parameters copied in the database folder
        if self.database_type=="stoch":
            params_file = "dtb_params.yaml"
        elif self.database_type=="flamelets":
            params_file = "dtb_params_flmts.yaml"
        elif self.database_type=="merged":
            params_file = "dtb_merging.yaml"
        with open(os.path.join(self.dtb_folder, params_file), "r") as file:
            pv_species = yaml.safe_load(file)["pv_species"]

        return {
            "dt_var": self.dt_var,
            "rollout": self.rollout,
            "fuel": self.fuel,
            "log_transform_X": self.log_transform_X,
            "log_transform_Y": self.log_transform_Y,
            "lambda_bct": self.lambda_bct,
            "threshold": self.threshold,
            "output_omegas": self.output_omegas,
            "with_N_chemistry": self.with_N_chemistry,
            "log_excluded_species": list(self.log_excluded_species),
            "clustering_method": self.clustering_method,
            "clusterize_on": self.clusterize_on,
            "nb_clusters": self.nb_clusters,   # Number of clusters actually written (1 without clustering)
            "pv_species": list(pv_species),
        }


    def _flatten_multi_dt_arrays(self, X_p, Y_p, dt_p):     
        
        # X columns names (it is still a pandas dataframe)
        #Keeping columns names at the end of this routine enables a transparent removal of variables later in process_database
        col_names_X = X_p.columns.tolist()
        
        N = X_p.shape[0]
        n_var_X = X_p.shape[1]
        n_var_Y = Y_p.shape[1]
        n_dt = dt_p.shape[1]

        # Flatten dt array 
        dt_p_flat = dt_p.flatten()

        X_p_flat_arr = np.empty((n_dt*N,n_var_X+1))
        for i_dt in range(n_dt):
            X_p_flat_arr[i_dt::n_dt,:-1] = X_p.values    # X_p is pandas
        X_p_flat_arr[:,-1] = dt_p_flat

        Y_p_flat_arr = np.empty((n_dt*N,n_var_Y))
        for i_dt in range(n_dt):
            Y_p_flat_arr[i_dt::n_dt,:] = Y_p[:,:,i_dt]

        # We finally want pandas dataframes
        col_names_X.append("dt")
        X_p_flat = pd.DataFrame(data=X_p_flat_arr, columns=col_names_X)
        #
        Y_p_flat = pd.DataFrame(data=Y_p_flat_arr, columns=self.col_names_Y)   # We assume no additional columns have been added to Y after reading h5

        return X_p_flat, Y_p_flat, dt_p_flat


    def compute_statistical_analysis(self, X_train, Xscaler, i_cluster):

        cols = X_train.columns

        means = Xscaler.mean_
        stds = np.sqrt(Xscaler.var_)

        header = (                                                                                                                                                                                                                                  
            f"{'Species':15s}"                                                                                                                                                                                                                      
            f"{'mean':>8s}" 
            f"{'std':>8s}" 
            f"{'min':>8s}"                                                                                                                                                                                                                         
            f"{'max':>8s}"                                                                                                                                                                                                                         
            f"{'skew':>8s}" 
            f"{'kurt':>8s}"                                                                                                                                                                                                         
            f"{'p01':>8s}"                                                                                                                                                                                                                          
            f"{'p50':>8s}"                                                                                                                                                                                                                          
            f"{'p99':>8s}"   
            f"{'f <-5':>9s}"                                                                                                                                                                                                                         
            f"{'f <-10':>9s}"                                                                                                                                                                                                                        
            f"{'f <-20':>9s}"                                                                                                                                                                                                                        
            f"{'n <-5':>9s}"                                                                                                                                                                                                                         
            f"{'n <-10':>9s}"                                                                                                                                                                                                                        
            f"{'n <-20':>9s}"                                                                                                                                                                                                                                                                                                                                                                                                                                            
        ) 

        separator = "-" * len(header)

        lines = [header, separator]

        for name, mu, sigma, z in zip(cols, means, stds, X_train.T.to_numpy()):

            zmin = z.min()
            zmax = z.max()

            m = z.mean()
            s = z.std()
            if s>0:
                skewn = skew(z, bias=False)
                kurt = kurtosis(z, fisher=True, bias=False)   # normal = 0
            else:
                skewn = np.nan
                kurt = np.nan

            p01, p50, p99 = np.percentile(z, [1, 50, 99])

            frac5 = np.mean(z < -5)
            frac10 = np.mean(z < -10)
            frac20 = np.mean(z < -20)

            n5 = np.sum(z < -5)
            n10 = np.sum(z < -10)
            n20 = np.sum(z < -20)

            line = (                                                                                                                                                                                                                                  
                f"{name:15s}"                                                                                                                                                                                                                       
                f"{mu:8.3f}"                                                                                                                                                                                                                     
                f"{sigma:8.3f}"
                f"{zmin:8.2f}"                                                                                                                                                                                                                      
                f"{zmax:8.2f}"                                                                                                                                                                                                                      
                f"{skewn:8.2f}"                                                                                                                                                                                                                      
                f"{kurt:8.2f}"
                f"{p01:8.2f}"                                                                                                                                                                                                                       
                f"{p50:8.2f}"                                                                                                                                                                                                                       
                f"{p99:8.2f}"                                                                                                                                                                                                                       
                f"{frac5:9.2e}"                                                                                                                                                                                                                     
                f"{frac10:9.2e}"                                                                                                                                                                                                                    
                f"{frac20:9.2e}"                                                                                                                                                                                                                                                                                                                                                                                                                                     
                f"{n5:9.2e}"                                                                                                                                                                                                                     
                f"{n10:9.2e}"                                                                                                                                                                                                                    
                f"{n20:9.2e}"
            ) 

            lines.append(line)

        # Print to console
        report = "\n".join(lines)
        print(report)

        # Write to file
        filename  = self.dtb_folder + "/" + self.database_name + f"/dtb_statistics_report_{i_cluster}.txt"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(report)




    def print_data_size(self):

        # Cluster of each point: physical states (constant dt, clustering on "phys" or no clustering)
        labels = self.X["cluster"].values

        # Multi-dt clustering on "dt" or "all": one cluster per flattened (state, dt) point
        if self.clusterized_dataset and self.dt_var:
            if self.clusterize_on == "dt":
                labels = self.time_clusters
            elif self.clusterize_on == "all":
                labels = self.all_clusters

        # Printing number of elements for each class
        size_total = 0
        for i in range(self.nb_clusters):

            size_cluster_i = np.sum(labels==i)
            size_total += size_cluster_i

            print(f">> There are {size_cluster_i} points in cluster{i}")

        print(f"\n => There are {size_total} points overall")

    
    # Distribution plotting function
    def plot_distributions(self, X_train, X_val, Y_train, Y_val, species, i_cluster):

        # Number of collocations points for pdf
        n = 400
        
        # Computing PDF's
        x_train = np.linspace(X_train[species + "_X"].min(), X_train[species + "_X"].max(), n)
        pdf_X_train = utils.compute_pdf(x_train, X_train[species + "_X"])

        x_val = np.linspace(X_val[species + "_X"].min(), X_val[species + "_X"].max(), n)
        pdf_X_val = utils.compute_pdf(x_val, X_val[species + "_X"])

        if species!="Temperature":
            y_train = np.linspace(Y_train[species + "_Y"].min(), Y_train[species + "_Y"].max(), n)
            pdf_Y_train = utils.compute_pdf(y_train, Y_train[species + "_Y"])

            y_val = np.linspace(Y_val[species + "_Y"].min(), Y_val[species + "_Y"].max(), n)
            pdf_Y_val = utils.compute_pdf(y_val, Y_val[species + "_Y"])

        fig1, (ax1, ax2) = plt.subplots(ncols=2)
        fig2, (ax3, ax4) = plt.subplots(ncols=2)

        ax1.plot(x_train, pdf_X_train, color="k", lw=2)
        ax1.set_xlabel(f"{species} X $[-]$", fontsize=12)
        ax1.set_ylabel("pdf $[-]$", fontsize=12)
        #
        if species!="Temperature":
            ax2.plot(y_train, pdf_Y_train, color="k", lw=2)
            ax2.set_xlabel(f"{species} Y $[-]$", fontsize=12)
            ax2.set_ylabel("pdf $[-]$", fontsize=12)

        ax3.plot(x_val, pdf_X_val, color="k", lw=2)
        ax3.set_xlabel(f"{species} X $[-]$", fontsize=12)
        ax3.set_ylabel("pdf $[-]$", fontsize=12)
        #
        if species!="Temperature":
            ax4.plot(y_val, pdf_Y_val, color="k", lw=2)
            ax4.set_xlabel(f"{species} Y $[-]$", fontsize=12)
            ax4.set_ylabel("pdf $[-]$", fontsize=12)

        for ax in [ax1,ax2,ax3,ax4]:
            ax.ticklabel_format(axis="x", style="sci", scilimits=(0,0),useMathText=True)
            ax.ticklabel_format(axis="y", style="sci", scilimits=(0,0),useMathText=True)

            ax.xaxis.get_offset_text().set_fontsize(10)
            ax.yaxis.get_offset_text().set_fontsize(10)

            ax.tick_params(axis='both', which='major', labelsize=10)
            ax.tick_params(axis='both', which='minor', labelsize=8)

            ax.set_aspect(1.0/ax.get_data_ratio(), adjustable='box')

        fig1.tight_layout()
        fig2.tight_layout()

        fig1.savefig(self.dtb_folder + "/" + self.database_name + f"/distrib_{species}_train_cluster_{i_cluster}.png", dpi=300, bbox_inches='tight')
        fig2.savefig(self.dtb_folder + "/" + self.database_name + f"/distrib_{species}_val_cluster_{i_cluster}.png", dpi=300, bbox_inches='tight')

    def check_inputs(self):

        if self.log_transform_X==0 and self.log_transform_Y>0:
            sys.exit("ERROR: log_transform_Y cannot be active if log_transform_X==0 !")

        if self.rollout and self.dt_var:
            sys.exit("ERROR: rollout is done with a constant dt, it cannot be used with dt_var !")

    # 2-D joint PDF plotting of two variable
    def density_scatter(self, var_x , var_y, sort = True, bins = 100):
        # Functions from https://stackoverflow.com/questions/20105364/how-can-i-make-a-scatter-plot-colored-by-density-in-matplotlib

        # If variables are PC1 and PC2, we compute the PCA
        if var_x=="PC1" and var_y=="PC2":
            if not self.is_pca_computed:
                self.compute_pca()
            
        x = self.X[var_x]
        y = self.X[var_y]

        fig , ax = plt.subplots()
        data , x_e, y_e = np.histogram2d(x, y, bins = bins, density = False )
        z = interpn( ( 0.5*(x_e[1:] + x_e[:-1]) , 0.5*(y_e[1:]+y_e[:-1]) ) , data , np.vstack([x,y]).T , method = "splinef2d", bounds_error = False)

        # To be sure to plot all data
        z[np.where(np.isnan(z))] = 0.0

        # Sort the points by density, so that the densest points are plotted last
        if sort :
            idx = z.argsort()
            x, y, z = x[idx], y[idx], z[idx]

        ax.scatter(x, y, c=z)

        norm = Normalize(vmin = np.min(z), vmax = np.max(z))
        cbar = fig.colorbar(cm.ScalarMappable(norm = norm), ax=ax)
        cbar.ax.set_ylabel('Density')

        fig.tight_layout()

        if self.is_resampled:
            fig.savefig(os.path.join(self.dtb_folder, f"density_{var_x}_{var_y}_resampled.png"), dpi=400)
        else:
            fig.savefig(os.path.join(self.dtb_folder, f"density_{var_x}_{var_y}.png"), dpi=400)


    # Marginal PDF of a given variable in the dataframe
    def plot_pdf_var(self, var):

        if var=="PC1" or var=="PC2":
            if not self.is_pca_computed:
                self.compute_pca()
            
        # Temperature histogram
        fig, ax = plt.subplots()
        
        sns.histplot(data=self.X, x=var, ax=ax, stat="density",
                     binwidth=10, kde=False)

        ax.set_box_aspect(1)

        if var=="Temperature":
            ax.set_xlabel("$T$ $[K]$", fontsize=14)
        ax.set_ylabel("Point density $[-]$", fontsize=14)

        ax.legend(fontsize=10)

        fig.tight_layout()
        if self.is_resampled:
            fig.savefig(os.path.join(self.dtb_folder, f"distribution_{var}_resampled.png"), dpi=400)
        else:
            fig.savefig(os.path.join(self.dtb_folder, f"distribution_{var}.png"), dpi=400)



    # Compare
    def compare_resampled_pdfs(self, var): 

        if var=="PC1" or var=="PC2":
            if not self.is_pca_computed:
                self.compute_pca()

        if self.is_resampled is False:
            sys.exit("Data has not been resampled, this function is not accessible")
            
        # Temperature histogram
        fig, ax1 = plt.subplots()
        
        sns.histplot(data=self.X_old, x=var, ax=ax1, color="black", stat="density",
                     binwidth=10, kde=False, label="Before re-sampling")

        sns.histplot(data=self.X, x=var, ax=ax1, color="blue", stat="density",
                     binwidth=10, kde=False, alpha=0.4, label="After re-sampling")
        
        ax1.set_box_aspect(1)
        
        if var=="Temperature":
            ax1.set_xlabel("$T$ $[K]$", fontsize=14)
        ax1.set_ylabel("Point density $[-]$", fontsize=14)

        ax1.legend(fontsize=10)

        fig.tight_layout()
        fig.savefig(os.path.join(self.dtb_folder,"comparison_distribution.png"), dpi=400)

    # Compute PCA of database
    def compute_pca(self):

        # Number of PCA dimensions here forced to 2
        k = 2

        features = self.species_names.to_list()
        features.insert(0,"Temperature")
        if self.with_N_chemistry is False:
            features.remove("N2")

        # Get states only (temperature and Yk's)
        data = self.X[features].values

        # Scaling data
        pca_scaler = StandardScaler()
        pca_scaler.fit(data)
        data = pca_scaler.transform(data)

        # Performing PCA
        pca_algo = PCA(n_components=k, svd_solver="full")
        pca_algo.fit(data)
        PCs = pca_algo.transform(data)


        self.X["PC1"] = PCs[:,0]
        self.X["PC2"] = PCs[:,1]

        self.is_pca_computed = True


    def _estimate_lambda_boxcox(self, values):
        """Estimate Box–Cox lambda by MLE on a 1D array.

        values: array-like, strictly positive after thresholding.
        """
        values = np.asarray(values)
        # Remove non-positive or NaNs for safety
        values = values[np.isfinite(values)]
        values = values[values > 0.0]

        if values.size == 0:
            raise ValueError("No positive values available to estimate Box–Cox lambda.")

        lmbda = boxcox_normmax(values, method='mle')

        return lmbda