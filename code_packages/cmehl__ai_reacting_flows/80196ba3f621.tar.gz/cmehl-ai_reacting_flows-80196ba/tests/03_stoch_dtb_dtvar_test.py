"""
Test 03: multi-dt database generation.

Re-integrates the states of STOCH_DTB_TEST/solutions_resamp200K.h5 (session fixture h2_resampled_dtb,
see conftest.py) with 5 random time steps in [1e-7, 1e-6] s, and writes STOCH_DTB_TEST/mech_h2_5dt.h5.
Check: histograms of the outputs are close to the references in H2_dtvar_TEST_histograms/.
"""
from ai_reacting_flows.databases_processing.generate_var_dt_dtb import GenerateVariable_dt
from misc import extract_h2_dtvar_dtb_histograms
from h2_stoch_database import tests_dir, mech_file

import DummyComm as dc
import numpy as np
import os

#inlets
inlet_1 = {'type':'cold_premixed',
           'nb_particles': 450,
           'fuel': 'H2',
           'phi': 0.6,
           'T': 300.0,
           'P': 101325.0}
inlet_2 = {'type':'burnt_premixed',
           'nb_particles': 50,
           'fuel': 'H2',
           'phi': 0.6,
           'T': 300.0,
           'P': 101325.0}
inlets = {'inlet_1':inlet_1,
          'inlet_2':inlet_2}

# Dictionary to store inputs
data_gen_parameters = {}

# General parameters
data_gen_parameters["mech_file"] = mech_file      # Mechanism file
data_gen_parameters["inlets"] = inlets      # dict defining the stochastic reactors inlets
data_gen_parameters["results_folder_suffix"] = "TEST"    # Name of the resulting database (used as a suffix of "STOCH_DTB")
data_gen_parameters["dtb_file"] = "solutions_resamp200K.h5" #
data_gen_parameters["build_ml_dtb"] = True     # Flag to generate ML database or do a stand-alone simulation
data_gen_parameters["time_step"] = 5.0e-6       # Constant time step of the simulation
data_gen_parameters["time_max"] = 1e-3          # Simulation end time

# Multiple dt parameters
data_gen_parameters['time_step_type'] = 'random'  # set or random, if 'set': input the values of dt in a table. If 'random' : input the range (min and max)
data_gen_parameters['time_step_range'] = [0.1e-6, 1e-6]
data_gen_parameters['nb_dt'] = 5 # number of dt to choose in the range for each data point (only if time_step_type = 'random')
data_gen_parameters['new_file_name'] = f"mech_h2_{data_gen_parameters['nb_dt']}dt.h5"

# Modeling parameters
data_gen_parameters["mixing_model"] = "CURL_MODIFIED"         # Mixing model (CURL or CURL_MODIFIED)
data_gen_parameters["mixing_time"] = 1.0e-4                 # Mixing time-scale
data_gen_parameters["read_mixing"] = True                 # Use pre-computed mixing pairs
data_gen_parameters["T_threshold"] = 200.0                  # Temperature threshold for database
data_gen_parameters["pv_species"] = ["H2O"]                 # Species used to define progress variable

# post-processing parameters
data_gen_parameters["calc_mean_traj"] = False              # Flag to decide if mean trajectories are computed in the post-processing step

# ML inference
data_gen_parameters["ML_inference_flag"] = False
data_gen_parameters["prog_var_thresholds"] = (0.25, 0.95)

def test_h2_multi_dt_dtb_computation(h2_resampled_dtb):
    os.chdir(h2_resampled_dtb)

    GenerateVariable_dt("stoch", data_gen_parameters, dc.DummyComm())

    tol = np.array([168.86, 8.89, 50.17, 20.32, 139.32, 52.21, 61.66, 13.04, 11.16])
    assert np.max(extract_h2_dtvar_dtb_histograms(f"./STOCH_DTB_{data_gen_parameters['results_folder_suffix']:s}/mech_h2_5dt.h5", os.path.join(tests_dir, "H2_dtvar_TEST_histograms"), tol)) < np.float64(0.0)