import torch
import numpy as np
import random

def set_seed(seed):
    # Set the seed for Python's built-in random module
    random.seed(seed)

    # Set the seed for NumPy
    np.random.seed(seed)

    # Set the seed for PyTorch
    torch.manual_seed(seed)

    # If using CUDA, set the seed for all GPUs (if available)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


def normer_D(Y, G):
    Y_new, G_new = Y.clone(), G.clone()
    Y_new[:,:,0] = (Y[:,:,0] - 2) / (60 - 2) # t
    Y_new[:,:,1] = (Y[:,:,1] - 0) / (0.005 - 0) # x
    G_new[:,:,0] = (G[:,:,0] - 300) / (1200 - 300) # T # low T->0 high T-> 1
    # G_new[:,:,1] = (G[:,:,1] - 0) / (0.45 - 0) * \
    #     torch.exp(G[:,:,0-1)
    G_new[:,:,1] = (G[:,:,1] - 0) / (0.45 - 0) * torch.exp(G_new[:,:,0]-1)
    G_new[:,:,2] = (np.log((G[:,:,2]+0.001) / (0.34+0.001)) - np.log((0.0001)/(0.341)))/\
        (np.log((0.341)/(0.341)) - np.log((0.0001)/(0.341)))
    return Y_new, G_new

def loadout(data):
    # Load the datasets
    train_dataset, test_dataset = data['train'], data['test']

    # To access the tensors in the train set:
    train_U, train_Y, train_G = [], [], []
    for U, Y, G in train_dataset:
        train_U.append(U)
        train_Y.append(Y)
        train_G.append(G)

    train_U = torch.stack(train_U)
    train_Y = torch.stack(train_Y)
    train_G = torch.stack(train_G)

    # To access the tensors in the test set:
    test_U, test_Y, test_G = [], [], []
    for U, Y, G in test_dataset:
        test_U.append(U)
        test_Y.append(Y)
        test_G.append(G)

    test_U = torch.stack(test_U)
    test_Y = torch.stack(test_Y)
    test_G = torch.stack(test_G)

    return train_U, train_Y, train_G, test_U, test_Y, test_G

# 45
def rand_1d_pred_45(Y_x, Nx=3, Nt=15):
    # Y_x size: [cases, points] stors x information
    # real sensors are 15, here we select 30 points to deal with interpolation on the x side.
    # x sensors are 0.2, 0.5, 0.8 (after normalization)
    # t sensors are 40, 100, 160, 220, 280
    # t_indices = np.array([40, 100, 160, 220, 280])
    # t_seq = np.array([1, 2, 4, 7, 10])
    t_seq = np.array([0, 1, 2, 3, 4, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42])
    t_indices = t_seq * 2
    indices = np.zeros([Y_x.size(0), Nx*Nt*2])
    # print(Y_x)
    # indices here include the information of both t and x.
    # print(Y_x[0,:122])
    for i in range(Y_x.size(0)):
        idi = 0
        for t in range(291):
            if t in t_indices:
                sweep = 0
                for x in range(122):
                    temp = t*122+x
                    if Y_x[i,temp] <= 0.8 and sweep == 0:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1
                        continue
                    if Y_x[i,temp] <= 0.5 and sweep == 1:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1
                        continue
                    if Y_x[i,temp] <= 0.2 and sweep == 2:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1

    return torch.Tensor(indices).to(torch.int64).unsqueeze(-1)

# 15
def rand_1d_pred_15(Y_x, Nx=1, Nt=15):
    # Y_x size: [cases, points] stors x information
    # real sensors are 15, here we select 30 points to deal with interpolation on the x side.
    # x sensors are 0.2, 0.5, 0.8 (after normalization)
    # t sensors are 40, 100, 160, 220, 280
    # t_indices = np.array([40, 100, 160, 220, 280])
    # t_seq = np.array([1, 2, 4, 7, 10])
    t_seq = np.array([0, 1, 2, 3, 4, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42])
    t_indices = t_seq * 2
    indices = np.zeros([Y_x.size(0), Nx*Nt*2])
    # print(Y_x)
    # indices here include the information of both t and x.
    # print(Y_x[0,:122])
    for i in range(Y_x.size(0)):
        idi = 0
        for t in range(291):
            if t in t_indices:
                sweep = 0
                for x in range(122):
                    temp = t*122+x
                    if Y_x[i,temp] <= 0.8 and sweep == 0:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1

    return torch.Tensor(indices).to(torch.int64).unsqueeze(-1)

# 30
def rand_1d_pred_30(Y_x, Nx=2, Nt=15):
    # Y_x size: [cases, points] stors x information
    # real sensors are 15, here we select 30 points to deal with interpolation on the x side.
    # x sensors are 0.2, 0.5, 0.8 (after normalization)
    # t sensors are 40, 100, 160, 220, 280
    # t_indices = np.array([40, 100, 160, 220, 280])
    # t_seq = np.array([1, 2, 4, 7, 10])
    t_seq = np.array([0, 1, 2, 3, 4, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42])
    t_indices = t_seq * 2
    indices = np.zeros([Y_x.size(0), Nx*Nt*2])
    # print(Y_x)
    # indices here include the information of both t and x.
    # print(Y_x[0,:122])
    for i in range(Y_x.size(0)):
        idi = 0
        for t in range(291):
            if t in t_indices:
                sweep = 0
                for x in range(122):
                    temp = t*122+x
                    if Y_x[i,temp] <= 0.8 and sweep == 0:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1
                        continue
                    if Y_x[i,temp] <= 0.5 and sweep == 1:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1

    return torch.Tensor(indices).to(torch.int64).unsqueeze(-1)

# 90
def rand_1d_pred_90(Y_x, Nx=3, Nt=30):
    # Y_x size: [cases, points] stors x information
    # real sensors are 15, here we select 30 points to deal with interpolation on the x side.
    # x sensors are 0.2, 0.5, 0.8 (after normalization)
    # t sensors are 40, 100, 160, 220, 280
    # t_indices = np.array([40, 100, 160, 220, 280])
    # t_seq = np.array([1, 2, 4, 7, 10])
    t_seq = np.array([0, 1, 2, 3, 4, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42,\
                      46, 50, 54, 58, 62, 66, 74, 82, 90, 98, 106, 114, 122, 130, 138])
    t_indices = t_seq * 2
    indices = np.zeros([Y_x.size(0), Nx*Nt*2])
    # print(Y_x)
    # indices here include the information of both t and x.
    # print(Y_x[0,:122])
    for i in range(Y_x.size(0)):
        idi = 0
        for t in range(291):
            if t in t_indices:
                sweep = 0
                for x in range(122):
                    temp = t*122+x
                    if Y_x[i,temp] <= 0.8 and sweep == 0:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1
                        continue
                    if Y_x[i,temp] <= 0.5 and sweep == 1:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1
                        continue
                    if Y_x[i,temp] <= 0.2 and sweep == 2:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1

    return torch.Tensor(indices).to(torch.int64).unsqueeze(-1)

# 60
def rand_1d_pred_60(Y_x, Nx=3, Nt=20):
    # Y_x size: [cases, points] stors x information
    # real sensors are 15, here we select 30 points to deal with interpolation on the x side.
    # x sensors are 0.2, 0.5, 0.8 (after normalization)
    # t sensors are 40, 100, 160, 220, 280
    # t_indices = np.array([40, 100, 160, 220, 280])
    # t_seq = np.array([1, 2, 4, 7, 10])
    t_seq = np.array([0, 1, 2, 3, 4, 6, 10, 14, 18, 22, 26, 30, 34, 38, 42, \
                      46, 50, 54, 58, 62])
    t_indices = t_seq * 2
    indices = np.zeros([Y_x.size(0), Nx*Nt*2])
    # print(Y_x)
    # indices here include the information of both t and x.
    # print(Y_x[0,:122])
    for i in range(Y_x.size(0)):
        idi = 0
        for t in range(291):
            if t in t_indices:
                sweep = 0
                for x in range(122):
                    temp = t*122+x
                    if Y_x[i,temp] <= 0.8 and sweep == 0:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1
                        continue
                    if Y_x[i,temp] <= 0.5 and sweep == 1:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1
                        continue
                    if Y_x[i,temp] <= 0.2 and sweep == 2:
                        indices[i,idi], indices[i,idi+1] = temp, temp-1
                        idi += 2
                        sweep += 1

    return torch.Tensor(indices).to(torch.int64).unsqueeze(-1)