### `Output_Net` Directory

This directory stores the trained networks from the pre-training and downstream tasks. 
All networks are saved as `.pic` files containing the complete network that can be loaded.

### Note:

Existing files in these directories are for reference only and showcase the type of content stored.