
import io
import csv
import time
import numpy as np 

import torch
import torch.nn as nn
import torch.optim as optim
import pickle

from utils import set_seed
from torch import nn 
from constant import DataSplit 
from network import Direct_SensorToFeature, Finetuning_SensorToFeatures_MutualEncoding

device_ids = [0]
device = torch.device(f"cuda:{device_ids[0]}" if torch.cuda.is_available() else "cpu")
seed = 1024
set_seed(seed) # 3407, 42, 1234, 13, 1024

#__________________________PARAMETERS_________________________________
field_names = ['T', 'Y_cellulose', 'u']
n_fields    = len(field_names)
N_EPOCH     = 1000000
N_REPORT    = 10
Case_Num    = 60

EVALUATE     = True
n_field_info = 12
n_baseF      = 40
n_cond       = 3 #Length of the condition vector in U

field_idx    = 0 # The field used for sparse reconstruction
N_selected   = 90 # Points selected for sparse reconstruction
N_P_Selected = 2000 # points to evaluate performances
#Transformer layer parameters
num_heads    = 6
num_layers   = 1

Unifed_weight = 5.0

hidden_sizes = [500,500]
NET_TYPE = int(0) 
                # 0 = [Mutual_Representation_PreTrain_Net]; 1 = [Direct_SensorToFeature]
NET_SETTINGS = f'Selecting {N_selected} random sensors from {field_names[field_idx]} to recover the latent features\thidden_sizes = {hidden_sizes}\n'
NET_NAME = [f'MutualEncoding_SensorToFeature_N{N_selected}_LoadFeature', f'Direct_SensorToFeature_N{N_selected}']

PreTrained_Net_Name = 'MutualEncoding_{}{}'.format(seed,Case_Num)
Load_file_path = 'Output_Net/{}.pic'.format(PreTrained_Net_Name)

def get_data_iter(U, Y, G, Yin, Gin, batch_size = 360): # random sampling in each epoch
    num_examples = len(U)
    num_points = Y.shape[1]
    indices = list(range(num_examples))
    for i in range(0, num_examples, batch_size):
        j = torch.LongTensor(indices[i: min(i + batch_size, num_examples)]) 
        j = j.to(device)

        selected_points = torch.randperm(num_points)[:N_P_Selected].to(device)
        yield  U.index_select(0, j), Y.index_select(0, j).index_select(1, selected_points), G.index_select(0, j).index_select(1, selected_points), Yin.index_select(0, j), Gin.index_select(0, j)

def custom_mse_loss(output, target, field_weights):

    num_fields = target.size(-1)
    total_loss = 0
    field_losses = torch.zeros(num_fields)

    for id in range(num_fields):
        field_output = output[:, :, id]
        field_target = target[:, :, id]
        
        field_loss = torch.mean((field_output - field_target) ** 2)
        field_losses[id] = field_loss.item()
        total_loss += field_weights[id] * field_loss

    return total_loss, field_losses

if __name__ == '__main__':

    with open(f'Loss_csv/train_test_loss_reconstruction/train_test_loss_S2F_{NET_NAME[NET_TYPE]}.csv', 'wt') as fp: 
        pass

    if EVALUATE is True:
        with open(f'Loss_csv/train_test_loss_reconstruction/Reconstruct_loss_{NET_NAME[NET_TYPE]}.csv', 'wt') as fp:
            pass
    with open(Load_file_path, 'rb') as fp:
        PreTrained_net = pickle.load(fp).to(device)

    for id in range(len(field_names) + 1):
        field_name_or_feature = 'Unified' if id == len(field_names) else field_names[id]
        file_path = f'LatentRepresentation/FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}.csv'
        
        # Open the CSV file for reading
        try:
            with open(file_path, 'rt') as fp:
                reader = csv.reader(fp)
                next(reader)  # Skip the first row (header)
                second_row = next(reader)  # Read the second row
                
        except Exception as e:
            print(f"Failed to process {file_path}: {str(e)}")

    field_info_train_tensors = {}
    field_info_test_tensors = {}
    # Load the dataset of all fields & Randomly pick-out sensor points for the selected Field_idx
    with open(f'data_split/data_split_MutualEncoding_Features_{field_idx}_{N_selected}.pic', 'rb') as fp: 
        data_split = pickle.load(fp)

        U_train          = data_split.U_train.to(device)
        Y_train          = data_split.Y_train.to(device)
        G_train          = data_split.G_train.to(device)

        Gin_train  		 = data_split.Gin_train.to(device)  		
        Yin_train   	 = data_split.Yin_train.to(device)

        LR_T_train  	 = data_split.LR_T_train.to(device)
        field_info_train_tensors[f'field_info_T'] = LR_T_train

        LR_Y_cellulose_train  	 = data_split.LR_Y_cellulose_train.to(device)
        field_info_train_tensors[f'field_info_Y_cellulose'] = LR_Y_cellulose_train

        LR_u_train  	 = data_split.LR_u_train.to(device)
        field_info_train_tensors[f'field_info_u'] = LR_u_train

        LR_Unified_train = data_split.LR_Unified_train.to(device)

        U_test           = data_split.U_test.to(device)
        Y_test           = data_split.Y_test.to(device)
        G_test           = data_split.G_test.to(device)

        Gin_test  		 = data_split.Gin_test.to(device)  		
        Yin_test   	 	 = data_split.Yin_test.to(device)  

        LR_T_test  	 = data_split.LR_T_test.to(device)
        field_info_test_tensors[f'field_info_T'] = LR_T_test

        LR_Y_cellulose_test  	 = data_split.LR_Y_cellulose_test.to(device)
        field_info_test_tensors[f'field_info_Y_cellulose'] = LR_Y_cellulose_test

        LR_u_test 	 = data_split.LR_u_test.to(device)
        field_info_test_tensors[f'field_info_u'] = LR_u_test

        LR_Unified_test  = data_split.LR_Unified_test.to(device)

        n_inputF = U_train.shape[-1]
        n_pointD = Y_train.shape[-1]

    # Define the network
    if (NET_TYPE == 0):
        layer_sizes = [n_field_info * 3] + hidden_sizes + [n_field_info]  
        net = Finetuning_SensorToFeatures_MutualEncoding(layer_sizes, PreTrained_net).to(device)
        # Fix the parameters in the petrained net
        for param in net.PreTrained_net.parameters():
            param.requires_grad = False
    elif (NET_TYPE == 1): # Directly map the sensor values to the latent space
        layer_sizes = [N_selected*2] + hidden_sizes + [n_field_info]  # *2 here for the double pseudo sensors due to the dynamic mesh
        net = Direct_SensorToFeature(layer_sizes).to(device)
    else:
        print('Net is not correctly defined !!!')
        exit()

    # Wrap the model with DataParallel
    net = nn.DataParallel(net, device_ids=device_ids)
    optimizer = optim.Adam(net.parameters(), lr=0.0001) # , weight_decay=5.0E-5

    # Set up early stopping parameters
    patience = 250
    best_combined_loss = float('5.0') #Initial threshold to determine early stopping
    counter = 0
    train_loss_weight = 0.15
    test_loss_weight = 0.85
    criterion = nn.MSELoss(reduction='mean')
    criterion = nn.CosineEmbeddingLoss()

    field_weights = torch.tensor([1.0] * 3)  # Replace with actual weights if needed
    field_weights = field_weights.to(device)

    for epoch in range(N_EPOCH):

        train_loss   = 0
        train_losses = torch.zeros(len(field_names)+1, device=device)
        test_loss    = 0
        test_losses  = torch.zeros(len(field_names)+1, device=device)

        Total_Field_train_loss_Data = 0.0
        Total_Field_test_loss_Data  = 0.0
        Field_train_loss = torch.zeros(len(field_names), device=device)  # [len(field_names), len(field_names)]
        Field_test_loss  = torch.zeros(len(field_names), device=device)  # [len(field_names), len(field_names)]

        train_batch_count = 0
        test_batch_count  = 0

        start_time = time.time()  # Start time measurement

        for U, Y, G, Yin, Gin in get_data_iter(U_train, Y_train, G_train, Yin_train, Gin_train):
            loss = 0.0
            optimizer.zero_grad()

            #----------------------------
            # Entering the training phase:
            #----------------------------
            if (NET_TYPE == 0):
                Predicted_Features, Unified_Feature_output = net(Yin, Gin, num_heads)
            elif (NET_TYPE == 1):
                Unified_Feature_output = net(Yin, Gin,)
            else:
                print('Net is not correctly defined !!!')
                exit()

            for id in range( len(field_names) ):
                field_output = Predicted_Features[:, :, id]
                field_target = field_info_train_tensors[f'field_info_{field_names[id]}']
                
                # where loss is calculated
                t0 = torch.ones(field_output.size(0)).to(device)
                field_loss = criterion(field_output, field_target, t0)


                train_losses[id] = field_loss.item()
                
                train_loss += field_loss
                loss += field_weights[id] * field_loss

            # where loss is calculated
            t0 = torch.ones(Unified_Feature_output.size(0)).to(device)
            mse_loss_Unifed_train = criterion(Unified_Feature_output, LR_Unified_train, t0)
            train_losses[ len(field_names) ] = mse_loss_Unifed_train
            train_loss += mse_loss_Unifed_train
            loss += Unifed_weight *mse_loss_Unifed_train 

            loss.backward()
            optimizer.step()

            if EVALUATE is True and (epoch + 1) % N_REPORT == 0:
                with torch.no_grad():
                    # Evaluate the field-reconstruction performance in the training set
                    baseF = PreTrained_net.module.PosNet(Y)
                    DeNormalized_train_output = Unified_Feature_output

                    Global_Unified_field_outputs = []
                    for field_name, field_net in PreTrained_net.module.field_nets.items(): # Generate all the fields
                        coef = field_net(DeNormalized_train_output)
                        combine = coef * baseF
                        Global_Unified_field_output = torch.sum(combine, dim=2, keepdim=True)
                        Global_Unified_field_outputs.append(Global_Unified_field_output)
                    Global_Unified_Gout = torch.cat(Global_Unified_field_outputs, dim=-1) #   All the field_idx(th) field results from Global_Unified_U

                    field_loss_data, field_losses = custom_mse_loss(Global_Unified_Gout, G, field_weights)
                    Total_Field_train_loss_Data += field_loss_data
                    for j, loss_item in enumerate(field_losses):
                        Field_train_loss[j] += loss_item

            train_batch_count += 1
        train_loss /= train_batch_count
        train_losses /= train_batch_count
        Total_Field_train_loss_Data /= train_batch_count
        Field_train_loss /= train_batch_count

        #----------------------------
        #   Entering the test phase:
        #----------------------------
        with torch.no_grad():  
            for U, Y, G, Yin, Gin in get_data_iter(U_test, Y_test, G_test, Yin_test, Gin_test):
                if (NET_TYPE == 0):
                    Predicted_Features, Unified_Feature_output = net(Yin, Gin, num_heads)
                    

                elif (NET_TYPE == 1):
                    Unified_Feature_output = net(Yin, Gin)
                else:
                    print('Net is not correctly defined !!!')
                    exit()

                for id in range( len(field_names) ):
                    field_output = Predicted_Features[:, :, id]
                    field_target = field_info_test_tensors[f'field_info_{field_names[id]}']

                    t0 = torch.ones(field_output.size(0)).to(device)
                    field_loss = criterion(field_output, field_target, t0)
                    test_losses[id] = field_loss.item()
                    
                    test_loss += field_loss
                
                t0 = torch.ones(Unified_Feature_output.size(0)).to(device)
                mse_loss_Unifed_test = criterion(Unified_Feature_output, LR_Unified_test, t0)
                test_losses[ len(field_names) ] = mse_loss_Unifed_test
                test_loss += mse_loss_Unifed_test

                if EVALUATE is True and (epoch + 1) % N_REPORT == 0:
                    baseF = PreTrained_net.module.PosNet(Y)
                    DeNormalized_test_output = Unified_Feature_output

                    Global_Unified_field_outputs = []
                    for field_name, field_net in PreTrained_net.module.field_nets.items(): # Generate all the fields
                        coef = field_net(DeNormalized_test_output)
                        combine = coef * baseF
                        Global_Unified_field_output = torch.sum(combine, dim=2, keepdim=True)
                        Global_Unified_field_outputs.append(Global_Unified_field_output)
                    Global_Unified_Gout = torch.cat(Global_Unified_field_outputs, dim=-1) #   All the field_idx(th) field results from Global_Unified_U

                    field_loss_data, field_losses = custom_mse_loss(Global_Unified_Gout, G, field_weights)
                    Total_Field_test_loss_Data += field_loss_data
                    for j, loss_item in enumerate(field_losses):
                        Field_test_loss[j] += loss_item

                test_batch_count += 1
        test_loss /= test_batch_count
        test_losses /= test_batch_count
        Total_Field_test_loss_Data /= test_batch_count
        Field_test_loss /= test_batch_count

        if EVALUATE is False:
            combined_loss = train_loss_weight*mse_loss_Unifed_train + test_loss_weight*mse_loss_Unifed_test
        elif EVALUATE is True:
            combined_loss = train_loss_weight*Total_Field_train_loss_Data + test_loss_weight*Total_Field_test_loss_Data
        else:
            print(f'EVALUATE is {EVALUATE}, not correctly defined!!!')
            exit(0)

        end_time = time.time()  # End time measurement
        epoch_duration = end_time - start_time  # Calculate duration

        # Print and write to CSV 
        if (epoch + 1) % N_REPORT == 0:

            print(f'Epoch {epoch+1}/{N_EPOCH}, Duration: {epoch_duration:.4f} seconds')
            print()

            print(f'Epoch {epoch+1}/{N_EPOCH}, for feature retrieving, Train Loss: {train_loss.item()}, Test Loss: {test_loss.item()}')
            for id in range( len(field_names) ):
                print(f'Train Loss for field {field_names[id]}: {train_losses[id].item()}, Test Loss for field {field_names[id]}: {test_losses[id].item()}')
            print(f'Train Loss for Unifed feature: {train_losses[ len(field_names) ].item()}, Test Loss for Unifed feature: {test_losses[ len(field_names) ].item()}')
            print()

            if EVALUATE is True:
                print(f'Total Field Train Loss: {Total_Field_train_loss_Data.item()}, Total Field Test Loss: {Total_Field_test_loss_Data.item()}')
                for id, field_name in enumerate(field_names):
                    print(f'Train Loss for field {field_name}: {Field_train_loss[id].item()}, Test Loss for field {field_name}: {Field_test_loss[id].item()}')
                print()

                with open(f'Loss_csv/train_test_loss_reconstruction/Reconstruct_loss_{NET_NAME[NET_TYPE]}.csv', 'at', newline='') as fp:
                    writer = csv.writer(fp, delimiter='\t')
                    if ((epoch + 1) // N_REPORT == 1):
                        header = ['Epoch', 'Overall_Train_Loss', 'Overall_Test_Loss']
                        interleaved_field_names = [fn for field_name in field_names for fn in (f'Train_{field_name}_loss', f'Test_{field_name}_loss')]
                        header.extend(interleaved_field_names)
                        writer.writerow(header)

                    row_data = [epoch + 1, Total_Field_train_loss_Data.item(), Total_Field_test_loss_Data.item()] 
                    # Combine train and test losses for each field into pairs
                    for field_train_loss, field_test_loss in zip(Field_train_loss, Field_test_loss):
                        row_data.append(f'{field_train_loss.item()}')
                        row_data.append(f'{field_test_loss.item()}')
                    writer.writerow(row_data)

            # Write to CSV file
            with open(f'Loss_csv/train_test_loss_reconstruction/train_test_loss_S2F_{NET_NAME[NET_TYPE]}.csv', 'at', newline='') as fp:
                writer = csv.writer(fp, delimiter='\t')
                if ((epoch + 1) // N_REPORT == 1):
                    fp.write(NET_SETTINGS)
                    header = ['Epoch', 'Train_Loss', 'Test_Loss']
                    interleaved_field_names = ['Train_Unifed_loss', 'Test_Unified_loss']
                    header.extend(interleaved_field_names)
                    interleaved_field_names = [fn for name in field_names + ['Unified_feature'] for fn in (f'Train_{name}_loss', f'Test_{name}_loss')]
                    header.extend(interleaved_field_names)
                    writer.writerow(header)
                
                row_data = [epoch + 1, train_loss.item(), test_loss.item()] + [train_losses[ len(field_names) ].item(), test_losses[ len(field_names) ].item()] + \
                            [item for pair in zip(train_losses.tolist(), test_losses.tolist()) for item in pair]
                writer.writerow(row_data)

            # Determine whether should trigger early stopping
            if ( combined_loss < best_combined_loss ):
                best_combined_loss = combined_loss
                best_T = Field_train_loss[0].item()
                best_Y = Field_train_loss[1].item()
                best_u = Field_train_loss[2].item()
                best_YY = Field_test_loss[1].item()
                print(f'Best combined loss so far is {best_combined_loss}, still improving, {best_T},{best_Y},{best_YY},{best_u}')
                counter = 0

                with open('Output_Net/{}.pic'.format(NET_NAME[NET_TYPE]), 'wb') as fp: 
                    pickle.dump(net, fp)
                    print('...Successfully Saved net.pic')
                    print()

            else:
                counter += 1
                print(f'Best combined loss so far is {best_combined_loss}, NOT further improving, {best_T},{best_Y},{best_YY},{best_u}')
                print(f'The counter for triggering early stopping is {counter}')
                print()
                if counter >= patience:
                    print("Early stopping triggered")
                    break

