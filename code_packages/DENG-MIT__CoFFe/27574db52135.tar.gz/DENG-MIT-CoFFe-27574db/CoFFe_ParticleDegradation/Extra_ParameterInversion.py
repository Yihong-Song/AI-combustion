import numpy as np
import torch
import torch.optim as optim
import torch.nn as nn
import pickle
import csv
from utils import set_seed
from network import MLP
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

device_ids = [1]
device = torch.device("cuda:1")

Case_Num = 24
epochs = 20000
L = np.zeros(6)
PreTrained_Net_Name = f'MutualEncoding_{Case_Num}'
field_name_or_feature = 'Unified'
file_path = f'LatentRepresentation/FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}.csv'


field_idx = 0
N_selected = 45
with open(f'data_split/data_split_MutualEncoding_Features_{Case_Num}_{field_idx}_{N_selected}.pic', 'rb') as fp: 
    data_split = pickle.load(fp)
    U_train = data_split.U_train.to(device)
    LR_Unified_train = data_split.LR_Unified_train.to(device)
    U_test = data_split.U_test.to(device)
    LR_Unified_test = data_split.LR_Unified_test.to(device)
    Gin_train = data_split.Gin_train.view(-1,N_selected*2).to(device)
    Gin_test = data_split.Gin_test.view(-1,N_selected*2).to(device)

print(U_train.size())
print(LR_Unified_train.size())
print(Gin_train.size())

maxU, minU = torch.zeros(3), torch.zeros(3)
for i in range(3):
    max1 = torch.max(U_train[:,i])
    max2 = torch.max(U_test[:,i])
    maxU[i] = torch.max(torch.Tensor([max1, max2]))

    min1 = torch.min(U_train[:,i])
    min2 = torch.min(U_test[:,i])
    minU[i] = torch.min(torch.Tensor([min1, min2]))

    U_train[:,i] = (U_train[:,i] - minU[i])/(maxU[i]-minU[i])
    U_test[:,i] = (U_test[:,i] - minU[i])/(maxU[i]-minU[i])

print(maxU, minU)

# MLP model
set_seed(42)

layer_size = [12, 128, 128, 3]
net = MLP(layer_size).to(device)
criterion = nn.MSELoss(reduction='mean')
optimizer = optim.Adam(net.parameters(), lr=0.0001)

def initialize_weights(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_uniform_(m.weight)  # For uniform distribution
        # nn.init.xavier_normal_(m.weight)  # For normal distribution, use this instead if needed
        if m.bias is not None:
            nn.init.zeros_(m.bias)

# Apply the initialization function to each layer
net.apply(initialize_weights)

for epoch in range(epochs):
    loss = 0.0
    optimizer.zero_grad()

    U_pred = net(LR_Unified_train)
    loss = criterion(U_pred, U_train)

    loss.backward()
    optimizer.step()
    if (epoch+1) % 500 == 0:
        print('Epoch {}: {:.4f}'.format(epoch+1, loss.detach().cpu().numpy()))

with torch.no_grad():
    U_test_pred = net(LR_Unified_test)

U_test_pred_1 = U_test_pred.cpu().numpy()
U_test_1 = U_test.cpu().numpy()

print('MLP')
mse = mean_squared_error(U_test_1, U_test_pred_1, multioutput='raw_values')
case_no = 10
print(sum(mse), U_test[case_no], U_test_pred[case_no])
L[0] = sum(mse)
print(f"Feature: Mean Squared Error for each output dimension: {mse}")

print(U_test[0], U_test_pred[0])

# sensor test
layer_size = [N_selected*2, 128, 128, 3]
net = MLP(layer_size).to(device)
criterion = nn.MSELoss(reduction='mean')
optimizer = optim.Adam(net.parameters(), lr=0.0001)
def initialize_weights(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_uniform_(m.weight)  # For uniform distribution
        if m.bias is not None:
            nn.init.zeros_(m.bias)

# Apply the initialization function to each layer
net.apply(initialize_weights)


for epoch in range(epochs):
    loss = 0.0
    optimizer.zero_grad()

    U_pred = net(Gin_train)
    loss = criterion(U_pred, U_train)

    loss.backward()
    optimizer.step()
    if (epoch+1) % 500 == 0:
        print('Epoch {}: {:.4f}'.format(epoch+1, loss.detach().cpu().numpy()))

with torch.no_grad():
    U_test_pred = net(Gin_test)

U_test_pred_1 = U_test_pred.cpu().numpy()
U_test_1 = U_test.cpu().numpy()

print('MLP')
mse = mean_squared_error(U_test_1, U_test_pred_1, multioutput='raw_values')
L[1] = sum(mse)
case_no = 10
print(sum(mse), U_test[case_no], U_test_pred[case_no])
print(f"Sensor: Mean Squared Error for each output dimension: {mse}")

print(U_test[0], U_test_pred[0])

############### Scikit models ##############

case_no = 10

U_train = U_train.cpu().numpy()
LR_Unified_train = LR_Unified_train.cpu().numpy()
U_test = U_test.cpu().numpy()
LR_Unified_test = LR_Unified_test.cpu().numpy()

model = LinearRegression()

model.fit(LR_Unified_train, U_train)

U_test_pred = model.predict(LR_Unified_test)
print('Linear Regression')
mse = mean_squared_error(U_test, U_test_pred, multioutput='raw_values')
print(f"Feature: Mean Squared Error for each output dimension: {mse}")

print(sum(mse), U_test[case_no], U_test_pred[case_no])
L[2] = sum(mse)

Gin_train = Gin_train.cpu().numpy()
Gin_test = Gin_test.cpu().numpy()
model = LinearRegression()

model.fit(Gin_train, U_train)

U_test_pred = model.predict(Gin_test)
print('Linear Regression')
mse = mean_squared_error(U_test, U_test_pred, multioutput='raw_values')
print(f"Sensor: Mean Squared Error for each output dimension: {mse}")

print(sum(mse), U_test[case_no], U_test_pred[case_no])
L[3] = sum(mse)

from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C

kernel = C(1.0, (1e-2, 1e2)) * RBF(1.0, (1e-2, 1e2))

# Initialize the GPR model with the defined kernel
gpr = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=10, alpha=1e-6)

# Train the GPR model
gpr.fit(LR_Unified_train, U_train)

# Predict on the test set
y_pred, y_std = gpr.predict(LR_Unified_test, return_std=True)

# Evaluate the model
print('GPR')
mse = mean_squared_error(U_test, y_pred, multioutput='raw_values')
print(f"Feature: Mean Squared Error for each output dimension: {mse}")

print(sum(mse), U_test[case_no], y_pred[case_no])
L[4] = sum(mse)
np.savetxt('GPR_F2C_U.txt',U_test)
np.savetxt('GPR_F2C_Y.txt',y_pred)

gpr = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=10, alpha=1e-6)

# Train the GPR model
gpr.fit(Gin_train, U_train)

# Predict on the test set
y_pred, y_std = gpr.predict(Gin_test, return_std=True)

# Evaluate the model
print('GPR')
mse = mean_squared_error(U_test, y_pred, multioutput='raw_values')
print(f"Sensor: Mean Squared Error for each output dimension: {mse}")

print(sum(mse), U_test[case_no], y_pred[case_no])
L[5] = sum(mse)
np.savetxt('GPR_S2C_U.txt',U_test)
np.savetxt('GPR_S2C_Y.txt',y_pred)

print('LR,GPR,MLP{} {:.4f} {:.4f} {:.4f}'.format(Case_Num,L[2],L[4],L[0]))






