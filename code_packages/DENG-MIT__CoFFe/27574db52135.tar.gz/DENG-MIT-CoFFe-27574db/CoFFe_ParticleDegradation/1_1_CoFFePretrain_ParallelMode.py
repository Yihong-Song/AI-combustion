
import io
import csv
import numpy as np 

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import pickle

from tqdm import tqdm
from torch import nn 
from constant import DataSplit 
from network import CoFFe_PreTrain_Net_ParallelMode
from utils import loadout, set_seed
from utils import normer_D as normer

# Specify the GPUs to use
device_ids = [0]
device = torch.device(f"cuda:{device_ids[0]}" if torch.cuda.is_available() else "cpu")
seed=1234
set_seed(seed)

#__________________________PARAMETERS_________________________________
N_EPOCH = 100000     # Expected total epoches, can set a large number
BATCH_SIZE = 180
num_p = 60           # The number of random sparse sensors in each pre-training epoch
n_field_info = 12    # The dimension of latent features to be extracted from fied distribution data
n_baseF = 40         # The dimension of output layers of DeepONet-based decoder

Unified_Weight = 5.0 # Contribution of the unified feature

# FieldAttention layer parameters
num_heads = 6
num_layers = 1

field_names = ['T', 'Y_cellulose', 'u']
NET_TYPE = int(0)

# You can put important nots here, will be recorded in the output loss file
NET_SETTINGS = f'Unified_Weight = {Unified_Weight}\tn_field_info = {n_field_info}\tMultiHeadAttention={num_heads} & layer={num_layers}\tn_baseF = {n_baseF}\n'
NET_NAME = 'ParallelMode_{}{}'.format(seed, num_p)

print('Points selected for training amounts to {}'.format(num_p))
print('Parallel Mode')
#____________________________________________________________________

def weights_init(m):
    if isinstance(m, nn.Linear):
        torch.nn.init.kaiming_uniform_(m.weight)
        if m.bias is not None:
            torch.nn.init.zeros_(m.bias)

def get_data_iter(U, Y, G, N_P_Selected = 600, batch_size = 101): # random sampling in each epoch
    num_examples = len(U)
    num_points = Y.shape[1]
    indices = list(range(num_examples))
    np.random.shuffle(indices)  
    for i in range(0, num_examples, batch_size):
        j = torch.LongTensor(indices[i: min(i + batch_size, num_examples)]) 
        j = j.to(device)

        selected_points = torch.randperm(num_points)[:N_P_Selected].to(device)
        yield  U.index_select(0, j), Y.index_select(0, j).index_select(1, selected_points), G.index_select(0, j).index_select(1, selected_points)

def field_custom_mse_loss(output, target, field_idx, field_weights):
    num_fields = target.size(-1)
    total_loss = 0
    weighted_total_loss = 0
    field_losses = torch.zeros(num_fields+1)

    for id in range(num_fields + 1):
        field_output = output[:, :, id] #   The reconstructed field_idx(th) field from id(th) field or Unified
        field_target = target[:, :, field_idx]  # Ground truth of the field_idx(th) field
        field_loss = torch.mean((field_output - field_target) ** 2)
        
        field_losses[id] = field_loss.item()
        total_loss += field_loss
        
        field_weight = field_weights[id] if id < len(field_names) else 5.0
        weighted_total_loss += field_weight * field_loss
    
    sorted_losses, sorted_indices = torch.sort(field_losses[:num_fields])

    return weighted_total_loss, total_loss, field_losses, sorted_indices.tolist()

def custom_mse_loss(output, target):

    num_fields = target.size(-1)
    total_loss = 0
    weighted_total_loss = 0
    field_losses = torch.zeros(num_fields)

    for field_idx in range(num_fields):
        field_output = output[:, :, field_idx]
        field_target = target[:, :, field_idx]
        field_loss = torch.mean((field_output - field_target) ** 2)
        
        field_losses[field_idx] = field_loss.item()
        total_loss += field_loss

    return total_loss, field_losses

if __name__ == '__main__':

    with open(f'Loss_csv/train_test_loss_Parallel/train_test_loss_{NET_NAME}.csv', 'wt') as fp:
        pass
    with open(f'Loss_csv/train_test_loss_Parallel/train_test_loss_{NET_NAME}_Unified.csv', 'wt') as fp:
        pass

    with open('data_split/data_split.pic', 'rb') as fp: 
        data_split = pickle.load(fp)
        U_train, Y_train, G_train, U_test, Y_test, G_test = loadout(data_split)
        
        Y_train, G_train = normer(Y_train, G_train)
        Y_test, G_test = normer(Y_test, G_test)

        U_train = U_train.to(device)
        Y_train = Y_train.to(device)
        G_train = G_train.to(device)

        U_test = U_test.to(device)
        Y_test = Y_test.to(device)
        G_test = G_test.to(device)

    field_weights_default = torch.tensor([1.0] * 3)  # Replace with modified weights if needed
    field_weights_default = field_weights_default.to(device)

    if (NET_TYPE == 0):
        net = CoFFe_PreTrain_Net_ParallelMode(n_field_info, n_baseF, num_heads, num_layers, num_fields=3).to(device)
    else:
        print('Net is not correctly defined !!!')
        exit()
    # Wrap the model with DataParallel 
    net = nn.DataParallel(net, device_ids=device_ids)
    net.apply(weights_init)

    optimizer = optim.Adam(net.parameters(), lr=0.00050)  
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.98, patience=2000, verbose=True, min_lr=0.0002)

    # Set up early stopping parameters
    patience = 500
    best_combined_loss = float('5.0') #Initial threshold to determine early stopping
    counter = 0
    train_loss_weight = 0.15
    test_loss_weight = 0.85

    for epoch in range(N_EPOCH):

        Total_train_loss_Data = 0 # the total losses from all generated fields from each field: Loss_T = Sigma(i) Sigma(j) Field_j(Generated from Field_i)
        Total_test_loss_Data = 0
        Total_train_loss_Data_Unified = 0 # the total losses from all generated fields from each field: Loss_T = Sigma(i) Sigma(j) Field_j(Generated from Field_i)
        Total_test_loss_Data_Unified = 0
        train_loss = torch.zeros(len(field_names), device=device)  # [len(field_names), len(field_names)]
        test_loss = torch.zeros(len(field_names), device=device)  # [len(field_names), len(field_names)]

        train_loss_Unified = torch.zeros(len(field_names), device=device)  # [len(field_names), len(field_names)]
        test_loss_Unified = torch.zeros(len(field_names), device=device)  # [len(field_names), len(field_names)]

        train_batch_count = 0
        test_batch_count = 0

        for U, Y, G in get_data_iter(U_train, Y_train, G_train, N_P_Selected=num_p):
            
            optimizer.zero_grad()
            loss = 0
            output_list = net(U, Y, G, num_heads)
            output_stacked = torch.stack(output_list, dim=0)
            output = output_stacked[0, :, :, :]
            output_Unified = output_stacked[1, :, :, :]
            
            loss_data, losses = custom_mse_loss(output, G)
            Total_train_loss_Data += loss_data
            loss += loss_data
            
            loss_data_Unified, losses_Unified = custom_mse_loss(output_Unified, G)
            Total_train_loss_Data_Unified += loss_data_Unified
            loss += Unified_Weight * loss_data_Unified

            for j, loss_item in enumerate(losses):
                train_loss[j] += loss_item
            for j, loss_item in enumerate(losses_Unified):
                train_loss_Unified[j] += loss_item
            
            loss.backward()            
            optimizer.step()
            scheduler.step(loss)
            train_batch_count += 1

        train_loss /= train_batch_count
        Total_train_loss_Data /= train_batch_count
        train_loss_Unified /= train_batch_count
        Total_train_loss_Data_Unified /= train_batch_count

        # Print and write to CSV 
        if (epoch + 1) % 20 == 0:

            with torch.no_grad():  # Make sure to use no_grad for evaluation in test phase
                for U, Y, G in get_data_iter(U_test, Y_test, G_test, N_P_Selected = 1000):
                    output_list = net(U, Y, G, num_heads)
                    output_stacked = torch.stack(output_list, dim=0)
                    output = output_stacked[0, :, :, :]
                    output_Unified = output_stacked[1, :, :, :]
                    
                    loss_data, losses = custom_mse_loss(output, G)
                    Total_test_loss_Data += loss_data
                    loss_data_Unified, losses_Unified = custom_mse_loss(output_Unified, G)
                    Total_test_loss_Data_Unified += loss_data_Unified

                    for j, loss_item in enumerate(losses):
                        test_loss[j] += loss_item
                    for j, loss_item in enumerate(losses_Unified):
                        test_loss_Unified[j] += loss_item
                    test_batch_count += 1
                
                test_loss /= test_batch_count
                Total_test_loss_Data /= test_batch_count
                test_loss_Unified /= test_batch_count
                Total_test_loss_Data_Unified /= test_batch_count
            
            combined_loss = train_loss_weight*Total_train_loss_Data_Unified + test_loss_weight*Total_test_loss_Data_Unified

            print(f'Epoch {epoch+1}/{N_EPOCH}, Total Train Loss: {Total_train_loss_Data.item()}, Total Test Loss: {Total_test_loss_Data.item()}')
            for field_idx, field_name in enumerate(field_names):
                print(f'Train Loss for {field_name}: {train_loss[field_idx].item()}, Test Loss for {field_name}: {test_loss[field_idx].item()}')
            print()
            print(f'Epoch {epoch+1}/{N_EPOCH}, Unified Total Train Loss: {Total_train_loss_Data_Unified.item()}, Unifed Total Test Loss: {Total_test_loss_Data_Unified.item()}')
            for field_idx, field_name in enumerate(field_names):
                print(f'Unified Train Loss for {field_name}: {train_loss_Unified[field_idx].item()}, Unified Test Loss for {field_name}: {test_loss_Unified[field_idx].item()}')

            # Write to CSV file
            with open(f'Loss_csv/train_test_loss_Parallel/train_test_loss_{NET_NAME}.csv', 'at', newline='') as fp:
                writer = csv.writer(fp, delimiter='\t')
                if ((epoch + 1) // 20 == 1):
                    fp.write(NET_SETTINGS)
                    header = ['Epoch', 'Overall_Train_Loss', 'Overall_Test_Loss']
                    interleaved_field_names = [fn for field_name in field_names for fn in (f'Train_{field_name}_loss', f'Test_{field_name}_loss')]
                    header.extend(interleaved_field_names)
                    writer.writerow(header)
                row_data = [epoch + 1, Total_train_loss_Data.item(), Total_test_loss_Data.item()] 
                
                for train_loss, test_loss in zip(train_loss, test_loss):
                    row_data.append(f'{train_loss.item()}')
                    row_data.append(f'{test_loss.item()}')
                writer.writerow(row_data)
            
            with open(f'Loss_csv/train_test_loss_Parallel/train_test_loss_{NET_NAME}_Unified.csv', 'at', newline='') as fp:
                writer = csv.writer(fp, delimiter='\t')
                if ((epoch + 1) // 20 == 1):
                    fp.write(NET_SETTINGS)
                    header = ['Epoch', 'Overall_Train_Loss', 'Overall_Test_Loss']
                    interleaved_field_names = [fn for field_name in field_names for fn in (f'Train_{field_name}_loss', f'Test_{field_name}_loss')]
                    header.extend(interleaved_field_names)
                    writer.writerow(header)
                row_data = [epoch + 1, Total_train_loss_Data_Unified.item(), Total_test_loss_Data_Unified.item()] 
                
                for train_loss, test_loss in zip(train_loss_Unified, test_loss_Unified):
                    row_data.append(f'{train_loss.item()}')
                    row_data.append(f'{test_loss.item()}')
                writer.writerow(row_data)

            # Determine whether should trigger early stopping every 200 epochs
            if ( combined_loss < best_combined_loss ):
                best_combined_loss = combined_loss
                print(f'Best combined loss so far is {best_combined_loss}, still improving')
                counter = 0
                
                with open('Output_Net/{}.pic'.format(NET_NAME), 'wb') as fp:
                    pickle.dump(net, fp)
                    print('...Saved net.pic')

            else:
                counter += 1
                print(f'Best combined loss so far is {best_combined_loss}, NOT further improving')
                print(f'The counter for triggering early stopping is {counter}\n')
                if counter >= patience:
                    print("Early stopping triggered")
                    break