
import torch
from dataclasses import dataclass

@dataclass
class DataSplit:
	U_train  : torch.Tensor
	U_test   : torch.Tensor
	Y_train  : torch.Tensor
	Y_test   : torch.Tensor
	G_train  : torch.Tensor
	G_test   : torch.Tensor

@dataclass
class DataSplit_F:
	U_train  		 : torch.Tensor
	U_test   		 : torch.Tensor
	Y_train  		 : torch.Tensor
	Gin_train  		 : torch.Tensor
	Yin_train   	 : torch.Tensor
	LR_T_train  	 : torch.Tensor
	LR_Y_cellulose_train  	 : torch.Tensor
	LR_u_train  	 : torch.Tensor
	LR_Unified_train : torch.Tensor

	Y_test   		 : torch.Tensor
	G_train  		 : torch.Tensor
	G_test   		 : torch.Tensor
	Gin_test  		 : torch.Tensor
	Yin_test   	 	 : torch.Tensor
	LR_T_test  	 	 : torch.Tensor
	LR_Y_cellulose_test  	 	 : torch.Tensor
	LR_u_test  	 : torch.Tensor
	LR_Unified_test  : torch.Tensor