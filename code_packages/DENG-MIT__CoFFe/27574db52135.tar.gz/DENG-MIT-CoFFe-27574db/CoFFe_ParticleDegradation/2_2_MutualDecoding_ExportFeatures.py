
import numpy as np
import csv
import torch
import pickle
from constant import DataSplit_F
from utils import loadout, set_seed
from utils import normer_D as normer 
from utils import rand_1d_pred_90 as rand_1d

# Specify the GPUs to use
device_ids = [0]
device = torch.device(f"cuda:{device_ids[0]}" if torch.cuda.is_available() else "cpu")
seed=1234
set_seed(seed)

#__________________________PARAMETERS_________________________________

# Set the neccessary parameters based on the corresponding pre-training task

N_EPOCH = 100000     # Expected total epoches, can set a large number
n_field_info = 12    # The dimension of latent features to be extracted from fied distribution data
n_baseF = 40         # The dimension of output layers of DeepONet-based decoder

num_p = 60           # The number of random sparse sensors in each pre-training epoch
N_selected = 90      # selected points to generate features
Unified_Weight = 5.0 # Contribution of the unified feature
N_P_Selected = 1000  # Number of selected points to calculate field losses

# FieldAttention layer parameters
num_heads = 6
num_layers = 1

field_idx = 0        # The selected field for sparse reconstruction
field_names = ['T', 'Y_cellulose', 'u']
n_fields = len(field_names)
EVALUATION = True

PreTrained_Net_Name = 'MutualDecoding_{}{}'.format(seed,num_p)
Load_file_path = 'Output_Net/{}.pic'.format(PreTrained_Net_Name)

outFile = f'data_split/data_split_MutualDecoding_Features_{field_idx}_{N_selected}.pic'
#____________________________________________________________________

def get_data_iter(U, Y, G, Yin, Gin, batch_size = 360): # random sampling in each epoch
    # batch_size larger than the whole case
    num_examples = len(U)
    num_points = Y.shape[1]
    indices = list(range(num_examples))
    # np.random.shuffle(indices)  
    for i in range(0, num_examples, batch_size):
        j = torch.LongTensor(indices[i: min(i + batch_size, num_examples)]) 
        j = j.to(device)

        selected_points = torch.randperm(num_points)[:N_P_Selected].to(device) # evaluate points
        yield  U.index_select(0, j), Y.index_select(0, j).index_select(1, selected_points), G.index_select(0, j).index_select(1, selected_points), Yin.index_select(0, j), Gin.index_select(0, j)

def custom_mse_loss(output, target, field_weights):

    num_fields = target.size(-1)
    total_loss = 0
    field_losses = torch.zeros(num_fields)

    for id in range(num_fields):
        field_output = output[:, :, id]
        field_target = target[:, :, id]
        
        field_loss = torch.mean((field_output - field_target) ** 2)
        field_losses[id] = field_loss.item()
        total_loss += field_weights[id] * field_loss

    return total_loss, field_losses

if __name__ == '__main__':

    for id in range(len(field_names) + 1):
        field_name_or_feature = 'Unified' if id == len(field_names) else field_names[id]
        with open(f'LatentRepresentation/FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}.csv', 'wt') as fp: 
            pass

    with open(Load_file_path, 'rb') as fp:
        PreTrained_net = pickle.load(fp).to(device)

    field_weights = torch.tensor([1.0] * 3)  
    field_weights = field_weights.to(device)

    # Load the dataset of all fields
    with open('data_split/data_split.pic', 'rb') as fp: 
        data_split = pickle.load(fp)
        print(device)
        U_train, Y_train, G_train, U_test, Y_test, G_test = loadout(data_split)
        
        Y_train, G_train = normer(Y_train, G_train)
        Y_test, G_test = normer(Y_test, G_test)

        U_train = U_train.to(device)
        Y_train = Y_train.to(device)
        G_train = G_train.to(device)

        U_test = U_test.to(device)
        Y_test = Y_test.to(device)
        G_test = G_test.to(device)

        n_inputF = U_train.shape[-1]
        n_pointD = Y_train.shape[-1]

        Y_select_indices = rand_1d(Y_train[:,:,1]).to(device)
        Y_select_indices_test = rand_1d(Y_test[:,:,1]).to(device)

        Yin_train = Y_train.gather(1, Y_select_indices.expand(-1,-1,2))
        Yin_test = Y_test.gather(1, Y_select_indices_test.expand(-1,-1,2))

        print('Y_train.shape = ', Y_train.shape)
        print('Yin_train.shape = ', Yin_train.shape)
 
        Gin_train = G_train.gather(1, Y_select_indices.expand(-1,-1,3))[...,field_idx].unsqueeze(-1)
        Gin_test = G_test.gather(1, Y_select_indices_test.expand(-1,-1,3))[...,field_idx].unsqueeze(-1)
        print('G_train.shape = ', G_train.shape)
        print('Gin_Train.shape = ', Gin_train.shape)
    
    with torch.no_grad():
        for U, Y, G, Yin, Gin in get_data_iter(U_train, Y_train, G_train, Yin_train, Gin_train):

            baseF = PreTrained_net.module.PosNet(Y)   #   [n_batch, np_selected, n_dim -> n_base]
            FieldInfo_train = PreTrained_net.module._compress_data(baseF, G, num_heads)

            norm_UU = torch.norm(FieldInfo_train, p=2, dim=1, keepdim=True)
            FieldInfo_train = FieldInfo_train/norm_UU

            print('In train set, FieldInfo_train.shape is ', FieldInfo_train.shape)
            Unified_FieldInfo_train = PreTrained_net.module.FinalMerge(FieldInfo_train)   #   [n_batch, n_field_info]
            print('In train set, Unified_FieldInfo_train.shape is ', Unified_FieldInfo_train.shape)

            if EVALUATION is True:
                Total_Field_train_loss_Data = 0.0
                Field_train_loss = torch.zeros(len(field_names), device=device)  # [len(field_names), len(field_names)]

                Unified_field_outputs = []   # This means, the field output is decoded from the "Unified" feature
                for field_name, field_net in PreTrained_net.module.field_nets.items(): # Generate all the fields
                    coef = field_net(Unified_FieldInfo_train)
                    combine = coef * baseF
                    Unified_field_output = torch.sum(combine, dim=2, keepdim=True)
                    Unified_field_outputs.append(Unified_field_output)
                Unified_Gout_train = torch.cat(Unified_field_outputs, dim=-1) #   All the field_idx(th) field results from Unified_U

                field_loss_data, field_losses = custom_mse_loss(Unified_Gout_train, G, field_weights)
                Total_Field_train_loss_Data = field_loss_data
                for j, loss_item in enumerate(field_losses):
                    Field_train_loss[j] = loss_item                

                print(f'Total Field Train Loss: {Total_Field_train_loss_Data.item()}')
                for id, field_name in enumerate(field_names):
                    print(f'Train Loss for field {field_name}: {Field_train_loss[id].item()}')
                print()

        for U, Y, G, Yin, Gin in get_data_iter(U_test, Y_test, G_test, Yin_test, Gin_test):

            baseF = PreTrained_net.module.PosNet(Y)   #   [n_batch, np_selected, n_dim -> n_base]
            FieldInfo_test = PreTrained_net.module._compress_data(baseF, G, num_heads)
            norm_UU = torch.norm(FieldInfo_test, p=2, dim=1, keepdim=True)
            FieldInfo_test = FieldInfo_test/norm_UU

            print('In test set, FieldInfo_test.shape is ', FieldInfo_test.shape)
            Unified_FieldInfo_test = PreTrained_net.module.FinalMerge(FieldInfo_test)   #   [n_batch, n_field_info]
            print('In test set, Unified_FieldInfo_test.shape is ', Unified_FieldInfo_test.shape)

            if EVALUATION is True:
                Total_Field_test_loss_Data = 0.0
                Field_test_loss = torch.zeros(len(field_names), device=device)  

                Unified_field_outputs = [] 
                for field_name, field_net in PreTrained_net.module.field_nets.items(): 
                    coef = field_net(Unified_FieldInfo_test)
                    combine = coef * baseF
                    Unified_field_output = torch.sum(combine, dim=2, keepdim=True)
                    Unified_field_outputs.append(Unified_field_output)
                Unified_Gout_test = torch.cat(Unified_field_outputs, dim=-1) 

                field_loss_data, field_losses = custom_mse_loss(Unified_Gout_test, G, field_weights)
                Total_Field_test_loss_Data = field_loss_data
                for j, loss_item in enumerate(field_losses):
                    Field_test_loss[j] = loss_item                

                print(f'Total Field Test Loss: {Total_Field_test_loss_Data.item()}')
                for id, field_name in enumerate(field_names):
                    print(f'Test Loss for field {field_name}: {Field_test_loss[id].item()}')
                print()

    normalized_field_info_train_tensors = {}
    normalized_field_info_test_tensors  = {}

    for id in range(len(field_names) + 1):
        field_name_or_feature = 'Unified' if id == len(field_names) else field_names[id]
        
        info_train = Unified_FieldInfo_train if id == len(field_names) else FieldInfo_train[:, :, id]
        info_test  = Unified_FieldInfo_test  if id == len(field_names) else FieldInfo_test[:, :, id]

        if id == len(field_names): # For the global feature
            normalized_U_Unified_train = info_train
            normalized_U_Unified_test = info_test
        else:
            normalized_field_info_train_tensors[f'field_info_{field_names[id]}'] = info_train
            normalized_field_info_test_tensors[f'field_info_{field_names[id]}'] = info_test

        print(f'Successfully Normalized FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}!')

        with open(f'LatentRepresentation/FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}.csv', 'wt') as fp:

            # Standard csv.writer for writing the initial scalars row
            simple_writer = csv.writer(fp)
            fieldnames = ['U', 'field_info']
            writer = csv.DictWriter(fp, fieldnames=fieldnames)
            writer.writeheader()

            # Write data from the training set
            writer.writerow({'U': 'From training set:'})
            for i in range(U_train.shape[0]):
                row = {'U': U_train[i].cpu().numpy().tolist(),
                    'field_info': info_train[i].cpu().numpy().tolist()}
                writer.writerow(row)       
            writer.writerow({'U': 'From test set:'})
            for i in range(U_test.shape[0]):
                row = {'U': U_test[i].cpu().numpy().tolist(),
                    'field_info': info_test[i].cpu().numpy().tolist()}
                writer.writerow(row)
        print(f'Successfully export FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}.csv!\n')

    #   Export all the data to DataSplit for next-step training
    data_split = DataSplit_F(
            U_train          = U_train,
            Y_train          = Y_train,
            G_train          = G_train,
            Gin_train  		 = Gin_train,
            Yin_train   	 = Yin_train,
            LR_T_train  	 = normalized_field_info_train_tensors['field_info_T'],
            LR_Y_cellulose_train 	 = normalized_field_info_train_tensors['field_info_Y_cellulose'],
            LR_u_train  	 = normalized_field_info_train_tensors['field_info_u'],
            LR_Unified_train = normalized_U_Unified_train,

            U_test           = U_test,
            Y_test           = Y_test,
            G_test           = G_test,
            Gin_test  		 = Gin_test,
            Yin_test   	 	 = Yin_test,
            LR_T_test  	 = normalized_field_info_test_tensors['field_info_T'],
            LR_Y_cellulose_test 	 = normalized_field_info_test_tensors['field_info_Y_cellulose'],
            LR_u_test  	 = normalized_field_info_test_tensors['field_info_u'],
            LR_Unified_test  = normalized_U_Unified_test
        )

    with open(outFile, 'wb') as fp:
        pickle.dump(data_split, fp)
        print(f'...Data saved to Data_split {outFile} !!!')

