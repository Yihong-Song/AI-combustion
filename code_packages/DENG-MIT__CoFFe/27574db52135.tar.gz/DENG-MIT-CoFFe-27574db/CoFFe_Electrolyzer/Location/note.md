### `Location` Directory

This directory stores the intermediate variable in sensor optimization process, all stored in '.pth' format

#### pre:
The learning results 

#### post:
The optimized sensor ditribution

### Note:

Existing files in these directories are for reference only and showcase the type of content stored ! ! !