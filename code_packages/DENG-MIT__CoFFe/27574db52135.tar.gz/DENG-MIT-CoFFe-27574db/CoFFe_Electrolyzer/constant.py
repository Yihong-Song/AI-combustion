
import torch
from dataclasses import dataclass

@dataclass
class DataSplit:
	U_train  : torch.Tensor
	U_test   : torch.Tensor
	Y_train  : torch.Tensor
	Y_test   : torch.Tensor
	G_train  : torch.Tensor
	G_test   : torch.Tensor

@dataclass
class DataSplit_F:
	U_train  		 : torch.Tensor
	U_test   		 : torch.Tensor
	Y_train  		 : torch.Tensor
	Gin_train  		 : torch.Tensor
	Yin_train   	 : torch.Tensor
	LR_vof_train  	 : torch.Tensor
	LR_j_train  	 : torch.Tensor
	LR_velp1_train   : torch.Tensor
	LR_velp2_train   : torch.Tensor
	LR_Unified_train : torch.Tensor

	Y_test   		 : torch.Tensor
	G_train  		 : torch.Tensor
	G_test   		 : torch.Tensor
	Gin_test  		 : torch.Tensor
	Yin_test   	 	 : torch.Tensor
	LR_vof_test  	 : torch.Tensor
	LR_j_test  	 : torch.Tensor
	LR_velp1_test   : torch.Tensor
	LR_velp2_test   : torch.Tensor
	LR_Unified_test  : torch.Tensor

@dataclass
class DataSplit_STD:
	U_train  		 : torch.Tensor
	U_test   		 : torch.Tensor
	Y_train  		 : torch.Tensor
	Gin_train  		 : torch.Tensor
	Yin_train   	 : torch.Tensor

	LR_vof_train  	 : torch.Tensor
	MEAN_vof_train   : torch.Tensor
	STD_vof_train  	 : torch.Tensor

	LR_j_train  	 : torch.Tensor
	MEAN_j_train     : torch.Tensor
	STD_j_train  	 : torch.Tensor

	LR_velp1_train   : torch.Tensor
	MEAN_velp1_train : torch.Tensor
	STD_velp1_train  : torch.Tensor

	LR_velp2_train   : torch.Tensor
	MEAN_velp2_train : torch.Tensor
	STD_velp2_train  : torch.Tensor

	LR_Unified_train : torch.Tensor
	MEAN_Unified_train : torch.Tensor
	STD_Unified_train  : torch.Tensor

	Y_test   		 : torch.Tensor
	G_train  		 : torch.Tensor
	G_test   		 : torch.Tensor
	Gin_test  		 : torch.Tensor
	Yin_test   	 	 : torch.Tensor

	LR_vof_test  	 : torch.Tensor
	MEAN_vof_test    : torch.Tensor
	STD_vof_test  	 : torch.Tensor

	LR_j_test  	     : torch.Tensor
	MEAN_j_test      : torch.Tensor
	STD_j_test  	 : torch.Tensor

	LR_velp1_test    : torch.Tensor
	MEAN_velp1_test  : torch.Tensor
	STD_velp1_test   : torch.Tensor

	LR_velp2_test    : torch.Tensor
	MEAN_velp2_test  : torch.Tensor
	STD_velp2_test   : torch.Tensor

	LR_Unified_test  : torch.Tensor
	MEAN_Unified_test : torch.Tensor
	STD_Unified_test  : torch.Tensor	