
import os
import csv
import torch
import pickle
from constant import DataSplit_F, DataSplit_STD
from network import CoFFe_PreTrain_Net_MutualEncodingMode

# Specify the GPUs to use
device_ids = [0]
device = torch.device(f"cuda:{device_ids[0]}" if torch.cuda.is_available() else "cpu")

#__________________________PARAMETERS_________________________________

# Set the neccessary parameters based on corresponding pre-training task

field_idx = 2 # The selected field for sparse reconstruction
field_names = ['vof', 'j', 'vel_p1', 'vel_p2']
n_fields = len(field_names)

n_field_info = 24
n_baseF = 40 
N_selected   = 20 # Points selected for sparse reconstruction
N_P_Selected = 500 # points to evaluate performances
EVALUATION = True

# FieldAttention layer parameters
num_heads = 9
num_layers = 1

PreTrained_Net_Name = f'net_MutualEncoding_{n_field_info}_state_dict_N{N_selected}'
Load_file_path = 'Output_Net/{}.pth'.format(PreTrained_Net_Name)
outFile = f'data_split/data_split_MutualEncoding_Features_{field_idx}_{N_selected}.pic'
#____________________________________________________________________

def get_data_iter(U, Y, G, G_max, Yin, Gin, batch_size = 3000): # random sampling in each epoch
    num_examples = len(U)
    num_points = Y.shape[1]
    indices = list(range(num_examples))
    # np.random.shuffle(indices)  
    for i in range(0, num_examples, batch_size):
        j = torch.LongTensor(indices[i: min(i + batch_size, num_examples)]) 
        j = j.to(device)

        selected_points = torch.randperm(num_points)[:N_P_Selected].to(device)
        yield  U.index_select(0, j), Y.index_select(0, j).index_select(1, selected_points), G.index_select(0, j).index_select(1, selected_points), G_max.index_select(0,j), Yin.index_select(0, j), Gin.index_select(0, j)

def custom_mse_loss(output, target, target_max, field_weights):

    num_fields = target.size(-1)
    total_loss = 0
    field_losses = torch.zeros(num_fields)

    for id in range(num_fields):
        target_max_k = target_max[:, :, id]
        target_max_k = torch.clamp(target_max_k, min=0.1)
        field_output = output[:, :, id]
        field_target = target[:, :, id]
        
        field_loss = torch.mean(((field_output - field_target)/target_max_k) ** 2)
        field_losses[id] = field_loss.item()
        total_loss += field_weights[id] * field_loss

    return total_loss, field_losses

def standardize_features(latent_vectors):
    mean = torch.mean(latent_vectors, dim=0, keepdim=True)
    std = torch.std(latent_vectors, dim=0, keepdim=True)
    
    epsilon = 1e-8
    std = torch.clamp(std, min=epsilon)
    
    standardized_vectors = (latent_vectors - mean) / std
    
    return standardized_vectors, mean, std

if __name__ == '__main__':

    for id in range(len(field_names) + 1):
        field_name_or_feature = 'Unified' if id == len(field_names) else field_names[id]
        with open(f'LatentRepresentation/FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}.csv', 'wt') as fp: 
            pass

    # Load the pretrained net
    PreTrained_net = CoFFe_PreTrain_Net_MutualEncodingMode(n_field_info, n_baseF, num_heads, num_layers, num_fields=len(field_names)).to(device)
    state_dict = torch.load(Load_file_path)
    PreTrained_net.load_state_dict(state_dict)

    field_weights = torch.tensor([1.0] * 9)  # Replace with actual weights if needed
    field_weights = field_weights.to(device)

    # Load the dataset of all fields
    with open(os.path.join('Original_Split', 'Cathode', f'data_split.pic'), 'rb') as fp:
        data_split = pickle.load(fp)

        U_train = data_split.U_train.to(device)
        Y_train = data_split.Y_train.to(device)
        G_train = data_split.G_train.to(device)

        G_train[:, :, 0] = -1 * torch.log(G_train[:, :, 0] + 1e-7)
        G_train[:, :, 2] = -1 * torch.log(G_train[:, :, 2] + 1e-7)
        G_train[:, :, 3] = -1 * torch.log(G_train[:, :, 3] + 1e-7)

        U_test = data_split.U_test.to(device)
        Y_test = data_split.Y_test.to(device)
        G_test = data_split.G_test.to(device)

        G_test[:, :, 0] = -1 * torch.log(G_test[:, :, 0] + 1e-7)
        G_test[:, :, 2] = -1 * torch.log(G_test[:, :, 2] + 1e-7)
        G_test[:, :, 3] = -1 * torch.log(G_test[:, :, 3] + 1e-7)

        G_train_max, _ = torch.max(G_train, axis=1, keepdim=True)
        G_test_max, _ = torch.max(G_test, axis=1, keepdim=True)
        print(U_train.shape, U_test.shape)
        
        n_inputF = U_train.shape[-1]
        n_pointD = Y_train.shape[-1]

        points = Y_train[0,:]
        def indice_choosen(points):
            x_min, x_max = points[:, 0].min(), points[:, 0].max()
            y_min, y_max = points[:, 1].min(), points[:, 1].max()

            inner_x_min, inner_x_max = x_min + 0.1, x_max - 0.1
            inner_y_min, inner_y_max = y_min + 0.1, y_max - 0.1
            
            inner_indices = torch.where(
                (points[:, 0] > inner_x_min) & (points[:, 0] < inner_x_max) &
                (points[:, 1] > inner_y_min) & (points[:, 1] < inner_y_max)
            )[0]

            if len(inner_indices) < N_selected:
                raise ValueError("no enough points")

            random_inner_indices = inner_indices[torch.randperm(len(inner_indices))[:N_selected]]

            print("indices in inner region:", inner_indices.shape)
            print("indices randomly chosen from inner region:", random_inner_indices.shape)

            return random_inner_indices
        indices = indice_choosen(points)
        torch.save(indices,f'indices_restricted_Loadfeature.pth')
        
        restricted_indices = torch.load('indices_restricted_Loadfeature.pth').to(device)
        Yin_train = Y_train[:, restricted_indices, :].to(device)
        Yin_test = Y_test[:, restricted_indices, :].to(device)
        print('Y_train.shape = ', Y_train.shape)
        print('Yin_train.shape = ', Yin_train.shape)
        
        Gin_train = G_train[:, restricted_indices, field_idx].unsqueeze(-1).to(device)  
        Gin_test = G_test[:, restricted_indices, field_idx].unsqueeze(-1).to(device)  
        print('Gin_Train.shape = ', Gin_train.shape)
    
    with torch.no_grad():
        for U, Y, G, G_max, Yin, Gin in get_data_iter(U_train, Y_train, G_train, G_train_max, Yin_train, Gin_train):

            baseF = PreTrained_net.PosNet(Y)   #   [n_batch, np_selected, n_dim -> n_base]
            U_Unified_list_train = []
            for id in range(n_fields):   # Reconstructing the id(th) field
                field_info = PreTrained_net._compress_data(baseF, G, id, num_heads) # [n_batch, n_field_info, n_fields]: The latent representations from one Encoder towards the id(th) field
                
                U_Unified = PreTrained_net.FieldMerges[id](field_info, id) #   [n_batch, n_field_info]: Unified latent representations from one Encoder towards the id(th) field
                U_Unified_list_train.append(U_Unified)

            ALL_Unified_U_train = torch.stack(U_Unified_list_train, dim=2) #   [n_batch, n_field_info, n_fields]
            print('In train set, ALL_Unified_U_train.shape is ', ALL_Unified_U_train.shape)
            Global_Unified_U_train = PreTrained_net.FinalMerge(ALL_Unified_U_train, -1)   #   [n_batch, n_field_info]
            print('In train set, Global_Unified_U_train.shape is ', Global_Unified_U_train.shape)

            if EVALUATION is True:
                Total_Field_train_loss_Data = 0.0
                Field_train_loss = torch.zeros(len(field_names), device=device)  # [len(field_names), len(field_names)]

                Global_Unified_field_outputs = []   # This means, the field output is decoded from the "Global_Unified" feature
                for field_name, field_net in PreTrained_net.field_nets.items(): # Generate all the fields
                    coef = field_net(Global_Unified_U_train)
                    combine = coef * baseF
                    Global_Unified_field_output = torch.sum(combine, dim=2, keepdim=True)
                    Global_Unified_field_outputs.append(Global_Unified_field_output)
                Global_Unified_Gout = torch.cat(Global_Unified_field_outputs, dim=-1) #   All the field_idx(th) field results from Global_Unified_U

                field_loss_data, field_losses = custom_mse_loss(Global_Unified_Gout, G, G_max, field_weights)
                Total_Field_train_loss_Data = field_loss_data
                for j, loss_item in enumerate(field_losses):
                    Field_train_loss[j] = loss_item                

                print(f'Total Field Train Loss: {Total_Field_train_loss_Data.item()}')
                for id, field_name in enumerate(field_names):
                    print(f'Train Loss for field {field_name}: {Field_train_loss[id].item()}')
                print()

        for U, Y, G, G_max, Yin, Gin in get_data_iter(U_test, Y_test, G_test, G_test_max, Yin_test, Gin_test):

            baseF = PreTrained_net.PosNet(Y)   #   [n_batch, np_selected, n_dim -> n_base]
            U_Unified_list_test = []
            for id in range(n_fields):   # Reconstructing the id(th) field
                field_info = PreTrained_net._compress_data(baseF, G, id, num_heads) # [n_batch, n_field_info, n_fields]: The latent representations from one Encoder towards the id(th) field
                
                U_Unified = PreTrained_net.FieldMerges[id](field_info, id) #   [n_batch, n_field_info]: Unified latent representations from one Encoder towards the id(th) field
                U_Unified_list_test.append(U_Unified)

            ALL_Unified_U_test = torch.stack(U_Unified_list_test, dim=2) #   [n_batch, n_field_info, n_fields]
            print('In test set, ALL_Unified_U_test.shape is ', ALL_Unified_U_test.shape)
            Global_Unified_U_test = PreTrained_net.FinalMerge(ALL_Unified_U_test, -1)   #   [n_batch, n_field_info]
            print('In test set, Global_Unified_U_test.shape is ', Global_Unified_U_test.shape)

            if EVALUATION is True:
                Total_Field_test_loss_Data = 0.0
                Field_test_loss = torch.zeros(len(field_names), device=device)  # [len(field_names), len(field_names)]

                Global_Unified_field_outputs = [] # This means, the field output is decoded from the "Global_Unified" feature
                for field_name, field_net in PreTrained_net.field_nets.items(): # Generate all the fields
                    coef = field_net(Global_Unified_U_test)
                    combine = coef * baseF
                    Global_Unified_field_output = torch.sum(combine, dim=2, keepdim=True)
                    Global_Unified_field_outputs.append(Global_Unified_field_output)
                Global_Unified_Gout = torch.cat(Global_Unified_field_outputs, dim=-1) #   All the field_idx(th) field results from Global_Unified_U

                field_loss_data, field_losses = custom_mse_loss(Global_Unified_Gout, G,G_max, field_weights)
                Total_Field_test_loss_Data = field_loss_data
                for j, loss_item in enumerate(field_losses):
                    Field_test_loss[j] = loss_item                

                print(f'Total Field Test Loss: {Total_Field_test_loss_Data.item()}')
                for id, field_name in enumerate(field_names):
                    print(f'Test Loss for field {field_name}: {Field_test_loss[id].item()}')
                print()

    std_field_info_train_tensors = {}
    std_field_info_test_tensors  = {}

    train_mean_tensors = {}
    train_std_tensors  = {}
    test_mean_tensors  = {}
    test_std_tensors   = {}

    # Perform Normalization to latent features and Write to CSV file
    for id in range(len(field_names) + 1):
        # Determine field name or unified feature
        field_name_or_feature = 'Unified' if id == len(field_names) else field_names[id]
        
        info_train = Global_Unified_U_train if id == len(field_names) else ALL_Unified_U_train[:, :, id]
        info_test  = Global_Unified_U_test  if id == len(field_names) else ALL_Unified_U_test[:, :, id]

        #   Perform standardization for the latent representations
        info_train_std, mean_train, std_train = standardize_features(info_train)
        info_test_std, mean_test, std_test    = standardize_features(info_test)

        if id == len(field_names): # For the global feature
            std_U_Unified_train = info_train_std
            std_U_Unified_test  = info_test_std

            Unified_mean_train = mean_train 
            Unified_std_train  = std_train 
            Unified_mean_test  = mean_test 
            Unified_std_test   = std_test 
        else:
            std_field_info_train_tensors[f'field_info_{field_names[id]}'] = info_train_std
            std_field_info_test_tensors[f'field_info_{field_names[id]}']  = info_test_std

            train_mean_tensors[f'field_info_{field_names[id]}'] = mean_train
            train_std_tensors[f'field_info_{field_names[id]}']  = std_train
            test_mean_tensors[f'field_info_{field_names[id]}']  = mean_test
            test_std_tensors[f'field_info_{field_names[id]}']   = std_test

        print(f'Successfully Standardized FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}!')

        with open(f'LatentRepresentation/FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}.csv', 'wt') as fp:
            simple_writer = csv.writer(fp)

            fieldnames = ['U', 'field_info']
            writer = csv.DictWriter(fp, fieldnames=fieldnames)
            writer.writeheader()
            print(U_train.shape)
            # Write data from the training set
            writer.writerow({'U': 'From training set:'})
            for i in range(U_train.shape[0]):
                row = {'U': U_train[i].cpu().numpy().tolist(),
                    'field_info': info_train[i].cpu().numpy().tolist()}
                writer.writerow(row)            
            # Write data from the test set
            writer.writerow({'U': 'From test set:'})
            for i in range(U_test.shape[0]):
                row = {'U': U_test[i].cpu().numpy().tolist(),
                    'field_info': info_test[i].cpu().numpy().tolist()}
                writer.writerow(row)
        print(f'Successfully export FeaturesFrom_{PreTrained_Net_Name}_To_{field_name_or_feature}.csv!\n')

    #   Export all the data to DataSplit for next-step training
    data_split = DataSplit_STD(
            U_train          = U_train,
            Y_train          = Y_train,
            G_train          = G_train,
            Gin_train  		 = Gin_train,
            Yin_train   	 = Yin_train,

            LR_vof_train  	 = std_field_info_train_tensors['field_info_vof'],
            MEAN_vof_train   = train_mean_tensors['field_info_vof'],
            STD_vof_train  	 = train_std_tensors['field_info_vof'],

            LR_j_train  	 = std_field_info_train_tensors['field_info_j'],
            MEAN_j_train     = train_mean_tensors['field_info_j'],
            STD_j_train  	 = train_std_tensors['field_info_j'],

            LR_velp1_train   = std_field_info_train_tensors['field_info_vel_p1'],
            MEAN_velp1_train = train_mean_tensors['field_info_vel_p1'],
            STD_velp1_train  = train_std_tensors['field_info_vel_p1'],

            LR_velp2_train   = std_field_info_train_tensors['field_info_vel_p2'],
            MEAN_velp2_train = train_mean_tensors['field_info_vel_p2'],
            STD_velp2_train  = train_std_tensors['field_info_vel_p2'],

            LR_Unified_train = std_U_Unified_train,
            MEAN_Unified_train = Unified_mean_train,
            STD_Unified_train  = Unified_std_train,

            U_test           = U_test,
            Y_test           = Y_test,
            G_test           = G_test,
            Gin_test  		 = Gin_test,
            Yin_test   	 	 = Yin_test,

            LR_vof_test  	 = std_field_info_test_tensors['field_info_vof'],
            MEAN_vof_test    = test_mean_tensors['field_info_vof'],
            STD_vof_test  	 = test_std_tensors['field_info_vof'],

            LR_j_test  	     = std_field_info_test_tensors['field_info_j'],
            MEAN_j_test      = test_mean_tensors['field_info_j'],
            STD_j_test  	 = test_std_tensors['field_info_j'],

            LR_velp1_test    = std_field_info_test_tensors['field_info_vel_p1'],
            MEAN_velp1_test  = test_mean_tensors['field_info_vel_p1'],
            STD_velp1_test   = test_std_tensors['field_info_vel_p1'],
            
            LR_velp2_test    = std_field_info_test_tensors['field_info_vel_p2'],
            MEAN_velp2_test  = test_mean_tensors['field_info_vel_p2'],
            STD_velp2_test   = test_std_tensors['field_info_vel_p2'],

            LR_Unified_test  = std_U_Unified_test,
            MEAN_Unified_test = Unified_mean_test,
            STD_Unified_test  = Unified_std_test
        )

    with open(outFile, 'wb') as fp:
        pickle.dump(data_split, fp)
        print(f'...Data saved to Data_split {outFile} !!!')

