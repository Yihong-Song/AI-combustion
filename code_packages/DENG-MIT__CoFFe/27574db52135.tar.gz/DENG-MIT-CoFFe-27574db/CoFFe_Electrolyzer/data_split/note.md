
### `data_split` Directory

The `data_split` directory stores the raw data and the features data at intermediate stages of pre-training. 
All data files are saved in `.pic` format and can be read using the `pickle` package.

#### Contents:

- **`data_split.pic`**: This file contains six tensors for the Biomass combustion application:
  - `U_train`, `U_test`: Tensors storing the condition parameters for each case.
  - `Y_train`, `Y_test`: Tensors storing spatial coordinates for each case.
  - `G_train`, `G_test`: Tensors storing the specific values of various physical quantities.
  - Total cases: 1806
  - field_names = ['vof', 'j', 'vel_p1', 'vel_p2']


### Note:

For complete dataset or seeking for expansion on the current application, please contact wanglz@mit.edu
Once obtaining the datasets in thr format of `.pic`, just put them in this folder
If the name of dataset file is altered, need to update the information before runing the scripts.