import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import matplotlib.pyplot as plt
import torch.nn.functional as F
import pickle
import time

from sklearn.model_selection import train_test_split
from network import Direct_SensorToFeature, CoFFe_PreTrain_Net_MutualEncodingMode, Finetuning_SensorToFeatures_MutualEncoding


device_ids = [0]
device = torch.device(f"cuda:{device_ids[0]}" if torch.cuda.is_available() else "cpu")

#____________________________PARAMETERS_________________________________________________
CASENUM = 50
N_EPOCH = 100000
field_idx = 2
N_selected = 20
n_field_info = 24
n_baseF      = 40 
num_heads    = 9
num_layers   = 1
field_names = ['vof', 'j', 'vel_p1', 'vel_p2']
hidden_sizes = [500, 500]
Unifed_weight = 5.0
layer_sizes = [n_field_info * len(field_names)] + hidden_sizes + [n_field_info]  
Final_layer_sizes = [n_field_info] + hidden_sizes + [n_field_info] 
field_weights = torch.tensor([1.0] * 4)  # Replace with actual weights if needed
field_weights = field_weights.to(device)
EVALUATE = False
N_REPORT = 10
train_loss_weight = 0.15
test_loss_weight = 0.85
patience = 20

NET_TYPE = int(0) 
                # 0 = [Mutual_Representation_PreTrain_Net]; 1 = [Direct_SensorToFeature]

PreTrained_Net_Name = f'net_MutualEncoding_{n_field_info}_state_dict_N{N_selected}'
Load_file_path = 'Output_Net/{}.pth'.format(PreTrained_Net_Name)

#____________________________________________________________________

class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.fc1 = nn.Linear(20 * 2, 128)  
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 1)  

    def forward(self, x):
        x = x.view(-1, 20 * 2)  
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x

def custom_mse_loss(output, target, target_max, field_weights):
    losses = []
    num_fields = target.size(-1)
    for k in range(output.shape[2]):  # Loop over fields
        target_max_k = target_max[:, :, k]
        target_max_k = torch.clamp(target_max_k, min=0.1)
        field_output = output[:, :, k]
        field_target = target[:, :, k]
        field_loss = torch.mean(((field_output - field_target)/target_max_k) ** 2)
        losses.append(field_loss*field_weights[k])

    total_loss = torch.stack(losses).sum()

    return total_loss, losses


def unstandardize_features(standardized_vectors, mean, std):
    return standardized_vectors * std + mean

PreTrained_net = CoFFe_PreTrain_Net_MutualEncodingMode(n_field_info, n_baseF, num_heads, num_layers, num_fields=len(field_names)).to(device)
state_dict = torch.load(Load_file_path)
PreTrained_net.load_state_dict(state_dict)
  
    
field_info_train_tensors = {}
field_info_test_tensors = {}
mean_train_tensors = {}
mean_test_tensors = {}
std_train_tensors = {}
std_test_tensors = {}    

with open(f'data_split/data_split_MutualEncoding_Features_{field_idx}_{N_selected}.pic', 'rb') as fp: 
        data_split = pickle.load(fp)

        U_train          = data_split.U_train.to(device)
        Y_train          = data_split.Y_train.to(device)
        G_train          = data_split.G_train.to(device)
        

        Gin_train  		 = data_split.Gin_train.to(device)  		
        Yin_train   	 = data_split.Yin_train.to(device)
        print(Gin_train.shape, Yin_train.shape)

        LR_vof_train  	 = data_split.LR_vof_train.to(device)
        field_info_train_tensors[f'field_info_vof'] = LR_vof_train
        MEAN_vof_train                              = data_split.MEAN_vof_train.to(device)
        mean_train_tensors[f'field_info_vof']       = MEAN_vof_train
        STD_vof_train                               = data_split.STD_vof_train.to(device)
        std_train_tensors[f'field_info_vof']        = STD_vof_train

        LR_j_train  	 = data_split.LR_j_train.to(device)
        field_info_train_tensors[f'field_info_j']   = LR_j_train
        MEAN_j_train                                = data_split.MEAN_j_train.to(device)
        mean_train_tensors[f'field_info_j']         = MEAN_j_train
        STD_j_train                                 = data_split.STD_j_train.to(device)
        std_train_tensors[f'field_info_j']          = STD_j_train

        LR_velp1_train  	 = data_split.LR_velp1_train.to(device)
        field_info_train_tensors[f'field_info_vel_p1'] = LR_velp1_train
        MEAN_velp1_train                               = data_split.MEAN_velp1_train.to(device)
        mean_train_tensors[f'field_info_vel_p1']       = MEAN_velp1_train
        STD_velp1_train                                = data_split.STD_velp1_train.to(device)
        std_train_tensors[f'field_info_vel_p1']        = STD_velp1_train

        LR_velp2_train  	 = data_split.LR_velp2_train.to(device)
        field_info_train_tensors[f'field_info_vel_p2'] = LR_velp2_train
        MEAN_velp2_train                               = data_split.MEAN_velp2_train.to(device)
        mean_train_tensors[f'field_info_vel_p2']       = MEAN_velp2_train
        STD_velp2_train                                = data_split.STD_velp2_train.to(device)
        std_train_tensors[f'field_info_vel_p2']        = STD_velp2_train

        LR_Unified_train = data_split.LR_Unified_train.to(device)
        MEAN_Unified_train                             = data_split.MEAN_Unified_train.to(device)
        mean_train_tensors[f'Unified']                  = MEAN_Unified_train
        STD_Unified_train                              = data_split.STD_Unified_train.to(device)
        std_train_tensors[f'Unified']                   = STD_Unified_train

        U_test           = data_split.U_test.to(device)
        Y_test           = data_split.Y_test.to(device)
        G_test           = data_split.G_test.to(device)
        

        Gin_test  		 = data_split.Gin_test.to(device)  		
        Yin_test   	 	 = data_split.Yin_test.to(device)  

        LR_vof_test  	 = data_split.LR_vof_test.to(device)
        field_info_test_tensors[f'field_info_vof'] = LR_vof_test
        MEAN_vof_test                              = data_split.MEAN_vof_test.to(device)
        mean_test_tensors[f'field_info_vof']       = MEAN_vof_test
        STD_vof_test                               = data_split.STD_vof_test.to(device)
        std_test_tensors[f'field_info_vof']        = STD_vof_test

        LR_j_test  	 = data_split.LR_j_test.to(device)
        field_info_test_tensors[f'field_info_j'] = LR_j_test
        MEAN_j_test                                = data_split.MEAN_j_test.to(device)
        mean_test_tensors[f'field_info_j']         = MEAN_j_test
        STD_j_test                                 = data_split.STD_j_test.to(device)
        std_test_tensors[f'field_info_j']          = STD_j_test

        LR_velp1_test  	 = data_split.LR_velp1_test.to(device)
        field_info_test_tensors[f'field_info_vel_p1'] = LR_velp1_test
        MEAN_velp1_test                               = data_split.MEAN_velp1_test.to(device)
        mean_test_tensors[f'field_info_vel_p1']       = MEAN_velp1_test
        STD_velp1_test                                = data_split.STD_velp1_test.to(device)
        std_test_tensors[f'field_info_vel_p1']        = STD_velp1_test

        LR_velp2_test  	 = data_split.LR_velp2_test.to(device)
        field_info_test_tensors[f'field_info_vel_p2'] = LR_velp2_test
        MEAN_velp2_test                               = data_split.MEAN_velp2_test.to(device)
        mean_test_tensors[f'field_info_vel_p2']       = MEAN_velp2_test
        STD_velp2_test                                = data_split.STD_velp2_test.to(device)
        std_test_tensors[f'field_info_vel_p2']        = STD_velp2_test

        LR_Unified_test  = data_split.LR_Unified_test.to(device)
        MEAN_Unified_test                             = data_split.MEAN_Unified_test.to(device)
        mean_test_tensors[f'Unified']                  = MEAN_Unified_test        
        STD_Unified_test                              = data_split.STD_Unified_test.to(device)
        std_test_tensors[f'Unified']                   = STD_Unified_test

        G_train_max, _ = torch.max(G_train, axis=1, keepdim=True)
        G_test_max, _ = torch.max(G_test, axis=1, keepdim=True)    

Y_origin = torch.load('Location/pre/Y_origin.pth').to(device)
Y_origin = Y_origin[:800,0,:]
LR_Unified_train = torch.load('Location/pre/LR_Unified_train.pth').to(device)
Unified_Feature_output = torch.load('Location/pre/Unified_Feature_output_train.pth')
Unified_Feature_output = torch.stack(Unified_Feature_output).to(device)
print(f'shape of Y_origin is {Y_origin.shape}')
print(f'shape of LR_Unified_train is {LR_Unified_train.shape}')
print(f'shape of Unified_Feature_output is {(Unified_Feature_output.shape)}')

# Define the network
if (NET_TYPE == 0):
    net = Finetuning_SensorToFeatures_MutualEncoding(layer_sizes, Final_layer_sizes, PreTrained_net).to(device)
    # Fix the parameters in the petrained net
    for param in net.PreTrained_net.parameters():
        param.requires_grad = False
elif (NET_TYPE == 1): # Directly map the sensor values to the latent space
    layer_sizes = [N_selected] + hidden_sizes + [n_field_info]  
    net = Direct_SensorToFeature(layer_sizes).to(device)
else:
    print('Net is not correctly defined !!!')
    exit()


errors = torch.zeros(800).to(device)  

for i in range(800):
    errors[i] = F.mse_loss(Unified_Feature_output[i], LR_Unified_train)
    
indices_P = torch.randint(0, 2500, (500,)).to(device)
Y_P_train = Y_train[:,indices_P]
G_P_train = G_train[:,indices_P]    
Y_P_test = Y_test[:,indices_P]
G_P_test = G_test[:,indices_P]
Y = Y_P_train
G = G_P_train
G_max = G_train_max
x_coords = Y_train[0][:,0]
y_coords = Y_train[0][:,1]
x_min, x_max = torch.min(x_coords), torch.max(x_coords)
y_min, y_max = torch.min(y_coords), torch.max(y_coords)


num_epochs = 3000
learning_rate = 1e-3

inputs = Y_origin
print(inputs.shape)
targets = torch.tensor(errors)

train_inputs, test_inputs, train_targets, test_targets = train_test_split(
    inputs, targets, test_size=0.2, random_state=42
)

train_inputs, train_targets = torch.tensor(train_inputs), torch.tensor(train_targets)
test_inputs, test_targets = torch.tensor(test_inputs), torch.tensor(test_targets)
print(train_inputs.shape)

model = MLP().to(device)
criterion = nn.MSELoss(reduction = 'mean').to(device)
optimizer_pre = optim.Adam(model.parameters(), lr=learning_rate)

train_losses = []
test_losses = []

for epoch in range(num_epochs):
    model.train()

    outputs = model(train_inputs)
    loss = criterion(outputs, train_targets)

    optimizer_pre.zero_grad()
    loss.backward()
    optimizer_pre.step()

    train_losses.append(loss.item())

    if (epoch + 1) % 100 == 0:
        model.eval()
        with torch.no_grad():
            test_outputs = model(test_inputs)
            test_loss = criterion(test_outputs, test_targets)
            test_losses.append(test_loss.item())
        
        print(f'Epoch [{epoch+1}/{num_epochs}], Train Loss: {loss.item():.4f}, Test Loss: {test_loss.item():.4f}')
        
        if test_loss >= 10*loss:
            break

indices = torch.zeros(1000,20, dtype=torch.long).to(device)
indices = indices.to(device)
target_coords = torch.zeros(1000,20,2).to(device)    
for i in range(CASENUM):
    indices[i] = torch.randperm(Y_train.size(1))[:20]
    target_coords[i] = Y_train[0,indices[i]]
    Y_in_sample = target_coords[i]
    sorted_indices = torch.argsort(Y_in_sample[:, 1])  
    sorted_Y_in_sample = Y_in_sample[sorted_indices]   
    sorted_Y_in_sample, final_sorted_indices = torch.sort(sorted_Y_in_sample, dim=0)
    new_indices = indices[i][sorted_indices[final_sorted_indices[:, 0]]]
    indices[i] = new_indices
    target_coords[i] = Y_train[0,indices[i]]

torch.save(target_coords,'Location/post/initial_location.pth')

for param in model.parameters():
    param.requires_grad = False

optimized_location = torch.zeros(1000,20,2).to(device)
losses = torch.zeros(1000).to(device)
optimizer = optim.Adam(net.parameters(), lr=0.002, weight_decay=5.0E-2)

location_loss = [None]*CASENUM
for case_number in range(CASENUM):
    initial_time = time.time()
    best_combined_loss = 5.0
    counter = 0
    present_location = target_coords[case_number].to(device)
    present_location = torch.nn.Parameter(present_location, requires_grad = True)
    num_opt_epochs = 10000
    optimizer_coords = optim.Adam([present_location], lr=1e-4)
    
    for epoch in range(num_opt_epochs):
        start = time.time()
        optimizer_coords.zero_grad()
    
        predicted_output = model(present_location)
    
        norm = torch.abs(predicted_output)
    
        norm.backward()
        
        optimizer_coords.step()

        x_present = present_location[:,0]
        y_present = present_location[:,1]
        x_present_max, x_present_min = torch.max(x_present), torch.min(x_present)
        y_present_max, y_present_min = torch.max(y_present), torch.min(y_present)
        
        if epoch == 0:
            location_loss[case_number] = norm.unsqueeze(0)
            torch.save(present_location.unsqueeze(0),f'Location/post/location_case{case_number}.pth')
        if (epoch+1)%1 ==0:
            locations = torch.load(f'Location/post/location_case{case_number}.pth').to(device)
            locations = torch.cat((locations, present_location.unsqueeze(0)), dim=0)
            torch.save(locations,f'Location/post/location_case{case_number}.pth')
            location_loss[case_number] = torch.cat((location_loss[case_number], norm.unsqueeze(0)))
            
        if x_present_max > x_max or x_present_min < x_min or y_present_max > y_max or y_present_min < y_min:
            break
        end = time.time()
        print(end-start)
        exit()
   
            
            
        


