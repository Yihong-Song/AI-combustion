import sys
sys.path.append('..')

import io
import csv
import time
import numpy as np 

import torch
import torch.nn as nn
import torch.optim as optim
import pickle

from torch import nn 
from constant import DataSplit_STD 
from network import Direct_SensorToFeature, CoFFe_PreTrain_Net_MutualEncodingMode, Finetuning_SensorToFeatures_MutualEncoding
from torch.utils.data import Dataset, DataLoader
# Specify the GPUs to use
device_ids = [1]
device = torch.device(f"cuda:{device_ids[0]}" if torch.cuda.is_available() else "cpu")

#__________________________PARAMETERS_________________________________

# Set the neccessary parameters based on corresponding pre-training task

field_idx    = 2 # The field used for sparse reconstruction
field_names = ['vof', 'j', 'vel_p1', 'vel_p2']
n_fields    = len(field_names)
N_EPOCH     = 1000000
N_REPORT    = 10
Case_Num    = 1500

EVALUATE     = True
n_field_info = 24
n_baseF      = 40 

N_selected   = 20 # Points selected for sparse reconstruction
N_P_Selected = 500 # points to evaluate performances

# FieldAttention layer parameters
num_heads    = 9
num_layers   = 1
hidden_sizes = [500, 500]
layer_sizes = [n_field_info * len(field_names)] + hidden_sizes + [n_field_info]  
Final_layer_sizes = [n_field_info] + hidden_sizes + [n_field_info]

Unifed_weight = 5.0

NET_TYPE = int(0)
                # 0 = [CoFFe_PreTrain_MutualEncoding]; 1 = [Direct_SensorToFeature]
NET_SETTINGS = f'Selecting {N_selected} random sensors from {field_names[field_idx]} to recover the latent features\thidden_sizes = {hidden_sizes}\n'
NET_NAME = [f'CoFFe_MutualEncoding_SensorToFeature_FromF{field_idx}_N{N_selected}', f'Direct_SensorToFeature_N{N_selected}']

PreTrained_Net_Name = f'net_MutualEncoding_{n_field_info}_state_dict_N{N_selected}'
Load_file_path = 'Output_Net/{}.pth'.format(PreTrained_Net_Name)
#____________________________________________________________________

def get_data_iter(U, Y, G, G_max, Yin, Gin, batch_size = 3000): # random sampling in each epoch
    num_examples = len(U)
    num_points = Y.shape[1]
    indices = list(range(num_examples))
    # np.random.shuffle(indices)  
    for i in range(0, num_examples, batch_size):
        j = torch.LongTensor(indices[i: min(i + batch_size, num_examples)]) 
        j = j.to(device)

        selected_points = torch.randperm(num_points)[:N_P_Selected].to(device)
        yield  U.index_select(0, j), Y.index_select(0, j).index_select(1, selected_points), G.index_select(0, j).index_select(1, selected_points), G_max.index_select(0, j), Yin.index_select(0, j), Gin.index_select(0, j)

def custom_mse_loss(output, target, target_max, field_weights):
    num_fields = target.size(-1)
    total_loss = 0
    field_losses = torch.zeros(num_fields)

    for id in range(num_fields):
        target_max_k = target_max[:, :, id]
        target_max_k = torch.clamp(target_max_k, min=0.1)
        field_output = output[:, :, id]
        field_target = target[:, :, id]
        
        field_loss = torch.mean(((field_output - field_target)/target_max_k) ** 2)
        field_losses[id] = field_loss.item()
        # total_loss += field_weights[id] * field_loss
        total_loss += field_loss

    return total_loss, field_losses

def standardize_features(latent_vectors, mean, std):    
    epsilon = 1e-8
    std = torch.clamp(std, min=epsilon)
    
    standardized_vectors = (latent_vectors - mean) / std
    
    return standardized_vectors, mean, std

def unstandardize_features(standardized_vectors, mean, std):
    return standardized_vectors * std + mean

def normalize_data(data, min_val, max_val):
    normalized_data = (data - min_val) / (max_val - min_val)

    sqrt_normalized_data = torch.sqrt(torch.clamp(normalized_data, min=0))
    return sqrt_normalized_data

def Denormalize_data(normalized_data, min_val, max_val):
    Retrieved_data = normalized_data ** 2
    Retrieved_data = Retrieved_data * (max_val - min_val) + min_val
    return Retrieved_data

if __name__ == '__main__':

    with open(f'Loss_csv/train_test_loss_reconstruction/train_test_loss_S2F_From{field_idx}_{NET_NAME[NET_TYPE]}.csv', 'wt') as fp: 
        pass

    if EVALUATE is True:
        with open(f'Loss_csv/train_test_loss_reconstruction/Reconstruct_loss_From{field_idx}_{NET_NAME[NET_TYPE]}.csv', 'wt') as fp:
            pass
        

    # Load the pretrained net
    PreTrained_net = CoFFe_PreTrain_Net_MutualEncodingMode(n_field_info, n_baseF, num_heads, num_layers, num_fields=len(field_names)).to(device)
    state_dict = torch.load(Load_file_path)
    PreTrained_net.load_state_dict(state_dict)

    field_info_train_tensors = {}
    field_info_test_tensors = {}
    mean_train_tensors = {}
    mean_test_tensors = {}
    std_train_tensors = {}
    std_test_tensors = {}

    with open(f'data_split/data_split_MutualEncoding_Features_{field_idx}_{N_selected}.pic', 'rb') as fp: 
        data_split = pickle.load(fp)

        U_train          = data_split.U_train.to(device)
        Y_train          = data_split.Y_train.to(device)
        G_train          = data_split.G_train.to(device)

        Gin_train  		 = data_split.Gin_train.to(device)  		
        Yin_train   	 = data_split.Yin_train.to(device)
        print(Gin_train.shape, Yin_train.shape)

        LR_vof_train  	 = data_split.LR_vof_train.to(device)
        field_info_train_tensors[f'field_info_vof'] = LR_vof_train
        MEAN_vof_train                              = data_split.MEAN_vof_train.to(device)
        mean_train_tensors[f'field_info_vof']       = MEAN_vof_train
        STD_vof_train                               = data_split.STD_vof_train.to(device)
        std_train_tensors[f'field_info_vof']        = STD_vof_train

        LR_j_train  	 = data_split.LR_j_train.to(device)
        field_info_train_tensors[f'field_info_j']   = LR_j_train
        MEAN_j_train                                = data_split.MEAN_j_train.to(device)
        mean_train_tensors[f'field_info_j']         = MEAN_j_train
        STD_j_train                                 = data_split.STD_j_train.to(device)
        std_train_tensors[f'field_info_j']          = STD_j_train

        LR_velp1_train  	 = data_split.LR_velp1_train.to(device)
        field_info_train_tensors[f'field_info_vel_p1'] = LR_velp1_train
        MEAN_velp1_train                               = data_split.MEAN_velp1_train.to(device)
        mean_train_tensors[f'field_info_vel_p1']       = MEAN_velp1_train
        STD_velp1_train                                = data_split.STD_velp1_train.to(device)
        std_train_tensors[f'field_info_vel_p1']        = STD_velp1_train

        LR_velp2_train  	 = data_split.LR_velp2_train.to(device)
        field_info_train_tensors[f'field_info_vel_p2'] = LR_velp2_train
        MEAN_velp2_train                               = data_split.MEAN_velp2_train.to(device)
        mean_train_tensors[f'field_info_vel_p2']       = MEAN_velp2_train
        STD_velp2_train                                = data_split.STD_velp2_train.to(device)
        std_train_tensors[f'field_info_vel_p2']        = STD_velp2_train

        LR_Unified_train = data_split.LR_Unified_train.to(device)
        MEAN_Unified_train                             = data_split.MEAN_Unified_train.to(device)
        mean_train_tensors[f'Unified']                  = MEAN_Unified_train
        STD_Unified_train                              = data_split.STD_Unified_train.to(device)
        std_train_tensors[f'Unified']                   = STD_Unified_train

        U_test           = data_split.U_test.to(device)
        Y_test           = data_split.Y_test.to(device)
        G_test           = data_split.G_test.to(device)

        Gin_test  		 = data_split.Gin_test.to(device)  		
        Yin_test   	 	 = data_split.Yin_test.to(device)  

        LR_vof_test  	 = data_split.LR_vof_test.to(device)
        field_info_test_tensors[f'field_info_vof'] = LR_vof_test
        MEAN_vof_test                              = data_split.MEAN_vof_test.to(device)
        mean_test_tensors[f'field_info_vof']       = MEAN_vof_test
        STD_vof_test                               = data_split.STD_vof_test.to(device)
        std_test_tensors[f'field_info_vof']        = STD_vof_test

        LR_j_test  	 = data_split.LR_j_test.to(device)
        field_info_test_tensors[f'field_info_j'] = LR_j_test
        MEAN_j_test                                = data_split.MEAN_j_test.to(device)
        mean_test_tensors[f'field_info_j']         = MEAN_j_test
        STD_j_test                                 = data_split.STD_j_test.to(device)
        std_test_tensors[f'field_info_j']          = STD_j_test

        LR_velp1_test  	 = data_split.LR_velp1_test.to(device)
        field_info_test_tensors[f'field_info_vel_p1'] = LR_velp1_test
        MEAN_velp1_test                               = data_split.MEAN_velp1_test.to(device)
        mean_test_tensors[f'field_info_vel_p1']       = MEAN_velp1_test
        STD_velp1_test                                = data_split.STD_velp1_test.to(device)
        std_test_tensors[f'field_info_vel_p1']        = STD_velp1_test

        LR_velp2_test  	 = data_split.LR_velp2_test.to(device)
        field_info_test_tensors[f'field_info_vel_p2'] = LR_velp2_test
        MEAN_velp2_test                               = data_split.MEAN_velp2_test.to(device)
        mean_test_tensors[f'field_info_vel_p2']       = MEAN_velp2_test
        STD_velp2_test                                = data_split.STD_velp2_test.to(device)
        std_test_tensors[f'field_info_vel_p2']        = STD_velp2_test

        LR_Unified_test  = data_split.LR_Unified_test.to(device)
        MEAN_Unified_test                             = data_split.MEAN_Unified_test.to(device)
        mean_test_tensors[f'Unified']                  = MEAN_Unified_test        
        STD_Unified_test                              = data_split.STD_Unified_test.to(device)
        std_test_tensors[f'Unified']                   = STD_Unified_test

        G_train_max, _ = torch.max(G_train, axis=1, keepdim=True)
        G_test_max, _ = torch.max(G_test, axis=1, keepdim=True)
      
        
        n_inputF = U_train.shape[-1]
        n_pointD = Y_train.shape[-1]

        print('LR_Unified_train.shape is ', LR_Unified_train.shape)
        print('MEAN_Unified_train.shape is ', MEAN_Unified_train.shape)
        print('STD_Unified_train.shape is ', STD_Unified_train.shape)

    # Define the network
    if (NET_TYPE == 0):
        net = Finetuning_SensorToFeatures_MutualEncoding(layer_sizes, Final_layer_sizes, PreTrained_net).to(device)
        # Fix the parameters in the petrained net
        for param in net.PreTrained_net.parameters():
            param.requires_grad = False
    elif (NET_TYPE == 1): # Directly map the sensor values to the latent space
        layer_sizes = [N_selected] + hidden_sizes + [n_field_info]  
        net = Direct_SensorToFeature(layer_sizes).to(device)
    else:
        print('Net is not correctly defined !!!')
        exit()


    indices = torch.load('indices_restricted_Loadfeature.pth')
    
    # Wrap the model with DataParallel
    net = nn.DataParallel(net, device_ids=device_ids)
    optimizer = optim.Adam(net.parameters(), lr=0.0002) # , weight_decay=5.0E-5
    Y_in = Y_train[:,indices]
    G_in = G_train[:,indices,field_idx].unsqueeze(-1)
    Y_in_T = Y_test[:,indices]
    G_in_T = G_test[:,indices,field_idx].unsqueeze(-1)
    indices_T = torch.randperm(Y_train.size(1))[:N_P_Selected]
    selected_points = Y_train[0, indices, :]
    selected_position = nn.Parameter(selected_points).to(device)
    
    # Set up early stopping parameters
    patience = 100
    best_combined_loss = float('5.0') #Initial threshold to determine early stopping
    counter = 0
    train_loss_weight = 0.15
    test_loss_weight = 0.85
    criterion = nn.MSELoss(reduction='mean')

    field_weights = torch.tensor([1.0] * 4)  # Replace with actual weights if needed
    field_weights = field_weights.to(device)
    
    for epoch in range(N_EPOCH):
        train_loss   = 0
        train_losses = torch.zeros(len(field_names)+1, device=device)
        test_loss    = 0
        test_losses  = torch.zeros(len(field_names)+1, device=device)

        Total_Field_train_loss_Data = 0.0
        Total_Field_test_loss_Data  = 0.0
        Field_train_loss = torch.zeros(len(field_names), device=device)  
        Field_test_loss  = torch.zeros(len(field_names), device=device)  
        train_batch_count = 0
        test_batch_count  = 0

        Y = Y_train
        G = G_train
        G_max = G_train_max
        Yin = Y_in
        Gin = G_in
        loss = 0.0
        optimizer.zero_grad()
        #----------------------------
        # Entering the training phase:
        #----------------------------
        if (NET_TYPE == 0):
            Predicted_Features, Unified_Feature_output_train = net(Yin, Gin, num_heads, mean_train_tensors, std_train_tensors)
        elif (NET_TYPE == 1):
            Unified_Feature_output_train = net(Yin, Gin)
        else:
            print('Net is not correctly defined !!!')
            exit()
        if (NET_TYPE == 0): # This is only calculated when the Encoder is reused in fine-tuning stage
            for id in range( len(field_names) ):
                field_output = Predicted_Features[:, :, id]
                field_target = field_info_train_tensors[f'field_info_{field_names[id]}'] 
                field_loss = criterion(field_output, field_target) 
                train_losses[id] = field_loss.item()
                train_loss += field_loss
                loss += field_weights[id] * field_loss
        mse_loss_Unifed_train = criterion(Unified_Feature_output_train, LR_Unified_train)
        train_losses[ len(field_names) ] = mse_loss_Unifed_train
        train_loss += mse_loss_Unifed_train
        loss += Unifed_weight *mse_loss_Unifed_train 
        loss.backward()
        optimizer.step()
        if EVALUATE is True and (epoch + 1) % N_REPORT == 0:
            with torch.no_grad():
                # Evaluate the field-reconstruction performance in the training set
                baseF = PreTrained_net.PosNet(Y)
                unstandardized_train_output = unstandardize_features(Unified_Feature_output_train, mean_train_tensors[f'Unified'], std_train_tensors[f'Unified'])
                # unstandardized_train_output = unstandardize_features(LR_Unified_train, mean_train_tensors[f'Unified'], std_train_tensors[f'Unified'])                   
                Global_Unified_field_outputs = []
                for field_name, field_net in PreTrained_net.field_nets.items(): # Generate all the fields
                    coef = field_net(unstandardized_train_output)
                    combine = coef * baseF
                    Global_Unified_field_output = torch.sum(combine, dim=2, keepdim=True)
                    Global_Unified_field_outputs.append(Global_Unified_field_output)
                Global_Unified_Gout = torch.cat(Global_Unified_field_outputs, dim=-1) #   All the field_idx(th) field results from Global_Unified_U  
                field_loss_data, field_losses = custom_mse_loss(Global_Unified_Gout, G, G_max, field_weights)
                Total_Field_train_loss_Data += field_loss_data
                for j, loss_item in enumerate(field_losses):
                    Field_train_loss[j] += loss_item
        train_batch_count += 1
        train_loss /= train_batch_count
        train_losses /= train_batch_count
        Total_Field_train_loss_Data /= train_batch_count
        Field_train_loss /= train_batch_count

        #----------------------------
        #   Entering the test phase:
        #----------------------------
        with torch.no_grad():  
            Y_test = Y_test
            G_test = G_test
            G_max_test = G_test_max
            Yin_test = Y_in_T
            Gin_test = G_in_T
            
            if (NET_TYPE == 0):
                Predicted_Features, Unified_Feature_output_test = net(Yin_test, Gin_test, num_heads, mean_test_tensors, std_test_tensors)
            elif (NET_TYPE == 1):
                Unified_Feature_output_test = net(Yin_test, Gin_test)
            else:
                print('Net is not correctly defined !!!')
                exit()
            if (NET_TYPE == 0): # This is only calculated when the Encoder is reused in fine-tuning stage
                for id in range( len(field_names) ):
                    field_output = Predicted_Features[:, :, id]
                    field_target = field_info_test_tensors[f'field_info_{field_names[id]}']
                    field_loss = criterion(field_output, field_target)
                    test_losses[id] = field_loss.item()
                    test_loss += field_loss
            mse_loss_Unifed_test = criterion(Unified_Feature_output_test, LR_Unified_test)

            test_losses[ len(field_names) ] = mse_loss_Unifed_test
            test_loss += mse_loss_Unifed_test
            if EVALUATE is True and (epoch + 1) % N_REPORT == 0:
                baseF = PreTrained_net.PosNet(Y_test)
                unstandardized_test_output = unstandardize_features(Unified_Feature_output_test, mean_test_tensors[f'Unified'], std_test_tensors[f'Unified'])
                Global_Unified_field_outputs = []
                for field_name, field_net in PreTrained_net.field_nets.items(): # Generate all the fields
                    coef = field_net(unstandardized_test_output)
                    combine = coef * baseF
                    Global_Unified_field_output = torch.sum(combine, dim=2, keepdim=True)
                    Global_Unified_field_outputs.append(Global_Unified_field_output)
                Global_Unified_Gout = torch.cat(Global_Unified_field_outputs, dim=-1) #   All the field_idx(th) field results from Global_Unified_U
                field_loss_data, field_losses = custom_mse_loss(Global_Unified_Gout, G_test, G_max_test, field_weights)
                Total_Field_test_loss_Data += field_loss_data
                for j, loss_item in enumerate(field_losses):
                    Field_test_loss[j] += loss_item
        
        test_batch_count += 1
        test_loss /= test_batch_count
        test_losses /= test_batch_count
        Total_Field_test_loss_Data /= test_batch_count
        Field_test_loss /= test_batch_count

        if EVALUATE is False:
            combined_loss = train_loss_weight*mse_loss_Unifed_train + test_loss_weight*mse_loss_Unifed_test
        elif EVALUATE is True:
            combined_loss = train_loss_weight*Total_Field_train_loss_Data + test_loss_weight*Total_Field_test_loss_Data
        else:
            print(f'EVALUATE is {EVALUATE}, not correctly defined!!!')
            exit(0)

        # Print and write to CSV 
        if (epoch + 1) % N_REPORT == 0:

            print(f'Epoch {epoch+1}/{N_EPOCH}')
            print()

            print(f'Epoch {epoch+1}/{N_EPOCH}, for feature retrieving, Train Loss: {train_loss.item()}, Test Loss: {test_loss.item()}')
            for id in range( len(field_names) ):
                print(f'Train Loss for field {field_names[id]}: {train_losses[id].item()}, Test Loss for field {field_names[id]}: {test_losses[id].item()}')
            print(f'Train Loss for Unifed feature: {train_losses[ len(field_names) ].item()}, Test Loss for Unifed feature: {test_losses[ len(field_names) ].item()}')
            print()

            if EVALUATE is True:
                print(f'Total Field Train Loss: {Total_Field_train_loss_Data.item()}, Total Field Test Loss: {Total_Field_test_loss_Data.item()}')
                for id, field_name in enumerate(field_names):
                    print(f'Train Loss for field {field_name}: {Field_train_loss[id].item()}, Test Loss for field {field_name}: {Field_test_loss[id].item()}')
                print()

                with open(f'Loss_csv/train_test_loss_reconstruction/Reconstruct_loss_From{field_idx}_{NET_NAME[NET_TYPE]}.csv', 'at', newline='') as fp:
                    writer = csv.writer(fp, delimiter='\t')
                    if ((epoch + 1) // N_REPORT == 1):
                        header = ['Epoch', 'Overall_Train_Loss', 'Overall_Test_Loss']
                        interleaved_field_names = [fn for field_name in field_names for fn in (f'Train_{field_name}_loss', f'Test_{field_name}_loss')]
                        header.extend(interleaved_field_names)
                        writer.writerow(header)

                    row_data = [epoch + 1, Total_Field_train_loss_Data.item(), Total_Field_test_loss_Data.item()] 
                    # Combine train and test losses for each field into pairs
                    for field_train_loss, field_test_loss in zip(Field_train_loss, Field_test_loss):
                        row_data.append(f'{field_train_loss.item()}')
                        row_data.append(f'{field_test_loss.item()}')
                    writer.writerow(row_data)

            # Write to CSV file
            with open(f'Loss_csv/train_test_loss_reconstruction/train_test_loss_S2F_From{field_idx}_{NET_NAME[NET_TYPE]}.csv', 'at', newline='') as fp:
                writer = csv.writer(fp, delimiter='\t')
                if ((epoch + 1) // N_REPORT == 1):
                    fp.write(NET_SETTINGS)
                    header = ['Epoch', 'Train_Loss', 'Test_Loss']
                    interleaved_field_names = ['Train_Unifed_loss', 'Test_Unified_loss']
                    header.extend(interleaved_field_names)
                    interleaved_field_names = [fn for name in field_names + ['Unified_feature'] for fn in (f'Train_{name}_loss', f'Test_{name}_loss')]
                    header.extend(interleaved_field_names)
                    writer.writerow(header)
                
                row_data = [epoch + 1, train_loss.item(), test_loss.item()] + [train_losses[ len(field_names) ].item(), test_losses[ len(field_names) ].item()] + \
                            [item for pair in zip(train_losses.tolist(), test_losses.tolist()) for item in pair]
                writer.writerow(row_data)

            # Determine whether should trigger early stopping
            if ( combined_loss < best_combined_loss ):
                best_combined_loss = combined_loss
                print(f'Best combined loss so far is {best_combined_loss}, still improving')
                counter = 0
                
                model_save_path = 'Output_Net/net_{}_state_dict.pth'.format(NET_NAME[NET_TYPE])
                torch.save(net.module.state_dict(), model_save_path)
                print('Successfully saved the latest best net at {}'.format(model_save_path))
                print('...Successfully Saved net.pic')
                print()

            else:
                counter += 1
                print(f'Best combined loss so far is {best_combined_loss}, NOT further improving')
                print(f'The counter for triggering early stopping is {counter}')
                print()
                if counter >= patience:
                    print("Early stopping triggered")
                    break
    
    
                
                


