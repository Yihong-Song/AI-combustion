
import io
import csv
import numpy as np 
import os
import time

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import pickle

from torch import nn 
from constant import DataSplit 
from network import CoFFe_PreTrain_Net_MutualEncodingMode

torch.set_default_tensor_type('torch.cuda.FloatTensor')

# Specify the GPUs to use
device_ids = [0]
device = torch.device(f"cuda:{device_ids[0]}" if torch.cuda.is_available() else "cpu")

#__________________________PARAMETERS_________________________________
N_EPOCH = 100000
N_P_Selected = 50   # The number of random sparse sensors in each pre-training epoch
n_field_info = 24   # The dimension of latent features to be extracted from fied distribution data
n_baseF = 40        # The dimension of output layers of DeepONet-based decoder

field_names = ['vof', 'j', 'vel_p1', 'vel_p2']
part = 'Cathode'
Unified_Weight = 5.0 # Contribution of the unified feature

# FieldAttention layer parameters
num_heads = 9
num_layers = 1

PRINT_NUM = int(20)
NET_SETTINGS = f'Unified_Weight = {Unified_Weight}\tn_field_info = {n_field_info}\tMultiHeadAttention={num_heads} & layer={num_layers}\tn_baseF = {n_baseF}\n'
NET_NAME = f'MutualEncoding_{n_field_info}'
#____________________________________________________________________

def weights_init(m):
    if isinstance(m, nn.Linear):
        torch.nn.init.kaiming_uniform_(m.weight)
        if m.bias is not None:
            torch.nn.init.zeros_(m.bias)

def get_data_iter(U, Y, G, G_max, N = N_P_Selected, batch_size = 360): 
    num_examples = len(U)
    num_points = Y.shape[1]
    indices = list(range(num_examples))
    np.random.shuffle(indices)  
    for i in range(0, num_examples, batch_size):
        j = torch.LongTensor(indices[i: min(i + batch_size, num_examples)]) 
        j = j.to(device)

        selected_points = torch.randperm(num_points)[:N].to(device)
        yield  U.index_select(0, j), Y.index_select(0, j).index_select(1, selected_points), G.index_select(0, j).index_select(1, selected_points), G_max.index_select(0,j)

def field_custom_mse_loss(output, target, target_max, field_idx, field_weights):

    num_fields = target.size(-1)
    total_loss = 0
    weighted_total_loss = 0
    field_losses = torch.zeros(num_fields+1).to(device)

    for id in range(num_fields + 1):

        target_max_k = target_max[:, :, field_idx]
        target_max_k = torch.clamp(target_max_k, min=0.1)

        field_output = output[:, :, id] #   The reconstructed field_idx(th) field from id(th) field or Unified
        field_target = target[:, :, field_idx]  # Ground truth of the field_idx(th) field
        field_loss = torch.mean(((field_output - field_target) / target_max_k) ** 2)
        

        field_losses[id] = field_loss.item()
        total_loss += field_loss
        
        field_weight = field_weights[id] if id < len(field_names) else 5.0
        weighted_total_loss += field_weight * field_loss
    
    sorted_losses, sorted_indices = torch.sort(field_losses[:num_fields])

    return weighted_total_loss, total_loss, field_losses, sorted_indices.tolist()

def custom_mse_loss(output, target, target_max):

    num_fields = target.size(-1)
    total_loss = 0
    field_losses = torch.zeros(num_fields)

    for field_idx in range(num_fields):
        target_max_k = target_max[:, :, field_idx]
        target_max_k = torch.clamp(target_max_k, min=0.1)
        field_output = output[:, :, field_idx]
        field_target = target[:, :, field_idx]
        field_loss = torch.mean(((field_output - field_target)/target_max_k) ** 2).to(device)        
        field_losses[field_idx] = field_loss.item()
        total_loss += field_loss

    return total_loss, field_losses

if __name__ == '__main__':

    for field_idx in range(len(field_names)):   # Saving losses to reconstruct the field_idx(th) field from [all fields & Unifed]
        with open(f'Loss_csv/train_test_loss_MutualEncoding/train_test_loss_{NET_NAME}_For_{field_names[field_idx]}_N{N_P_Selected}.csv', 'wt') as fp:
            pass
        with open(f'Loss_csv/train_test_loss_MutualEncoding/train_test_loss_{NET_NAME}_GlobalUnifed_N{N_P_Selected}.csv', 'wt') as fp:
            pass

    with open(os.path.join('Original_Split', part, f'data_split.pic'), 'rb') as fp:
        data_split = pickle.load(fp)

        U_train = data_split.U_train.to(device)
        Y_train = data_split.Y_train.to(device)
        G_train = data_split.G_train.to(device)
        print('G_train is: ', G_train.shape)
        print('U_train is: ', U_train.shape)
        print('Y_train is: ', Y_train.shape)

        G_train[:, :, 0] = -1 * torch.log(G_train[:, :, 0] + 1e-7)
        G_train[:, :, 2] = -1 * torch.log(G_train[:, :, 2] + 1e-7)
        G_train[:, :, 3] = -1 * torch.log(G_train[:, :, 3] + 1e-7)
        G_train_max, _ = torch.max(G_train, axis=1, keepdim=True)
        G_train_min, _ = torch.min(G_train, axis=1, keepdim=True)

        print('G_train is: ', G_train.shape)
        print('G_train_max.shape is: ', G_train_max.shape)
        print('G_train_max is: ', G_train_max.shape)
        print('G_train_min is: ', G_train_min.shape)

        train_min = torch.min(G_train)
        print('train_min is: ', train_min)
        train_max = torch.max(G_train)
        print('train_max is: ', train_max)

        U_test = data_split.U_test.to(device)
        Y_test = data_split.Y_test.to(device)
        G_test = data_split.G_test.to(device)

        G_test[:, :, 0] = -1 * torch.log(G_test[:, :, 0] + 1e-7)
        G_test[:, :, 2] = -1 * torch.log(G_test[:, :, 2] + 1e-7)
        G_test[:, :, 3] = -1 * torch.log(G_test[:, :, 3] + 1e-7)
        
        G_test_max, _ = torch.max(G_test, axis=1, keepdim=True)
        G_test_min, _ = torch.min(G_test, axis=1, keepdim=True)

        n_inputF = U_train.shape[-1]
        n_pointD = Y_train.shape[-1]


    field_weights_default = torch.tensor([1.0] * len(field_names))  # Replace with actual weights if needed
    field_weights_default = field_weights_default.to(device)

    net = CoFFe_PreTrain_Net_MutualEncodingMode(n_field_info, n_baseF, num_heads, num_layers, num_fields=len(field_names)).to(device)

    # Wrap the model with DataParallel 
    net = nn.DataParallel(net, device_ids=device_ids)
    net.to(device)
    net.apply(weights_init)

    optimizer = optim.Adam(net.parameters(), lr=0.00050) 
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.98, patience=500, verbose=True, min_lr=0.0002)

    # Set up early stopping parameters
    patience = 500
    best_combined_loss = float('5.0') #Initial threshold to determine early stopping
    counter = 0
    train_loss_weight = 0.15
    test_loss_weight = 0.85

    Field_weights_All = torch.zeros(len(field_names), len(field_names))
    Field_weights_All = Field_weights_All.fill_(1.0).to(device)

    # Create an empty tensor of the appropriate size
    att_index = torch.empty((len(field_names), len(field_names)), dtype=torch.long)  # Use dtype=torch.long for indices
    # Fill each row with a unique random permutation
    for i in range(len(field_names)):
        att_index[i] = torch.randperm(len(field_names))
    # Move the tensor to the specified device
    att_index = att_index.to(device)
    # print('att_index is ', att_index)

    for epoch in range(N_EPOCH):
        optimizer.zero_grad()
        Total_train_loss_Data = 0 # the total losses from all generated fields from each field: Loss_T = Sigma(i) Sigma(j) Field_j(Generated from Field_i)
        Total_test_loss_Data = 0
        train_loss = torch.zeros(len(field_names), device=device)  
        test_loss = torch.zeros(len(field_names), device=device)  

        Unified_train_loss = 0 
        Unified_test_loss = 0

        Unified_train_losses = torch.zeros(len(field_names), device=device)  
        Unified_test_losses = torch.zeros(len(field_names), device=device)  

        # Initialize a two-dimensional tensor for training losses
        train_losses = torch.zeros(len(field_names), len(field_names)+1, device=device)  
        test_losses = torch.zeros(len(field_names), len(field_names)+1, device=device)  

        train_batch_count = 0
        test_batch_count = 0

        for U, Y, G, G_max in get_data_iter(U_train, Y_train, G_train, G_train_max):
            G.to(device)
            G_max.to(device)
            optimizer.zero_grad()
            att_index_expanded = att_index.unsqueeze(0).repeat(len(device_ids), 1, 1)

            output, Unified_output = net(U, Y, G, num_heads)
            output_stacked = torch.stack(output, dim=0) 
            loss = 0
            
            for field_idx in range(len(field_names)):  # Calculating the losses to reconstruct field_idx(th) field from all fields
                
                output_Select = output_stacked[field_idx, :, :, :] # Picking out the reconstructed field_idx(th) field results from all fields & Unified
                
                field_weights = Field_weights_All[field_idx, :]
                weighted_loss_data, loss_data, losses, sorted_indices = field_custom_mse_loss(output_Select, G, G_max, field_idx, field_weights)  
                loss += weighted_loss_data

                att_index[field_idx] = torch.tensor(sorted_indices, dtype=torch.int32)
                               
                Total_train_loss_Data += loss_data
                train_loss[field_idx] += loss_data
                # Update train_losses for the current field or unified feature
                for j, loss_item in enumerate(losses):
                    train_losses[field_idx, j] += loss_item

            # Losses for reconstructing all fields from the Global Unified representation
            Unifed_loss_data, Unifed_losses = custom_mse_loss(Unified_output, G, G_max)
            loss += Unifed_loss_data * Unified_Weight
            Total_train_loss_Data += Unifed_loss_data
            Unified_train_loss += Unifed_loss_data
            Unifed_losses = Unifed_losses.to(device)
            for j, loss_item in enumerate(Unifed_losses):
                Unified_train_losses[j] += loss_item

            train_batch_count += 1
            loss.backward()
            optimizer.step()
            scheduler.step(loss)            

        train_loss /= train_batch_count
        train_losses /= train_batch_count
        Unified_train_loss /= train_batch_count
        Unified_train_losses /= train_batch_count
        Total_train_loss_Data /= train_batch_count

        if (epoch + 1) % PRINT_NUM == 0:

            with torch.no_grad():  # Make sure  to use no_grad for evaluation in test phase

                for U, Y, G, G_max in get_data_iter(U_test, Y_test, G_test, G_test_max):
                    output, Unified_output = net(U, Y, G, num_heads)
                    output_stacked = torch.stack(output, dim=0) 
                    
                    for field_idx in range(len(field_names)):  # Calculating the losses to reconstruct field_idx(th) field from all fields
                        
                        output_Select = output_stacked[field_idx, :, :, :] # Picking out the reconstructed field_idx(th) field results from all fields & Unified                        
                        field_weights = Field_weights_All[field_idx, :] 
                        weighted_loss_data, loss_data, losses, sorted_indices = field_custom_mse_loss(output_Select, G, G_max, field_idx, field_weights)  
                                        
                        Total_test_loss_Data += loss_data
                        test_loss[field_idx] += loss_data
                        # Update train_losses for the current field or unified feature
                        for j, loss_item in enumerate(losses):
                            test_losses[field_idx, j] += loss_item

                    # Losses for reconstructing all fields from the Global Unified representation
                    Unifed_loss_data, Unifed_losses = custom_mse_loss(Unified_output, G, G_max)
                    Total_test_loss_Data += Unifed_loss_data
                    Unified_test_loss += Unifed_loss_data
                    Unifed_losses = Unifed_losses.to(device)
                    for j, loss_item in enumerate(Unifed_losses):
                        Unified_test_losses[j] += loss_item

                    test_batch_count += 1
            
            test_loss /= test_batch_count
            test_losses /= test_batch_count
            Unified_test_loss /= test_batch_count
            Unified_test_losses /= test_batch_count
            Total_test_loss_Data /= test_batch_count
            
            combined_loss = train_loss_weight*Unified_train_loss + test_loss_weight*Unified_test_loss

            print(f'Epoch {epoch+1}/{N_EPOCH}, Total Train Loss: {Total_train_loss_Data.item()}; Total Test Loss: {Total_test_loss_Data.item()}')
            for field_idx, field_name in enumerate(field_names):
                print(f'Sub-total Train Loss for {field_name}: {train_loss[field_idx].item()}; Sub-total Test Loss for {field_name}: {test_loss[field_idx].item()}')
                print(f'Train Loss for {field_name} from {field_name}: {train_losses[field_idx, field_idx].item()}; Test Loss for {field_name} from {field_name}: {test_losses[field_idx, field_idx].item()}')
                print(f'Train Loss for {field_name} from Unified: {train_losses[field_idx, len(field_names)].item()}; Test Loss for {field_name} from Unified: {test_losses[field_idx, len(field_names)].item()}')
                print()
            
            print(f'Total Train Loss for Unified feature: {Unified_train_loss.item()}; Total Test Loss for Unified feature: {Unified_test_loss.item()}')
            for field_idx, field_name in enumerate(field_names):
                print(f'Unifed Train Loss for {field_name}: {Unified_train_losses[field_idx].item()}; Unified Test Loss for {field_name}: {Unified_test_losses[field_idx].item()}')

            # Write to CSV file
            for field_idx in range(len(field_names)):
                # Determine field name or unified feature
                with open(f'Loss_csv/train_test_loss_MutualEncoding/train_test_loss_{NET_NAME}_For_{field_names[field_idx]}_N{N_P_Selected}.csv', 'at', newline='') as fp:
                    writer = csv.writer(fp, delimiter='\t')
                    if ((epoch + 1) // PRINT_NUM == 1):
                        fp.write(NET_SETTINGS)
                        header = ['Epoch', 'Overall_Train_Loss', 'Overall_Test_Loss']
                        interleaved_field_names = [fn for name in field_names + ['Unified_feature'] for fn in (f'Train_{name}_loss', f'Test_{name}_loss')]
                        header.extend(interleaved_field_names)
                        writer.writerow(header)

                    row_data = [epoch + 1, train_loss[field_idx].item(), test_loss[field_idx].item()] + \
                            [item for pair in zip(train_losses[field_idx].tolist(), test_losses[field_idx].tolist()) for item in pair]
                    writer.writerow(row_data)
            with open(f'Loss_csv/train_test_loss_MutualEncoding/train_test_loss_{NET_NAME}_GlobalUnifed_N{N_P_Selected}.csv', 'at', newline='') as fp:
                writer = csv.writer(fp, delimiter='\t')
                if ((epoch + 1) // PRINT_NUM == 1):
                    fp.write(NET_SETTINGS)
                    header = ['Epoch', 'Overall_Train_Loss', 'Overall_Test_Loss']
                    interleaved_field_names = [fn for name in field_names for fn in (f'Train_{name}_loss', f'Test_{name}_loss')]
                    interleaved_field_names.append('att_index')
                    header.extend(interleaved_field_names)
                    writer.writerow(header)

                row_data = [epoch + 1, Unified_train_loss.item(), Unified_test_loss.item()] + \
                        [item for pair in zip(Unified_train_losses.tolist(), Unified_test_losses.tolist()) for item in pair] 
                writer.writerow(row_data)

            # Determine whether should trigger early stopping every 200 epochs
            if ( combined_loss < best_combined_loss ):
                best_combined_loss = combined_loss
                print(f'Best combined loss so far is {best_combined_loss}, still improving')
                counter = 0
                
                model_save_path = f'Output_Net/net_{NET_NAME}_state_dict_N{N_P_Selected}.pth'
                torch.save(net.module.state_dict(), model_save_path)
                print('Successfully saved the latest best net at {}'.format(model_save_path))
            else:
                counter += 1
                print(f'Best combined loss so far is {best_combined_loss}, NOT further improving')
                print(f'The counter for triggering early stopping is {counter}')
                if counter >= patience:
                    print("Early stopping triggered")
                    break
            
