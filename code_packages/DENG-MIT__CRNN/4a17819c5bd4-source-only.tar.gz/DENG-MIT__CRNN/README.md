# CRNN (Chemical Reaction Neural Network)

CRNN is an interpretable neural network architecture for autonomously inference chemical reaction pathways in various chemical systems. It is designed based on the following two fundamental physics laws: the Law of Mass Action and Arrhenius Law. It is also possible to incorporate other physics laws to adapt CRNN to a specific domain.

<p align="center">
<img src="./assets/CRNN_TOC.png" width="500">
</p>

You can find the common questions regarding CRNN in the [FAQs](https://github.com/DENG-MIT/CRNN/wiki/FAQs).

# Structure of this repo

This repo provides the case studies presented in the original CRNN paper as well as ongoing preliminary results on other systems. Currently, this includes:

* Cases 1-3 ([original CRNN paper](https://pubs.acs.org/doi/full/10.1021/acs.jpca.0c09316)) **requires Julia 1.6
* Cathode thermal decomposition modeling ([2023 Journal of Power Sources paper](https://doi.org/10.1016/j.jpowsour.2023.233443)) *updated for Julia 1.11.1, Project and Manifest files included
* Cathode UQ modeling via Bayesian CRNN ([2024 Proceedings of the Combustion Instititue paper](https://doi.org/10.1016/j.proci.2024.105243) and [2025 Chemical Engineering Journal paper](https://doi.org/10.1016/j.cej.2025.160402)) *updated for Julia 1.11.1, Project and Manifest files included
* Gene regulatory network (preliminary results) **requires Julia 1.6
* Oscillations in yeast glycolysis (preliminary results) **requires Julia 1.6
* Systems with strong stiffness (Robertson's problem) **requires Julia 1.6
* Gas-phase combustion kinetics (`HyChem`) **requires Julia 1.6

Other github repositories containing CRNN materials are:

* [Biomass pyrolysis kinetics](https://github.com/DENG-MIT/CRNN-Pyrolysis), later updated to [this repository](https://github.com/DENG-MIT/Biomass.jl) ([2022 Combustion and Flame paper](https://doi.org/10.1016/j.combustflame.2022.111992))
* [Cell signaling pathways for quantitative modeling drug effects](https://github.com/jiweiqi/CellBox.jl)

Inside each folder, such as case 1/2/3, you will find at least two Julia codes. One for training and the other one for weight pruning. Those two files are identical, except that the weight pruning includes a function to prune the CRNN weights to further encourage sparsity.

The cathode folder does not contain a weight pruning code. The study in this folder involves parameter optimization with existing knowledge of the mechanism's structure, thus pruning is redundant.

# Get Started

Have a look at the code for [case 2](https://github.com/DENG-MIT/CRNN/blob/main/case2/case2.jl). The script consists of the following parts:
* Hyper-parameter settings
* Generate synthesized data
* Define the neural ODE problem
* Train CRNN using ADAM

**Julia version recommendations are included above for each directory. Incorrect versions may lead to indexing issues and convergence to incorrect mechanisms. As of the current commit in September 2025, active development of CRNN capabilities is ongoing. If compatibility is required with different versions of Julia, please reach out to the authors [here](https://deng.mit.edu/people.html).**

# Cite
**Base CRNN (cases 1-3):**

- Ji, Weiqi, and Deng, Sili. "Autonomous Discovery of Unknown Reaction Pathways from Data by Chemical Reaction Neural Network." The Journal of Physical Chemistry A, (2021), 125, 4, 1082–1092, [acs](https://pubs.acs.org/doi/full/10.1021/acs.jpca.0c09316)/[arXiv](https://arxiv.org/abs/2002.09062)


**Cathode thermal decomposition CRNN (cathode folder):**

- Koenig, Benjamin C., Peng Zhao, and Sili Deng. "Accommodating physical reaction schemes in DSC cathode thermal stability analysis using chemical reaction neural networks." Journal of Power Sources 581 (2023) 233443. https://doi.org/10.1016/j.jpowsour.2023.233443 

(please note training data in this case is adapted from https://doi.org/10.1016/j.jpowsour.2021.230582).

**Cathode UQ study using Bayesian CRNN (based directly on the initial Cathode study above):** 
- B.C. Koenig, H. Chen, Q. Li, P. Zhao, S. Deng, Uncertain lithium-ion cathode kinetic decomposition modeling via Bayesian chemical reaction neural networks, Proceedings of the Combustion Institute 40 (2024) 105243. https://doi.org/10.1016/j.proci.2024.105243
- B.C. Koenig, P. Zhao, S. Deng, Comprehensive thermal-kinetic uncertainty quantification of lithium-ion battery thermal runaway via bayesian chemical reaction neural networks, Chemical Engineering Journal 507 (2025) 160402. https://doi.org/10.1016/j.cej.2025.160402

**Biomass CRNN (see https://github.com/DENG-MIT/Biomass.jl):**

- Ji, Weiqi, Franz Richter, Michael J. Gollner, and Sili Deng. "Autonomous kinetic modeling of biomass pyrolysis using chemical reaction neural networks." Combustion and Flame 240 (2022) 111992. https://doi.org/10.1016/j.combustflame.2022.111992
