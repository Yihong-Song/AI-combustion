## Proposed Changes
*Give a brief overview of your contribution here in a few sentences.*



## Related Work
*Resolve any issues (bug fix or feature request), note any related PRs, or mention interactions with the work of others, if any.*



## PR Checklist
*Put an X by all that apply. You can fill this out after submitting the PR. If you have any questions, don't hesitate to ask! We want to help. These are a guide for you to know what the reviewers will be looking for in your contribution.*

- [ ] I am submitting my contribution to the develop branch.
- [ ] I have added a unit/regression test, if applicable.
- [ ] I have sufficiently commented my changes.
- [ ] My code does not generate any compiler warnings when compiling ```main.cpp``` with the ```-Wall``` flag.
