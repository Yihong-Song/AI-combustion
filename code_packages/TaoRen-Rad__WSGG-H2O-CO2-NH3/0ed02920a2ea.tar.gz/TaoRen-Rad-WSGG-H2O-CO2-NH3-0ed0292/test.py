import torch
import numpy as np
from PINN_WSGG.nn_wsgg import load_wsgg, nn_wsgg_rte
from PINN_WSGG.plot_setup import setup
from matplotlib import pyplot as plt

device = "cpu"
dtype = torch.float32

if __name__ == "__main__":
    setup()
    nn_wsgg = load_wsgg(dtype).to(device)
    profiles = torch.tensor(np.load("data/profiles.npy")).to(device, dtype=dtype)
    results = np.load("data/results.npy")

    xs = profiles[:, 0]
    temperature_profiles = profiles[:, 4]
    x_h2o_profiles = profiles[:, 1]
    x_co2_profiles = profiles[:, 2]
    x_nh3_profiles = profiles[:, 3]

    T_l = torch.tensor(300.0).to(device, dtype=dtype)
    T_r = torch.tensor(300.0).to(device, dtype=dtype)

    wsgg_G, wsgg_q, wsgg_dq = nn_wsgg_rte(
        nn_wsgg,
        xs,
        temperature_profiles,
        x_h2o_profiles,
        x_co2_profiles,
        x_nh3_profiles,
        T_l,
        T_r,
    )

    plot_xs = profiles[:, 0].cpu().numpy()
    nn_wsgg_dq = wsgg_dq  

    fig, ax = plt.subplots(1, 1, figsize=[2.5, 2])

    # LBL (kW/m^3)
    ax.plot(plot_xs, results[:, -1] / 1e3, "b", label="LBL")

    # PINN-WSGG：red hollow circles
    ax.plot(
        plot_xs[::5],
        (nn_wsgg_dq.detach().cpu().numpy().flatten() / 1e3)[::5],
        "ro",
        markerfacecolor="none",
        markersize=4,
        markeredgewidth=1,
        label="PINN-WSGG",
    )

    min_val = np.min(results[:, -1]) / 1e3
    max_val = np.max(results[:, -1]) / 1e3
    diff_val = max_val - min_val
    ax.set_ylim([min_val - diff_val * 0.1, max_val + diff_val * 1.2])

    lbl = results[:, -1]
    nn = nn_wsgg_dq.detach().cpu().numpy().flatten()
    lbl_diff = np.max(lbl) - np.min(lbl)
    me_nn = np.mean(np.abs(lbl - nn) / lbl_diff)

    ax.set_xlabel("$x$ [m]")
    ax.set_xlim([np.min(plot_xs), np.max(plot_xs)])

    ax.set_ylabel(r"$\nabla\cdot q$ [kW/m$^3$]")
    ax.legend(loc="upper right")

    plt.tight_layout()
    fig.savefig("test_case.png")
