# WSGG-H₂O-CO₂-NH₃

> A Physics-Informed Neural Network (PINN) based Weighted Sum of Gray Gases (WSGG) model for radiative heat transfer in H₂O–CO₂–NH₃ participating-gas mixtures.

---

## Overview

This repository implements a PINN-WSGG model for accurate and efficient prediction of radiative properties in multi-component gas mixtures containing H₂O, CO₂, and NH₃. The model is validated against Line-by-Line (LBL) benchmark data through a 1D Radiative Transfer Equation (RTE) solver.

**Key features:**

- PINN-WSGG model for H₂O / CO₂ / NH₃ gas mixtures
- 1D Radiative Transfer Equation (RTE) solver
- Validation against Line-by-Line (LBL) benchmark data
- Automated generation of comparison figures

---

## Installation and Usage

1. Clone the repository:
```bash
   git clone https://github.com/your-username/WSGG-H2O-CO2-NH3.git
   cd WSGG-H2O-CO2-NH3
```

2. Install the required dependencies:
```bash
   pip install -r requirements.txt
```

3. Run the test script:
```bash
   python test.py
```

The script performs the following steps:

- Loads pre-trained PINN-WSGG model parameters from `PINN_WSGG/data/wsgg.json`
- Loads test profiles from `data/profiles.npy` and LBL benchmark results from `data/results.npy`
- Solves a 1D RTE problem using the PINN-WSGG model for the H₂O–CO₂–NH₃ mixture
- Compares the volumetric radiative heat loss (∇·q) against LBL reference data
- Exports the resulting comparison figure as `test_case.png`

---

## Output

![Test Output](test_case.png)

---

## Repository Structure
```
WSGG-H2O-CO2-NH3/
├── data/
│   ├── profiles.npy          # Thermochemical solution profiles (x, species volume fractions, temperature)
│   └── results.npy           # LBL benchmark reference results
├── PINN_WSGG/                # Core implementation package
│   ├── __init__.py
│   ├── nn_wsgg.py            # Neural network WSGG model and RTE wrapper
│   ├── mlp.py                # Multi-layer perceptron architecture
│   ├── rte.py                # Radiative transfer equation solver
│   ├── plot_setup.py         # Plotting and figure configuration
│   └── data/
│       └── wsgg.json         # Pre-trained model parameters
├── test.py                   # Test script — runs the case and generates the plot
├── test_case.png             # Example output figure
├── requirements.txt          # Python dependencies
├── README.md                 # This document
├── LICENSE                   # License information
└── .gitignore
```

---

## Cite as

If you use this work in your research, please cite as follows,

```bibtex
@article{Wang2026PINNWSGGNH3,
  title = {Physics-informed neural network {WSGG} model for radiative heat transfer in {H$_2$O}--{CO$_2$}--{NH$_3$} gas mixtures relevant to ammonia combustion},
  author = {Wang, Jiaxin and Chen, Wei and Ren, Tao},
  year = {2026},
  journal = {Proceedings of the Combustion Institute},
  volume = {42},
  pages = {106476},
  issn = {1540-7489},
  doi = {10.1016/j.proci.2026.106476}
}
```

J. Wang, W. Chen, and T. Ren, “Physics-informed neural network WSGG model for radiative heat transfer in H₂O–CO₂–NH₃ gas mixtures relevant to ammonia combustion,” *Proceedings of the Combustion Institute*, vol. 42, Article 106476, 2026, doi: [10.1016/j.proci.2026.106476](https://doi.org/10.1016/j.proci.2026.106476).

---
## License

This project is released under the **MIT License** — see the [`LICENSE`](LICENSE) file for details.
