# AL-GA: Active Learning Guided Genetic Algorithm Framework for Combustion Mechanism Optimization

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

Companion repository for the paper *"An Active Learning Guided Genetic Algorithm Framework with Surrogate Modeling for Reduced Combustion Mechanism Optimization and Kinetic Analysis of NH<sub>3</sub>/H<sub>2</sub>/n-Heptane Combustion"* (Applied Energy, 2025).

## Contents

```
framework/
├── src/workflows/    # Six-stage AL-GA optimization pipeline (01–09)
├── tests/            # Five unit tests (pytest)
└── data/             # Benchmark datasets (64 IDT + 65 LFS conditions)
```

## Workflow Scripts

| Script | Stage |
|--------|-------|
| `01_generate_conditions.py` | Sobol-sequence parameter-space sampling |
| `03_run_compute.py` | Parallel Cantera computation |
| `04_train_xgboost.py` | XGBoost surrogate benchmark |
| `04c_train_catboost.py` | CatBoost surrogate training (primary) |
| `05_prepare_ground_truth.py` | Ground-truth data preparation |
| `06_lambda_selection.py` | Regularization parameter selection |
| `07_active_learning_ga.py` | Active learning loop (XGBoost) |
| `07b_active_learning_catboost.py` | Active learning loop (CatBoost) |
| `08_analyze_model_errors.py` | Surrogate error analysis |
| `08_baseline_ga_experiment.py` | Baseline GA comparison |
| `09_analyze_optimization_results.py` | Optimization result analysis |

## Testing

```bash
pip install -r requirements.txt
pytest framework/tests/ -v
```

## Citation

See [CITATION.cff](CITATION.cff) for machine-readable metadata.

## License

MIT License. See [LICENSE](LICENSE).

## Notes

- **Mechanism files are not distributed.** Users must supply their own Cantera-format mechanism (`.yaml`).
- **Pre-trained models are not distributed.** CatBoost models should be trained from source using the provided workflow scripts.
- Benchmark datasets in `framework/data/` reproduce the 64 IDT and 65 LFS conditions used in the paper.
