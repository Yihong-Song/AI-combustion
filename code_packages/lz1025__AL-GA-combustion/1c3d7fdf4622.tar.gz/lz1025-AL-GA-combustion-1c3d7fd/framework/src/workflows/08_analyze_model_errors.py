# =============================================================================
# src/workflows/08_analyze_model_errors.py
# =============================================================================
# 工作流步骤 8/9: 分析模型预测误差
# =============================================================================
#
# 功能：
#   - 分析XGBoost模型在Ground Truth工况点的预测误差
#   - 识别高误差工况和潜在问题区域
#   - 生成误差统计报告和可视化
#
# 核心函数：
#   - analyze_idt_model(): 分析IDT模型误差
#   - analyze_lfs_model(): 分析LFS模型误差
#
# 输入文件：
#   - output/models/idt/model.json: IDT代理模型
#   - output/models/lfs/model.json: LFS代理模型
#   - output/models/idt/feature_list.json: IDT特征列表
#   - output/models/lfs/feature_list.json: LFS特征列表
#   - data/ground_truth/idt_det_reference.csv: IDT Ground Truth
#   - data/ground_truth/lfs_exp_reference.csv: LFS Ground Truth
#   - data/logA_base.npy: 基线logA值
#
# 输出文件：
#   - output/analysis/idt_model_errors.csv: IDT模型误差详情
#     包含：工况参数、预测值、参考值、相对误差、绝对误差
#   - output/analysis/lfs_model_errors.csv: LFS模型误差详情
#   - output/analysis/idt_error_summary.json: IDT误差统计
#   - output/analysis/lfs_error_summary.json: LFS误差统计
#
# 使用方法：
#   python src/workflows/08_analyze_model_errors.py
#   python src/workflows/08_analyze_model_errors.py --model idt
#   python src/workflows/08_analyze_model_errors.py --model lfs
#
# 输出指标：
#   - RMSE: 均方根误差
#   - MAE: 平均绝对误差
#   - MAPE: 平均绝对百分比误差
#   - Max Error: 最大误差
#   - Error Distribution: 误差分布统计
#
# 前置步骤：
#   - 04_train_xgboost.py: 训练模型
#   - 05_prepare_ground_truth.py: 准备Ground Truth
#
# 后续步骤：
#   - 09_analyze_optimization_results.py: 分析优化结果
#
# =============================================================================
# -*- coding: utf-8 -*-



import os
import sys
import json
import argparse
import numpy as np
import pandas as pd
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.core.objective import (
    load_surrogate_models, load_feature_lists, load_ground_truth,
    build_features_batch, predict_idt, predict_lfs
)


def analyze_idt_model(model_path: str, feature_list_path: str, gt_path: str, logA_base_path: str):
    """分析IDT模型在Ground Truth工况点的误差"""
    
    print("=" * 60)
    print("IDT模型误差分析")
    print("=" * 60)
    
    # 加载模型
    model, _ = load_surrogate_models(model_path, model_path)
    features, _ = load_feature_lists(feature_list_path, feature_list_path)
    
    # 加载Ground Truth
    gt_conditions, _ = load_ground_truth(gt_path, gt_path)
    gt_reference = gt_conditions['reference_idt'].values
    
    # 加载logA_base
    logA_base = np.load(logA_base_path)
    
    # 构建特征
    X = build_features_batch(logA_base, gt_conditions, features)
    
    # 预测
    pred_log = predict_idt(model, X, features)
    
    # 模型输出的是 log10(tau_in_seconds)，所以直接转换
    pred_s = 10 ** pred_log
    
    # GT reference_idt 也是秒
    gt_s = gt_reference
    
    # 相对误差
    relative_errors = np.abs(pred_s - gt_s) / gt_s
    log_errors = np.abs(pred_log - np.log10(gt_s))
    
    # 创建结果DataFrame
    results = pd.DataFrame({
        'condition_id': gt_conditions['condition_id'].values if 'condition_id' in gt_conditions.columns else range(len(gt_conditions)),
        'T': gt_conditions['T'].values if 'T' in gt_conditions.columns else gt_conditions['temperature'].values,
        'P_bar': gt_conditions['P_bar'].values,
        'phi': gt_conditions['phi'].values,
        'X_NH3': gt_conditions['X_NH3'].values,
        'X_H2': gt_conditions['X_H2'].values,
        'X_C7': gt_conditions['X_C7'].values,
        'gt_idt_s': gt_reference,
        'pred_idt_s': pred_s,
        'pred_idt_us': pred_s * 1e6,  # 转换为微秒用于显示
        'relative_error': relative_errors,
        'log_error': log_errors
    })
    
    # 统计
    print(f"\n总工况数: {len(results)}")
    print(f"\n相对误差统计:")
    print(f"  平均: {relative_errors.mean():.4f} ({relative_errors.mean()*100:.2f}%)")
    print(f"  最大: {relative_errors.max():.4f} ({relative_errors.max()*100:.2f}%)")
    print(f"  中位数: {np.median(relative_errors):.4f} ({np.median(relative_errors)*100:.2f}%)")
    print(f"  标准差: {relative_errors.std():.4f}")
    
    print(f"\n对数误差统计:")
    print(f"  平均: {log_errors.mean():.4f}")
    print(f"  最大: {log_errors.max():.4f}")
    
    # 高误差工况
    high_error_threshold = 0.3  # 30%
    high_error_mask = relative_errors > high_error_threshold
    n_high_error = high_error_mask.sum()
    print(f"\n高误差工况 (相对误差 > {high_error_threshold*100}%): {n_high_error}/{len(results)}")
    
    if n_high_error > 0:
        print("\n高误差工况详情:")
        high_error_df = results[high_error_mask].sort_values('relative_error', ascending=False)
        for _, row in high_error_df.iterrows():
            print(f"  {row['condition_id']}: T={row['T']}K, phi={row['phi']}, "
                  f"X_NH3={row['X_NH3']}, gt={row['gt_idt_s']:.6f}s, "
                  f"pred={row['pred_idt_s']:.6f}s, err={row['relative_error']*100:.1f}%")
    
    # 按条件分组统计
    print("\n按温度分组误差:")
    for t in sorted(results['T'].unique()):
        mask = results['T'] == t
        mean_err = results.loc[mask, 'relative_error'].mean()
        print(f"  T={t}K: 平均误差={mean_err*100:.2f}%, 工况数={mask.sum()}")
    
    print("\n按当量比分组误差:")
    for phi in sorted(results['phi'].unique()):
        mask = results['phi'] == phi
        mean_err = results.loc[mask, 'relative_error'].mean()
        print(f"  phi={phi}: 平均误差={mean_err*100:.2f}%, 工况数={mask.sum()}")
    
    print("\n按X_NH3分组误差:")
    for x in sorted(results['X_NH3'].unique()):
        mask = results['X_NH3'] == x
        mean_err = results.loc[mask, 'relative_error'].mean()
        print(f"  X_NH3={x}: 平均误差={mean_err*100:.2f}%, 工况数={mask.sum()}")
    
    return results


def analyze_lfs_model(model_path: str, feature_list_path: str, gt_path: str, logA_base_path: str):
    """分析LFS模型在Ground Truth工况点的误差"""
    
    print("=" * 60)
    print("LFS模型误差分析")
    print("=" * 60)
    
    # 加载模型
    _, model = load_surrogate_models(model_path, model_path)
    _, features = load_feature_lists(feature_list_path, feature_list_path)
    
    # 加载Ground Truth
    _, gt_conditions = load_ground_truth(gt_path, gt_path)
    gt_reference = gt_conditions['reference_lfs_ms'].values
    
    # 加载logA_base
    logA_base = np.load(logA_base_path)
    
    # 构建特征
    X = build_features_batch(logA_base, gt_conditions, features)
    
    # 预测
    pred_log = predict_lfs(model, X, features)
    pred_ms = 10 ** pred_log
    
    # reference_lfs_ms 单位是 m/s
    # 计算相对误差
    relative_errors = np.abs(pred_ms - gt_reference) / gt_reference
    
    # 创建结果DataFrame
    results = pd.DataFrame({
        'condition_id': gt_conditions['condition_id'].values if 'condition_id' in gt_conditions.columns else range(len(gt_conditions)),
        'T_u': gt_conditions['T_u'].values if 'T_u' in gt_conditions.columns else gt_conditions['T'].values,
        'P_bar': gt_conditions['P_bar'].values,
        'phi': gt_conditions['phi'].values,
        'X_NH3': gt_conditions['X_NH3'].values,
        'X_H2': gt_conditions['X_H2'].values,
        'X_C7': gt_conditions['X_C7'].values,
        'gt_lfs_ms': gt_reference,
        'pred_lfs_ms': pred_ms,
        'relative_error': relative_errors
    })
    
    # 统计
    print(f"\n总工况数: {len(results)}")
    print(f"\n相对误差统计:")
    print(f"  平均: {relative_errors.mean():.4f} ({relative_errors.mean()*100:.2f}%)")
    print(f"  最大: {relative_errors.max():.4f} ({relative_errors.max()*100:.2f}%)")
    print(f"  中位数: {np.median(relative_errors):.4f} ({np.median(relative_errors)*100:.2f}%)")
    print(f"  标准差: {relative_errors.std():.4f}")
    
    # 高误差工况
    high_error_threshold = 0.3  # 30%
    high_error_mask = relative_errors > high_error_threshold
    n_high_error = high_error_mask.sum()
    print(f"\n高误差工况 (相对误差 > {high_error_threshold*100}%): {n_high_error}/{len(results)}")
    
    if n_high_error > 0:
        print("\n高误差工况详情:")
        high_error_df = results[high_error_mask].sort_values('relative_error', ascending=False)
        for _, row in high_error_df.iterrows():
            print(f"  {row['condition_id']}: T={row['T_u']}K, P={row['P_bar']:.1f}bar, phi={row['phi']}, "
                  f"X_NH3={row['X_NH3']}, gt={row['gt_lfs_ms']:.4f}m/s, "
                  f"pred={row['pred_lfs_ms']:.4f}m/s, err={row['relative_error']*100:.1f}%")
    
    # 按条件分组统计
    print("\n按温度分组误差:")
    for t in sorted(results['T_u'].unique()):
        mask = results['T_u'] == t
        mean_err = results.loc[mask, 'relative_error'].mean()
        print(f"  T={t}K: 平均误差={mean_err*100:.2f}%, 工况数={mask.sum()}")
    
    print("\n按压力分组误差:")
    for p in sorted(results['P_bar'].unique()):
        mask = results['P_bar'] == p
        mean_err = results.loc[mask, 'relative_error'].mean()
        print(f"  P={p:.1f}bar: 平均误差={mean_err*100:.2f}%, 工况数={mask.sum()}")
    
    print("\n按当量比分组误差:")
    phi_bins = [0.7, 0.9, 1.1, 1.3, 1.5]
    for i in range(len(phi_bins)-1):
        mask = (results['phi'] >= phi_bins[i]) & (results['phi'] < phi_bins[i+1])
        if mask.sum() > 0:
            mean_err = results.loc[mask, 'relative_error'].mean()
            print(f"  phi=[{phi_bins[i]}, {phi_bins[i+1]}): 平均误差={mean_err*100:.2f}%, 工况数={mask.sum()}")
    # phi >= 1.3
    mask = results['phi'] >= 1.3
    if mask.sum() > 0:
        mean_err = results.loc[mask, 'relative_error'].mean()
        print(f"  phi>=1.3: 平均误差={mean_err*100:.2f}%, 工况数={mask.sum()}")
    
    print("\n按X_NH3分组误差:")
    for x in sorted(results['X_NH3'].unique()):
        mask = results['X_NH3'] == x
        mean_err = results.loc[mask, 'relative_error'].mean()
        print(f"  X_NH3={x}: 平均误差={mean_err*100:.2f}%, 工况数={mask.sum()}")
    
    return results


def main():
    parser = argparse.ArgumentParser(description='分析模型在Ground Truth工况点的误差')
    parser.add_argument('--model', choices=['idt', 'lfs', 'both'], default='both',
                        help='分析哪个模型')
    args = parser.parse_args()
    
    # 配置路径
    idt_model_path = 'output/models/idt/model.json'
    idt_feature_path = 'output/models/idt/feature_list.json'
    lfs_model_path = 'output/models/lfs/model.json'
    lfs_feature_path = 'output/models/lfs/feature_list.json'
    idt_gt_path = 'data/ground_truth/idt_det_reference_v2.csv'
    lfs_gt_path = 'data/ground_truth/lfs_exp_reference_v2.csv'
    logA_base_path = 'data/ground_truth/logA_base.npy'
    
    # 创建输出目录
    os.makedirs('output/analysis', exist_ok=True)
    
    if args.model in ['idt', 'both']:
        idt_results = analyze_idt_model(idt_model_path, idt_feature_path, idt_gt_path, logA_base_path)
        idt_results.to_csv('output/analysis/idt_model_errors.csv', index=False)
        print(f"\nIDT误差分析结果已保存: output/analysis/idt_model_errors.csv")
    
    if args.model in ['lfs', 'both']:
        lfs_results = analyze_lfs_model(lfs_model_path, lfs_feature_path, lfs_gt_path, logA_base_path)
        lfs_results.to_csv('output/analysis/lfs_model_errors.csv', index=False)
        print(f"\nLFS误差分析结果已保存: output/analysis/lfs_model_errors.csv")


if __name__ == '__main__':
    main()