# =============================================================================
# src/workflows/03_run_compute.py
# =============================================================================
# 工作流步骤 3/9: 并行计算IDT和LFS
# =============================================================================
#
# 功能：
#   - 加载变体参数和工况矩阵
#   - 使用Cantera并行计算点火延迟时间（IDT）和层流火焰速度（LFS）
#   - 支持断点续传、分批保存、增量计算
#   - 自动缓存管理，避免重复计算
#
# 核心函数：
#   - run_compute(): 主流程函数
#   - run_parallel(): 并行计算协调器
#   - create_tasks(): 创建计算任务列表
#   - load_conditions_and_params(): 加载输入数据
#
# 输入文件：
#   - output/conditions/variant_params_*.json: 变体参数（来自步骤1）
#   - output/conditions/idt_conditions_*.csv: IDT工况矩阵（来自步骤1/2）
#   - output/conditions/lfs_conditions_*.csv: LFS工况矩阵（来自步骤1/2）
#
# 输出文件：
#   - output/idt_results.csv: IDT计算结果（40,960条记录）
#   - output/lfs_results.csv: LFS计算结果（24,201条记录）
#   - output/checkpoint.json: 断点续传检查点
#   - output/cache/: 计算缓存目录
#
# 使用方法：
#   python src/workflows/03_run_compute.py -c config/config.yaml
#   python src/workflows/03_run_compute.py --incremental  # 增量计算
#   python src/workflows/03_run_compute.py --test-samples 100  # 测试模式
#
# 并行配置：
#   - 默认：12个进程并行（可在config.yaml中配置n_workers）
#   - 建议：n_workers = CPU核心数 - 2
#
# 计算时间：
#   - IDT: ~5秒/工况
#   - LFS: ~15秒/工况
#   - 总计：约8-12小时（40,960+24,201工况）
#
# 前置步骤：
#   - 01_generate_conditions.py: 生成工况矩阵
#   - 02_optimize_conditions.py: 工况去重（可选但推荐）
#
# 后续步骤：
#   - 04_train_xgboost.py: 训练代理模型
#
# =============================================================================
# -*- coding: utf-8 -*-


import os
import sys

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import json
import logging
import glob
import time
from datetime import datetime
from typing import Callable, Dict, Any, List, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm
from concurrent.futures import ProcessPoolExecutor, as_completed, CancelledError, TimeoutError

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.core.config_loader import load_config, load_config_with_override
from src.core.config_validator import ConfigValidator, ConfigValidationError
from src.core.condition_generator import prepare_condition_for_calc
from src.utils.condition_hash import (
    add_condition_hash,
    find_unique_conditions,
    expand_results_to_variants,
    print_condition_stats,
    get_condition_stats
)
from src.utils.result_cache import (
    ResultCache,
    create_checkpoint_data
)
from src.core.compute_worker import compute_idt_task, compute_lfs_task, compute_lfs_subprocess
from src.core.result_writer import create_idt_result_dict, create_lfs_result_dict

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    encoding='utf-8'
)
logger = logging.getLogger(__name__)


# =============================================================================
# 常量定义
# =============================================================================

CONDITIONS_DIR = "output/conditions"
RESULTS_DIR = "output"
CHECKPOINT_FILE = "output/checkpoint.json"
CHECKPOINT_VERSION = "2.1"


# =============================================================================
# Checkpoint 相关函数
# =============================================================================

def get_latest_file(pattern: str) -> str:
    """获取最新的文件（基于时间戳）"""
    files = glob.glob(pattern)
    if not files:
        return None
    return max(files, key=os.path.getmtime)


def get_conditions_timestamp() -> str:
    """获取工况文件的时间戳"""
    pattern = f"{CONDITIONS_DIR}/idt_conditions_*.csv"
    latest = get_latest_file(pattern)
    if latest:
        basename = os.path.basename(latest)
        parts = basename.replace('.csv', '').split('_')
        if len(parts) >= 3:
            return parts[-2] + parts[-1]
    return None


def get_variant_timestamp() -> str:
    """获取变体文件的时间戳"""
    pattern = f"{CONDITIONS_DIR}/variant_params_*.json"
    latest = get_latest_file(pattern)
    if latest:
        basename = os.path.basename(latest)
        parts = basename.replace('.json', '').split('_')
        if len(parts) >= 3:
            return parts[-2] + parts[-1]
    return None


def save_checkpoint(checkpoint_data: dict):
    """保存完整checkpoint"""
    os.makedirs(os.path.dirname(CHECKPOINT_FILE), exist_ok=True)
    with open(CHECKPOINT_FILE, 'w', encoding='utf-8') as f:
        json.dump(checkpoint_data, f, indent=2, ensure_ascii=False)


def load_checkpoint() -> dict:
    """加载checkpoint，损坏时自动备份"""
    if not os.path.exists(CHECKPOINT_FILE):
        return None
    
    try:
        with open(CHECKPOINT_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        logger.info(f"Checkpoint loaded: v{data.get('version', 'unknown')}")
        return data
    except json.JSONDecodeError as e:
        # JSON格式损坏，备份并返回None
        logger.error(f"Checkpoint file corrupted: {e}")
        backup_path = f"{CHECKPOINT_FILE}.corrupted.{int(time.time())}"
        try:
            os.rename(CHECKPOINT_FILE, backup_path)
            logger.warning(f"Corrupted checkpoint backed up to: {backup_path}")
            logger.warning("Please delete the backup file or fix it manually if you want to recover.")
        except OSError as rename_err:
            logger.error(f"Failed to backup corrupted checkpoint: {rename_err}")
        return None
    except IOError as e:
        logger.error(f"Failed to read checkpoint file: {e}")
        return None


def validate_checkpoint(checkpoint: dict, current_totals: dict, variant_params: list = None) -> Tuple[bool, str, int, int]:
    """
    校验checkpoint是否有效
    
    返回: (is_valid, message, resume_idt, resume_lfs)
    """
    if checkpoint is None:
        return True, "无checkpoint，需从头开始", 0, 0
    
    if checkpoint.get('version') != CHECKPOINT_VERSION:
        return False, f"checkpoint版本过旧 (v{checkpoint.get('version')} -> v{CHECKPOINT_VERSION})", 0, 0
    
    if checkpoint['idt']['total'] != current_totals['idt']:
        return False, f"IDT任务数变化: {checkpoint['idt']['total']} -> {current_totals['idt']}", 0, 0
    
    if checkpoint['lfs']['total'] != current_totals['lfs']:
        return False, f"LFS任务数变化: {checkpoint['lfs']['total']} -> {current_totals['lfs']}", 0, 0
    
    if variant_params is not None:
        saved_reactions = checkpoint.get('meta', {}).get('reaction_indices', [])
        current_reactions = variant_params[0].get('reaction_indices', []) if variant_params else []
        
        if saved_reactions != current_reactions:
            return False, f"反应索引已变化", 0, 0
        
        saved_n_variants = checkpoint.get('meta', {}).get('n_variants', 0)
        current_n_variants = len(variant_params)
        
        if saved_n_variants != current_n_variants:
            return False, f"变体数量变化: {saved_n_variants} -> {current_n_variants}", 0, 0
    
    cond_ts = get_conditions_timestamp()
    if cond_ts and checkpoint['meta'].get('conditions_timestamp') != cond_ts:
        return False, f"工况矩阵已更新", 0, 0
    
    resume_idt = checkpoint['idt'].get('completed', 0)
    resume_lfs = checkpoint['lfs'].get('completed', 0)
    
    return True, "checkpoint有效", resume_idt, resume_lfs


def clear_checkpoint():
    """清除检查点"""
    if os.path.exists(CHECKPOINT_FILE):
        os.remove(CHECKPOINT_FILE)
        logger.info("检查点已清除")


# =============================================================================
# 数据加载函数
# =============================================================================

def load_conditions_and_params() -> Tuple[List[Dict], pd.DataFrame, pd.DataFrame]:
    """加载工况和变体参数"""
    logger.info("加载工况和变体参数...")
    
    # 加载变体参数
    variant_file = get_latest_file(f"{CONDITIONS_DIR}/variant_params_*.json")
    if not variant_file:
        variant_file = f"{CONDITIONS_DIR}/variant_params.json"
    
    if not os.path.exists(variant_file):
        raise FileNotFoundError(f"变体参数文件不存在：{variant_file}")
    
    with open(variant_file, 'r') as f:
        variant_params = json.load(f)
    logger.info(f"  变体参数：{len(variant_params)} 个")
    
    # 加载工况文件（优先使用去重后的唯一工况）
    # 优先级：unique_*_conditions_*.csv > idt_conditions_*.csv > idt_conditions.csv
    idt_file = get_latest_file(f"{CONDITIONS_DIR}/unique_idt_conditions_*.csv")
    if not idt_file:
        idt_file = get_latest_file(f"{CONDITIONS_DIR}/idt_conditions_*.csv")
    if not idt_file:
        idt_file = f"{CONDITIONS_DIR}/idt_conditions.csv"
    
    lfs_file = get_latest_file(f"{CONDITIONS_DIR}/unique_lfs_conditions_*.csv")
    if not lfs_file:
        lfs_file = get_latest_file(f"{CONDITIONS_DIR}/lfs_conditions_*.csv")
    if not lfs_file:
        lfs_file = f"{CONDITIONS_DIR}/lfs_conditions.csv"
    
    if not os.path.exists(idt_file):
        raise FileNotFoundError(f"IDT 工况文件不存在：{idt_file}")
    if not os.path.exists(lfs_file):
        raise FileNotFoundError(f"LFS 工况文件不存在：{lfs_file}")
    
    idt_conditions = pd.read_csv(idt_file)
    lfs_conditions = pd.read_csv(lfs_file)
    logger.info(f"  IDT 工况：{len(idt_conditions)} 条")
    logger.info(f"  LFS 工况：{len(lfs_conditions)} 条")
    
    return variant_params, idt_conditions, lfs_conditions


# =============================================================================
# 通用任务创建函数
# =============================================================================

def create_tasks(
    variant_params: List[Dict],
    conditions: pd.DataFrame,
    mech_file: str,
    compute_config: Dict[str, Any],
    task_type: str,
    test_mode: bool = False,
    max_total_tasks: int = 0
) -> List[Dict]:
    """
    通用任务创建函数
    
    参数:
        variant_params: 变体参数列表
        conditions: 工况 DataFrame（可能包含 variant_id 列，或仅包含唯一工况）
        mech_file: 机理文件路径
        compute_config: 计算配置 (compute 子节)
        task_type: 'IDT' 或 'LFS'
        test_mode: 是否测试模式
        max_total_tasks: 测试模式下总任务数限制（0=不限制）
    
    逻辑:
        - 唯一工况模式（无 variant_id 列）：使用默认变体（variant_id=0）创建任务
        - 原始模式（有 variant_id 列）：为每个变体创建任务
    """
    tasks = []
    
    # === 唯一工况模式：使用默认变体计算所有唯一工况 ===
    if 'variant_id' not in conditions.columns:
        logger.info(f"  检测到唯一工况模式（无 variant_id 列），使用默认变体创建任务")
        
        # 使用第一个变体作为默认变体（variant_id=0）
        default_variant = variant_params[0] if variant_params else None
        if default_variant is None:
            raise ValueError("变体参数列表为空")
        
        # 预转换默认变体参数为 numpy 数组
        A_values = np.array(default_variant['A_values'], dtype=np.float64)
        log10A_values = np.array(default_variant['log10A_values'], dtype=np.float64)
        reaction_indices = default_variant['reaction_indices']
        
        # 为每个唯一工况创建任务（使用默认变体参数）
        for _, cond in conditions.iterrows():
            cond_dict = cond.to_dict()
            cond_prepared = prepare_condition_for_calc(cond_dict)
            
            task = {
                'task_type': task_type,
                'variant_id': 0,  # 默认变体ID
                'condition_hash': cond_dict.get('condition_hash'),  # 保留哈希用于结果展开
                'A_values': A_values,
                'log10A_values': log10A_values,
                'reaction_indices': reaction_indices,
                'condition': cond_prepared,
                'mech_path': mech_file,
            }
            
            # 根据任务类型添加对应配置
            if task_type == 'IDT':
                task['idt_config'] = compute_config
            else:
                task['lfs_config'] = compute_config
            
            tasks.append(task)
        
        logger.info(f"  唯一工况模式：创建 {len(tasks)} 个任务（使用默认变体）")
    
    # === 原始模式：为每个变体创建任务 ===
    else:
        logger.info(f"  原始模式（有 variant_id 列），为每个变体创建任务")
        
        # 预转换所有变体参数为 numpy 数组
        variant_params_store = {}
        for vp in variant_params:
            vid = vp['variant_id']
            variant_params_store[vid] = {
                'A_values': np.array(vp['A_values'], dtype=np.float64),
                'log10A_values': np.array(vp['log10A_values'], dtype=np.float64),
                'reaction_indices': vp['reaction_indices']
            }
        
        # 按 variant_id 分组遍历
        grouped_conditions = conditions.groupby('variant_id')
        
        for vid, variant_cond in grouped_conditions:
            if vid not in variant_params_store:
                continue
            
            params = variant_params_store[vid]
            A_values = params['A_values']
            log10A_values = params['log10A_values']
            reaction_indices = params['reaction_indices']
            
            for _, cond in variant_cond.iterrows():
                cond_dict = cond.to_dict()
                cond_prepared = prepare_condition_for_calc(cond_dict)
                
                task = {
                    'task_type': task_type,
                    'variant_id': vid,
                    'condition_hash': cond_dict.get('condition_hash'),
                    'A_values': A_values,
                    'log10A_values': log10A_values,
                    'reaction_indices': reaction_indices,
                    'condition': cond_prepared,
                    'mech_path': mech_file,
                }
                
                # 根据任务类型添加对应配置
                if task_type == 'IDT':
                    task['idt_config'] = compute_config
                else:
                    task['lfs_config'] = compute_config
                
                tasks.append(task)
        
        logger.info(f"  原始模式：创建 {len(tasks)} 个任务（跨所有变体）")
    
    # 测试模式下限制总任务数
    if test_mode and max_total_tasks > 0 and len(tasks) > max_total_tasks:
        tasks = tasks[:max_total_tasks]
        logger.info(f"  测试模式：限制为 {len(tasks)} 个任务")
    
    return tasks


# =============================================================================
# 通用并行计算函数
# =============================================================================

def run_parallel(
    tasks: List[Dict],
    n_workers: int,
    output_path: str,
    compute_func: Callable,
    result_creator: Callable,
    batch_size: int = 50,
    checkpoint_interval: int = 10,
    start_offset: int = 0,
    update_checkpoint_fn: Callable = None,
    is_tuple_result: bool = False,
    task_name: str = "Task"
) -> Dict[str, int]:
    """
    通用并行计算函数
    
    参数:
        tasks: 任务列表
        n_workers: 进程数
        output_path: 输出文件路径
        compute_func: 计算函数
        result_creator: 结果创建函数
        batch_size: 每批任务数
        checkpoint_interval: 每N批保存检查点
        start_offset: 起始偏移量
        update_checkpoint_fn: 更新checkpoint的回调
        is_tuple_result: 计算函数是否返回元组
        task_name: 任务名称 (用于日志)
    
    返回: 统计信息
    """
    n_tasks = len(tasks)
    n_batches = (n_tasks + batch_size - 1) // batch_size
    
    stats = {'success': 0, 'failed': 0, 'total': n_tasks}
    
    logger.info(f"启动{task_name}并行计算: {n_tasks}任务, {n_workers}进程, {n_batches}批")
    
    file_exists = os.path.exists(output_path)
    
    if file_exists and start_offset > 0:
        try:
            with open(output_path, 'r', encoding='utf-8') as f:
                existing_lines = sum(1 for _ in f) - 1
            if existing_lines > start_offset:
                logger.warning(f"文件已包含{existing_lines}条记录 > checkpoint({start_offset})，调整起始位置避免重复")
                skip_count = existing_lines - start_offset
                start_offset = existing_lines
                tasks = tasks[skip_count:]
                n_tasks = len(tasks)
                n_batches = (n_tasks + batch_size - 1) // batch_size
                logger.info(f"跳过{skip_count}个已完成任务，剩余{n_tasks}个任务")
        except Exception as e:
            logger.warning(f"读取已有文件行数失败: {e}")
    
    with ProcessPoolExecutor(max_workers=n_workers) as executor:
        for batch_idx in tqdm(range(n_batches), desc=f"{task_name}批次"):
            start_idx = batch_idx * batch_size
            end_idx = min(start_idx + batch_size, n_tasks)
            batch_tasks = tasks[start_idx:end_idx]
            
            # 并行计算
            futures = {executor.submit(compute_func, task): i 
                      for i, task in enumerate(batch_tasks)}
            
            batch_results = [None] * len(batch_tasks)
            
            for future in as_completed(futures):
                task_idx = futures[future]
                try:
                    result = future.result()
                    batch_results[task_idx] = result
                    
                    # 处理结果值
                    if is_tuple_result:
                        value = result[0] if isinstance(result, tuple) else result
                    else:
                        value = result
                    
                    if value is not None and not np.isnan(value):
                        stats['success'] += 1
                    else:
                        stats['failed'] += 1
                        
                except CancelledError:
                    logger.warning(f"{task_name}任务{start_idx + task_idx}被取消")
                    batch_results[task_idx] = (np.nan, 0) if is_tuple_result else np.nan
                    stats['failed'] += 1
                        
                except TimeoutError:
                    logger.warning(f"{task_name}任务{start_idx + task_idx}超时")
                    batch_results[task_idx] = (np.nan, 0) if is_tuple_result else np.nan
                    stats['failed'] += 1
                        
                except Exception as e:
                    logger.error(f"{task_name}任务{start_idx + task_idx}计算异常: {e}")
                    batch_results[task_idx] = (np.nan, 0) if is_tuple_result else np.nan
                    stats['failed'] += 1
            
            # 保存结果
            if is_tuple_result:
                batch_results_list = []
                for task, result in zip(batch_tasks, batch_results):
                    # 安全处理None值
                    if result is None:
                        value = np.nan
                        grid_points = 0
                    elif isinstance(result, tuple):
                        value = result[0] if result[0] is not None else np.nan
                        grid_points = result[1] if len(result) > 1 else 0
                    else:
                        value = result
                        grid_points = 0
                    
                    # 详细状态判断
                    if value is not None and not np.isnan(value):
                        status = 'success'
                    else:
                        status = 'fail'
                    
                    batch_results_list.append(result_creator(task, value, status=status, grid_points=grid_points))
                batch_df = pd.DataFrame(batch_results_list)
            else:
                batch_results_list = []
                for task, result in zip(batch_tasks, batch_results):
                    # 安全处理None值
                    value = result if result is not None else np.nan
                    
                    # 详细状态判断
                    if value is not None and not np.isnan(value):
                        status = 'success'
                    else:
                        status = 'fail'
                    
                    batch_results_list.append(result_creator(task, value, status=status))
                batch_df = pd.DataFrame(batch_results_list)
            
            if file_exists:
                batch_df.to_csv(output_path, mode='a', header=False, index=False)
            else:
                batch_df.to_csv(output_path, index=False)
                file_exists = True
            
            # 更新checkpoint
            completed = end_idx + start_offset
            if update_checkpoint_fn and (batch_idx + 1) % checkpoint_interval == 0:
                update_checkpoint_fn(completed, stats['success'], stats['failed'])
            
            # 进度日志
            logger.info(f"{task_name}进度: {end_idx}/{n_tasks} ({end_idx/n_tasks*100:.1f}%) 成功:{stats['success']} 失败:{stats['failed']}")
    
    return stats


# =============================================================================
# 主函数
# =============================================================================
# -*- coding: utf-8 -*-


def run_compute(
    config_path: str = 'config/config.yaml', 
    use_timestamp: bool = False, 
    test_samples: int = 0,
    incremental: bool = False,
    force: bool = False
):
    """阶段2: 并行计算"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S") if use_timestamp else ""
    
    logger.info("=" * 70)
    logger.info("阶段2: 并行计算 (优化版)")
    logger.info("=" * 70)
    
    # 加载配置
    config = load_config_with_override(config_path)
    
    # 配置验证
    try:
        ConfigValidator.validate(config)
    except ConfigValidationError as e:
        logger.error(str(e))
        raise
    
    comp_config = config['computation']
    n_workers = comp_config['n_workers']
    batch_size = comp_config.get('batch_size', 50)
    
    test_samples = test_samples if test_samples > 0 else comp_config.get('test_samples', 0)
    test_mode_enabled = test_samples > 0
    
    periodic_save = comp_config.get('batch_export', {}).get('periodic_save', 10)
    
    var_config = config['variant_generation']
    mech_file = var_config['mechanism_file']
    
    # 获取计算配置
    conditions_config = config['conditions']
    idt_cfg = conditions_config.get('idt', {})
    lfs_cfg = conditions_config.get('lfs', {})
    idt_compute = idt_cfg.get('compute', {})
    lfs_compute = lfs_cfg.get('compute', {})
    
    # 加载数据
    variant_params, idt_conditions, lfs_conditions = load_conditions_and_params()
    
    # === 优化工况统计 ===
    logger.info("=" * 70)
    logger.info("工况去重分析")
    logger.info("=" * 70)
    print_condition_stats(idt_conditions, "IDT 工况")
    print_condition_stats(lfs_conditions, "LFS 工况")
    
    # 计算唯一工况数（用于 checkpoint 进度跟踪）
    idt_stats = get_condition_stats(idt_conditions)
    lfs_stats = get_condition_stats(lfs_conditions)
    n_unique_idt = idt_stats['unique_conditions']
    n_unique_lfs = lfs_stats['unique_conditions']
    logger.info(f"唯一工况数：IDT={n_unique_idt}, LFS={n_unique_lfs}")
    
    # 从配置读取总任务数限制
    if test_mode_enabled:
        idt_max_tasks = test_samples // 2
        lfs_max_tasks = test_samples - idt_max_tasks
    else:
        idt_max_tasks = 0
        lfs_max_tasks = 0
    
    # 创建任务
    logger.info("创建计算任务...")
    idt_tasks = create_tasks(
        variant_params, idt_conditions, mech_file, 
        idt_compute, 'IDT', test_mode_enabled, idt_max_tasks
    )
    lfs_tasks = create_tasks(
        variant_params, lfs_conditions, mech_file, 
        lfs_compute, 'LFS', test_mode_enabled, lfs_max_tasks
    )
    
    if test_mode_enabled:
        logger.info(f"测试模式: IDT限制{idt_max_tasks}个, LFS限制{lfs_max_tasks}个")
    
    logger.info(f"  IDT任务: {len(idt_tasks)}")
    logger.info(f"  LFS任务: {len(lfs_tasks)}")
    
    current_totals = {'idt': len(idt_tasks), 'lfs': len(lfs_tasks)}
    logger.info(f"总任务数: IDT={len(idt_tasks)}, LFS={len(lfs_tasks)}")
    
    # 输出目录和文件名
    os.makedirs(RESULTS_DIR, exist_ok=True)
    
    if timestamp:
        idt_output = f"{RESULTS_DIR}/idt_results_{timestamp}.csv"
        lfs_output = f"{RESULTS_DIR}/lfs_results_{timestamp}.csv"
    else:
        idt_output = f"{RESULTS_DIR}/idt_results.csv"
        lfs_output = f"{RESULTS_DIR}/lfs_results.csv"
    
    workers = min(n_workers, os.cpu_count() or 8)
    logger.info(f"使用{workers}个进程")
    
    # Checkpoint校验
    checkpoint = load_checkpoint()
    is_valid, message, resume_idt, resume_lfs = validate_checkpoint(checkpoint, current_totals, variant_params)
    
    if not is_valid:
        logger.warning(f"Checkpoint校验失败: {message}")
        logger.warning("将重新计算所有任务")
        if checkpoint:
            clear_checkpoint()
        resume_idt, resume_lfs = 0, 0
    else:
        logger.info(f"Checkpoint: {message}, 继续从 IDT:{resume_idt}, LFS:{resume_lfs}")
    
    # 初始化checkpoint
    if checkpoint is None or not is_valid:
        reaction_indices = variant_params[0].get('reaction_indices', []) if variant_params else []
        checkpoint = {
            "version": CHECKPOINT_VERSION,
            "idt": {"total": len(idt_tasks), "completed": 0, "success": 0, "failed": 0, "progress_pct": 0.0},
            "lfs": {"total": len(lfs_tasks), "completed": 0, "success": 0, "failed": 0, "progress_pct": 0.0},
            "meta": {
                "timestamp": timestamp,
                "conditions_timestamp": get_conditions_timestamp(),
                "variant_timestamp": get_variant_timestamp(),
                "reaction_indices": reaction_indices,
                "n_variants": len(variant_params)
            }
        }
    
    # Checkpoint回调 - 包含进度百分比
    def update_idt_checkpoint(completed, success, failed):
        checkpoint['idt']['completed'] = completed
        checkpoint['idt']['success'] = success
        checkpoint['idt']['failed'] = failed
        total = checkpoint['idt']['total']
        checkpoint['idt']['progress_pct'] = round(completed / total * 100, 2) if total > 0 else 0.0
        save_checkpoint(checkpoint)
    
    def update_lfs_checkpoint(completed, success, failed):
        checkpoint['lfs']['completed'] = completed
        checkpoint['lfs']['success'] = success
        checkpoint['lfs']['failed'] = failed
        total = checkpoint['lfs']['total']
        checkpoint['lfs']['progress_pct'] = round(completed / total * 100, 2) if total > 0 else 0.0
        save_checkpoint(checkpoint)
    
    # ==================== IDT计算 ====================
    stats_idt = {'success': 0, 'failed': 0, 'total': 0}
    
    if len(idt_tasks) > 0:
        logger.info("=" * 70)
        logger.info(f"开始IDT计算 (从第{resume_idt}个继续)")
        logger.info("=" * 70)
        
        idt_tasks_to_run = idt_tasks[resume_idt:]
        
        stats_idt = run_parallel(
            idt_tasks_to_run, workers, idt_output,
            compute_func=compute_idt_task,
            result_creator=create_idt_result_dict,
            is_tuple_result=False,
            batch_size=batch_size,
            checkpoint_interval=periodic_save,
            start_offset=resume_idt,
            update_checkpoint_fn=update_idt_checkpoint,
            task_name="IDT"
        )
        
        logger.info(f"IDT计算完成: 成功{stats_idt['success']}, 失败{stats_idt['failed']}, 总计{stats_idt['total']}")
    
    # ==================== LFS计算 ====================
    stats_lfs = {'success': 0, 'failed': 0, 'total': 0}
    
    if len(lfs_tasks) > 0:
        logger.info("=" * 70)
        logger.info(f"开始LFS计算 (从第{resume_lfs}个继续)")
        logger.info("=" * 70)
        
        lfs_tasks_to_run = lfs_tasks[resume_lfs:]
        
        stats_lfs = run_parallel(
            lfs_tasks_to_run, workers, lfs_output,
            compute_func=compute_lfs_subprocess,
            result_creator=create_lfs_result_dict,
            is_tuple_result=True,
            batch_size=batch_size,
            checkpoint_interval=periodic_save,
            start_offset=resume_lfs,
            update_checkpoint_fn=update_lfs_checkpoint,
            task_name="LFS"
        )
        
        logger.info(f"LFS计算完成: 成功{stats_lfs['success']}, 失败{stats_lfs['failed']}, 总计{stats_lfs['total']}")
    
    # 清除checkpoint
    clear_checkpoint()
    
    # 输出摘要
    logger.info("=" * 70)
    logger.info("阶段2完成! 计算结果已保存。")
    logger.info("=" * 70)
    logger.info(f"IDT结果: {idt_output}")
    logger.info(f"  - 成功: {stats_idt['success']}")
    logger.info(f"  - 失败: {stats_idt['failed']}")
    logger.info(f"  - 总计: {stats_idt['total']}")
    logger.info(f"LFS结果: {lfs_output}")
    logger.info(f"  - 成功: {stats_lfs['success']}")
    logger.info(f"  - 失败: {stats_lfs['failed']}")
    logger.info(f"  - 总计: {stats_lfs['total']}")
    logger.info("=" * 70)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Phase 2: Compute IDT and LFS (优化版)')
    parser.add_argument('-c', '--config', default='config/config.yaml', help='Config file path')
    parser.add_argument('--timestamp', action='store_true', help='Add timestamp to output filenames')
    parser.add_argument('--test-samples', type=int, default=0, help='Enable test mode with N samples')
    parser.add_argument('--incremental', action='store_true', help='Enable incremental computation (reuse cached results)')
    parser.add_argument('--force', action='store_true', help='Force recompute all conditions (ignore cache)')
    parser.add_argument('--cache-stats', action='store_true', help='Show cache statistics and exit')
    args = parser.parse_args()
    
    # 特殊处理：只显示缓存统计
    if args.cache_stats:
        from src.utils.result_cache import ResultCache
        cache = ResultCache()
        cache.print_cache_stats()
        exit(0)
    
    run_compute(
        args.config, 
        use_timestamp=args.timestamp, 
        test_samples=args.test_samples,
        incremental=args.incremental,
        force=args.force
    )
