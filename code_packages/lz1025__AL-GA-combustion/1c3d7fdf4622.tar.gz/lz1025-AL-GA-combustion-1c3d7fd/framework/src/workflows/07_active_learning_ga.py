# =============================================================================
# src/workflows/07_active_learning_ga.py
# =============================================================================
# 工作流步骤 7/9: 主动学习驱动的遗传算法优化（核心）
# =============================================================================
#
# 功能：
#   - 使用XGBoost代理模型进行快速优化
#   - 主动学习循环：GA优化 → Cantera验证 → 样本回填 → 模型重训练
#   - 支持多目标优化（NSGA-II）和迁移学习
#   - 自动寻找最优A因子组合
#
# 核心函数：
#   - run_active_learning(): 主动学习主循环
#   - cross_validate_lambda(): λ交叉验证
#   - check_and_train_models(): 检查并训练模型
#
# 目标函数（统一对数空间MSE）：
#   - IDT: ε_IDT = (1/N) Σ (log10(τ_sim/μs) - log10(τ_ref/μs))²
#   - LFS: ε_LFS = (1/N) Σ (log10(S_sim/cm/s) - log10(S_ref/cm/s))²
#   - 总目标: J(x) = α·ε_IDT + (1-α)·ε_LFS + λ||x - x_base||²
#
# 高级功能（新增）：
#   - 多目标优化（NSGA-II）: 输出IDT-LFS Pareto前沿
#   - 迁移学习：基于基线模型增量微调
#   - 回退机制：迁移学习失败时自动切换到超参数寻优
#   - 并行GA：多岛模型并行进化（待修复）
#
# 输入文件：
#   - output/models/idt/model.json: IDT代理模型
#   - output/models/lfs/model.json: LFS代理模型
#   - data/ground_truth/idt_det_reference.csv: IDT Ground Truth
#   - data/ground_truth/lfs_exp_reference.csv: LFS Ground Truth
#   - data/logA_base.npy: 基线logA值
#   - 02-Reduced-Wang_fuel_2023.yaml: 机理文件
#   - output/idt_results.csv: IDT训练数据（用于重训练）
#   - output/lfs_results.csv: LFS训练数据（用于重训练）
#
# 输出文件：
#   - output/active_learning/active_learning_results_TIMESTAMP.json:
#     包含：
#     - 每次迭代的logA候选
#     - 代理模型误差
#     - Cantera验证误差
#     - GA优化历史
#     - Pareto前沿（多目标模式）
#     - 最终优化结果
#
# 使用方法：
#   python src/workflows/07_active_learning_ga.py -c config/ga_config.yaml
#   python src/workflows/07_active_learning_ga.py --skip-lfs    # 跳过LFS验证
#   python src/workflows/07_active_learning_ga.py --idt-only    # 仅IDT模式
#   python src/workflows/07_active_learning_ga.py --alpha 0.9   # 调整IDT权重
#
# 配置参数（ga_config.yaml）：
#   active_learning:
#     max_iterations: 20           # 最大迭代次数
#     convergence_threshold: 0.10  # 收敛阈值（10%）
#     use_multi_objective: true    # 启用多目标优化
#     use_transfer_learning: true  # 启用迁移学习
#     early_stopping_patience: 5   # 早停耐心值
#
# 计算时间：
#   - 单次迭代：约8-10分钟（GA优化 + Cantera验证）
#   - 典型收敛：10-15次迭代
#   - 总计：约1.5-2.5小时
#
# 前置步骤：
#   - 01-06: 完整的前置工作流
#
# 后续步骤：
#   - 08_analyze_model_errors.py: 分析模型误差
#   - 09_analyze_optimization_results.py: 分析优化结果
#
# =============================================================================
# -*- coding: utf-8 -*-



import os
import sys
import json
import yaml
import logging
import argparse
import time
from datetime import datetime
from typing import Dict, List, Any, Tuple, Optional

import numpy as np
import pandas as pd
import xgboost as xgb

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.core.objective import (
    load_surrogate_models, load_feature_lists, load_ground_truth,
    build_features_batch, predict_idt, predict_lfs, compute_objective
)
from src.core.ga_optimizer import (
    create_bounds, setup_toolbox, run_ga_with_callback,
    create_evaluation_function
)
from src.core.cantera_validator import (
    validate_candidate, compute_validation_error
)
from src.core.model_retrainer import (
    create_infill_samples,
    prepare_idt_training_data, prepare_lfs_training_data,
    retrain_xgboost, merge_training_data,
    retrain_with_optimization, validate_hyperparams
)


def check_and_train_models(config: Dict[str, Any]) -> Tuple[bool, bool]:
    """
    检查模型是否存在，如不存在则自动训练
    
    返回: (idt_available, lfs_available)
    """
    models_cfg = config['models']
    
    idt_model_path = models_cfg['idt_model']
    lfs_model_path = models_cfg['lfs_model']
    
    idt_exists = os.path.exists(idt_model_path)
    lfs_exists = os.path.exists(lfs_model_path)
    
    idt_available = idt_exists
    lfs_available = lfs_exists
    
    if not idt_exists or not lfs_exists:
        logger.info("=" * 60)
        logger.info("检测到模型缺失，开始自动训练...")
        logger.info("=" * 60)
        
        try:
            import importlib.util
            
            script_dir = os.path.dirname(os.path.abspath(__file__))
            train_xgboost_path = os.path.join(script_dir, '04_train_xgboost.py')
            
            spec = importlib.util.spec_from_file_location("train_xgboost_module", train_xgboost_path)
            if spec is None or spec.loader is None:
                raise ImportError(f"无法加载模块: {train_xgboost_path}")
            train_xgboost_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(train_xgboost_module)
            train_target_model = train_xgboost_module.train_target_model
            
            from src.core.config_loader import load_config_with_override
            
            main_config = load_config_with_override(config.get('main_config_path', 'config/config.yaml'))
            
            if not idt_exists:
                logger.info("训练IDT模型...")
                idt_output_dir = os.path.join(os.path.dirname(idt_model_path), '..')
                train_target_model('idt', main_config, 
                                   use_optuna=config.get('use_optuna', True),
                                   n_trials=config.get('n_trials', 50),
                                   output_dir=idt_output_dir)
                idt_available = True
                logger.info("IDT模型训练完成")
            
            if not lfs_exists:
                lfs_results_path = config.get('training_data', {}).get('lfs_results', 'output/lfs_results.csv')
                if os.path.exists(lfs_results_path):
                    logger.info("训练LFS模型...")
                    lfs_output_dir = os.path.join(os.path.dirname(lfs_model_path), '..')
                    train_target_model('lfs', main_config,
                                      use_optuna=config.get('use_optuna', True),
                                      n_trials=config.get('n_trials', 50),
                                      output_dir=lfs_output_dir)
                    lfs_available = True
                    logger.info("LFS模型训练完成")
                else:
                    logger.warning(f"LFS训练数据不存在: {lfs_results_path}")
                    logger.warning("跳过LFS模型训练")
        except Exception as e:
            logger.error(f"自动训练模型失败: {e}")
            logger.warning("将继续尝试使用现有模型（如存在）")
    
    return idt_available, lfs_available

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    encoding='utf-8'
)
logger = logging.getLogger(__name__)


def load_config(config_path: str) -> Dict[str, Any]:
    """加载配置文件"""
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def save_results(results: Dict, output_dir: str, filename: str):
    """保存结果到JSON文件"""
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False, default=str)
    logger.info(f"结果已保存: {filepath}")


def cross_validate_lambda(idt_model: xgb.Booster, lfs_model: xgb.Booster,
                          idt_features: List[str], lfs_features: List[str],
                          idt_conditions: pd.DataFrame, lfs_conditions: pd.DataFrame,
                          idt_reference: np.ndarray, lfs_reference: np.ndarray,
                          logA_base: np.ndarray,
                          lambda_candidates: List[float],
                          alpha: float = 0.5,
                          n_folds: int = 5,
                          n_samples_per_fold: int = 20,
                          sampling_range: float = 1.0,
                          idt_only: bool = False) -> float:
    """
    K折交叉验证确定最优正则化系数λ
    
    参数:
        lambda_candidates: λ候选值列表
        n_folds: K折数
        n_samples_per_fold: 每折采样数
        sampling_range: 采样范围（相对于基线的偏移）
    
    方法:
        对每个λ候选值，使用K折交叉验证：
        - 将n_folds×n_samples_per_fold个采样点分为K折
        - 每折用K-1折训练，计算第折的误差
        - 选择平均误差最小的λ
    """
    logger.info("开始K折交叉验证确定λ...")
    logger.info(f"  K={n_folds}, 每折{n_samples_per_fold}样本, 采样范围±{sampling_range}")
    
    n_dim = len(logA_base)
    n_total = n_folds * n_samples_per_fold
    
    # 生成所有采样点
    np.random.seed(42)
    all_samples = []
    for _ in range(n_total):
        noise = np.random.uniform(-1, 1, n_dim)
        logA_test = logA_base + noise * sampling_range
        all_samples.append(logA_test)
    all_samples = np.array(all_samples)
    
    best_lambda = 0.0
    best_score = float('inf')
    lambda_results = {}
    
    for lam in lambda_candidates:
        fold_scores = []
        
        # K折交叉验证
        for fold in range(n_folds):
            # 划分训练集和验证集
            val_start = fold * n_samples_per_fold
            val_end = val_start + n_samples_per_fold
            
            val_indices = list(range(val_start, val_end))
            
            # 计算验证集误差（不含正则化项）
            fold_errors = []
            for idx in val_indices:
                logA_test = all_samples[idx]
                
                result = compute_objective(
                    logA_test, idt_model, lfs_model,
                    idt_features, lfs_features,
                    idt_conditions, lfs_conditions,
                    idt_reference, lfs_reference,
                    lam, logA_base, alpha, idt_only
                )
                
                if idt_only:
                    fold_errors.append(result['idt_error'])
                else:
                    fold_errors.append(result['total'] - result['reg_term'])
            
            fold_scores.append(np.mean(fold_errors))
        
        avg_score = np.mean(fold_scores)
        std_score = np.std(fold_scores)
        lambda_results[lam] = avg_score
        
        logger.info(f"  λ={lam}: 平均误差={avg_score:.6f} ± {std_score:.6f}")
        
        if avg_score < best_score:
            best_score = avg_score
            best_lambda = lam
    
    logger.info(f"交叉验证选择: λ={best_lambda}")
    
    # 打印所有结果
    logger.info("λ候选值结果:")
    for lam, score in sorted(lambda_results.items(), key=lambda x: x[1]):
        marker = " ← 选择" if lam == best_lambda else ""
        logger.info(f"  λ={lam}: {score:.6f}{marker}")
    
    return best_lambda


def run_active_learning(config: Dict[str, Any], 
                        skip_lfs: bool = False,
                        idt_only: bool = False,
                        alpha: float = None) -> Dict[str, Any]:
    """
    运行主动学习优化循环
    
    skip_lfs: 跳过Cantera LFS验证
    idt_only: 仅使用IDT模型（LFS模型不存在时）
    alpha: IDT/LFS权重平衡系数 (覆盖配置文件)
    """
    start_time = time.time()
    
    models_cfg = config['models']
    gt_cfg = config['ground_truth']
    mech_cfg = config['mechanism']
    al_cfg = config['active_learning']
    ga_cfg = config['genetic_algorithm']
    lambda_cfg = config['lambda_cv']
    output_cfg = config['output']
    retrain_cfg = config.get('model_retraining', {})  # 新增：超参数重训练配置
    
    # 将 retrain_cfg 合并到 al_cfg 以便后续代码访问
    if retrain_cfg:
        al_cfg['model_retraining'] = retrain_cfg
    
    # 获取 Cantera 并行进程数
    cantera_workers = config.get('cantera', {}).get('n_workers', 12)
    logger.info(f"Cantera并行进程数: {cantera_workers}")
    
    # 获取alpha参数 (命令行 > 配置文件 > 默认值0.5)
    if alpha is not None:
        final_alpha = alpha
    else:
        final_alpha = config.get('objective', {}).get('alpha', 0.5)
    logger.info(f"IDT/LFS权重平衡系数 α = {final_alpha}")
    
    output_dir = output_cfg['results_dir']
    os.makedirs(output_dir, exist_ok=True)
    
    logger.info("=" * 60)
    logger.info("检查并训练模型（如需要）...")
    logger.info("=" * 60)
    
    idt_available, lfs_available = check_and_train_models(config)
    
    logger.info("=" * 60)
    logger.info("加载模型和数据...")
    logger.info("=" * 60)
    
    if not idt_available:
        raise FileNotFoundError(f"IDT模型不可用: {models_cfg['idt_model']}")
    
    idt_model, _ = load_surrogate_models(
        models_cfg['idt_model'], models_cfg['idt_model']
    )
    idt_features, _ = load_feature_lists(
        models_cfg['idt_feature_list'], models_cfg['idt_feature_list']
    )
    idt_conditions, lfs_conditions = load_ground_truth(
        gt_cfg['idt_reference'], gt_cfg['lfs_reference']
    )
    
    if idt_only or (skip_lfs and not lfs_available):
        logger.info("仅IDT模式：LFS模型未加载")
        lfs_model = None
        lfs_features = idt_features
        lfs_reference = np.ones(len(lfs_conditions))
        use_lfs = False
    elif not lfs_available:
        logger.info("LFS模型不可用，仅使用IDT")
        lfs_model = None
        lfs_features = idt_features
        lfs_reference = np.ones(len(lfs_conditions))
        use_lfs = False
    else:
        _, lfs_model = load_surrogate_models(
            models_cfg['idt_model'], models_cfg['lfs_model']
        )
        _, lfs_features = load_feature_lists(
            models_cfg['idt_feature_list'], models_cfg['lfs_feature_list']
        )
        lfs_reference = lfs_conditions['reference_lfs_ms'].values
        use_lfs = True
    
    idt_reference = idt_conditions['reference_idt'].values
    
    logA_base = np.load(mech_cfg['logA_base_file'])
    reaction_indices = mech_cfg['reaction_indices']
    mech_path = mech_cfg['path']
    
    logger.info(f"IDT工况: {len(idt_conditions)} 条")
    logger.info(f"LFS工况: {len(lfs_conditions)} 条")
    logger.info(f"反应数: {len(reaction_indices)}")
    
    logger.info("=" * 60)
    logger.info("加载原始训练数据...")
    logger.info("=" * 60)
    
    idt_train_df = None
    lfs_train_df = None
    
    if use_lfs:
        from src.core.objective import load_training_data
        idt_train_path = config.get('training_data', {}).get('idt_results', 'output/idt_results.csv')
        lfs_train_path = config.get('training_data', {}).get('lfs_results', 'output/lfs_results.csv')
        
        if os.path.exists(idt_train_path):
            idt_train_df, lfs_train_df = load_training_data(idt_train_path, lfs_train_path)
            logger.info(f"训练数据: IDT={len(idt_train_df)}, LFS={len(lfs_train_df)}")
        else:
            logger.warning(f"训练数据文件不存在: {idt_train_path}")
    
    logger.info("=" * 60)
    logger.info("设置正则化系数λ...")
    logger.info("=" * 60)
    
    # 优先使用配置文件中选定的λ值
    if 'selected_lambda' in lambda_cfg:
        lambda_reg = lambda_cfg['selected_lambda']
        logger.info(f"使用配置文件选定的λ: {lambda_reg}")
        logger.info("（如需重新选择λ，请运行 scripts/06_lambda_selection.py）")
    else:
        logger.info("配置文件中未指定selected_lambda，使用交叉验证...")
        lambda_reg = cross_validate_lambda(
            idt_model, lfs_model,
            idt_features, lfs_features,
            idt_conditions, lfs_conditions,
            idt_reference, lfs_reference,
            logA_base,
            lambda_cfg.get('candidates', [0, 0.001, 0.01, 0.1, 1.0]),
            alpha=final_alpha,
            idt_only=(not use_lfs)
        )
    
    logger.info(f"最终λ值: {lambda_reg}")
    
    bounds = create_bounds(logA_base, config['search_space']['offset_range'])
    
    al_results = {
        'config': config,
'lambda_reg': lambda_reg,
        'iterations': [],
        'converged': False,
        'final_solution': None,
        'early_stopped': False
    }
    
    # 早停机制参数
    best_error = float('inf')
    no_improve_count = 0
    patience = 3  # 连续3次无改善则停止
    
    logger.info("=" * 60)
    logger.info("开始主动学习循环...")
    logger.info("=" * 60)
    
    for iteration in range(1, al_cfg['max_iterations'] + 1):
        iter_start = time.time()
        logger.info(f"\n{'='*60}")
        logger.info(f"Active Learning 迭代 {iteration}/{al_cfg['max_iterations']}")
        logger.info(f"{'='*60}")
        
        eval_fn = create_evaluation_function(
            idt_model, lfs_model,
            idt_features, lfs_features,
            idt_conditions, lfs_conditions,
            idt_reference, lfs_reference,
            lambda_reg, logA_base
        )
        
        toolbox = setup_toolbox(bounds, eval_fn, ga_cfg)
        
        logger.info("运行GA优化...")
        
        # 详细GA历史记录（用于论文作图）
        ga_detailed_history = {
            'generation': [],
            'best_fitness': [],
            'avg_fitness': [],
            'worst_fitness': [],
            'best_idt_error': [],
            'best_lfs_error': [],
            'best_params': []
        }
        
        def ga_callback(gen, best_ind, best_fitness):
            # 记录每一代详细信息
            ga_detailed_history['generation'].append(gen)
            ga_detailed_history['best_fitness'].append(float(best_fitness))
            
            # 计算该代的其他统计信息
            best_logA = np.array(best_ind)
            obj = compute_objective(
                best_logA, idt_model, lfs_model,
                idt_features, lfs_features,
                idt_conditions, lfs_conditions,
                idt_reference, lfs_reference,
                lambda_reg, logA_base, final_alpha, idt_only
            )
            ga_detailed_history['best_idt_error'].append(float(obj['idt_error']))
            ga_detailed_history['best_lfs_error'].append(float(obj['lfs_error']))
            ga_detailed_history['best_params'].append(best_logA.tolist())
            
            # 每10代输出一次日志（显示目标函数值）
            if gen % 10 == 0:
                logger.info(f"  GA Gen {gen}: fitness={best_fitness:.6f}, IDT_LogMSE={obj['idt_error']:.6f}, LFS_LogMSE={obj['lfs_error']:.6f}")
        
        best_ind, best_fitness, ga_history = run_ga_with_callback(
            toolbox, ga_cfg, callback=ga_callback, verbose=False
        )
        
        logA_candidate = np.array(best_ind)
        
        logger.info(f"GA最优适应度: {best_fitness:.6f}")
        
        obj_result = compute_objective(
            logA_candidate, idt_model, lfs_model,
            idt_features, lfs_features,
            idt_conditions, lfs_conditions,
            idt_reference, lfs_reference,
            lambda_reg, logA_base, final_alpha, idt_only
        )
        
        # 代理模型预测误差（对数空间）
        logger.info(f"代理模型预测误差 (对数空间):")
        logger.info(f"  IDT Log-MSE: {obj_result['idt_error']:.6f}")
        if use_lfs:
            logger.info(f"  LFS Log-MSE: {obj_result['lfs_error']:.6f}")
            logger.info(f"  加权总误差: {obj_result['total'] - obj_result['reg_term']:.6f} (α={final_alpha})")
        
            if skip_lfs:
                logger.info("跳过 Cantera 验证（LFS 模型未就绪）")
                idt_pred_feat = build_features_batch(logA_candidate, idt_conditions, idt_features)
                idt_pred_log = predict_idt(idt_model, idt_pred_feat, idt_features)
                idt_pred = 10 ** idt_pred_log
                
                idt_error_result = compute_validation_error(idt_pred, idt_reference, error_type='idt')
                
                idt_max_rel = idt_error_result['max_relative_error']
                lfs_max_rel = 0.0
                max_error = idt_max_rel
                
                idt_true = None
                lfs_true = None
                lfs_error_result = {'mse': 0, 'rmse': 0, 'max_relative_error': 0, 'valid_count': 0}
                
                # log 空间误差（用于收敛判断，与 GA 优化目标一致）
                idt_log_error = np.abs(idt_pred_log - np.log10(idt_reference))
                idt_max_log_error = float(np.max(idt_log_error))
                lfs_max_log_error = 0.0
            else:
                logger.info(f"Cantera 验证 ({cantera_workers}进程)...")
                
                try:
                    idt_true, lfs_true = validate_candidate(
                        logA_candidate, mech_path, reaction_indices,
                        idt_conditions, lfs_conditions,
                        n_workers=cantera_workers
                    )
                except Exception as e:
                    logger.error(f"Cantera 验证失败 (迭代{iteration}): {e}")
                    logger.warning("跳过本次迭代的验证，继续下一次迭代")
                    continue
                
                idt_pred_feat = build_features_batch(logA_candidate, idt_conditions, idt_features)
                idt_pred_log = predict_idt(idt_model, idt_pred_feat, idt_features)
                idt_pred = 10 ** idt_pred_log
                
                lfs_pred_feat = build_features_batch(logA_candidate, lfs_conditions, lfs_features)
                lfs_pred_log = predict_lfs(lfs_model, lfs_pred_feat, lfs_features)
                lfs_pred = 10 ** lfs_pred_log
                
                idt_error_result = compute_validation_error(idt_pred, idt_true, error_type='idt')
                lfs_error_result = compute_validation_error(lfs_pred, lfs_true, error_type='lfs')
                
                idt_max_rel = idt_error_result['max_relative_error']
                lfs_max_rel = lfs_error_result['max_relative_error'] if use_lfs else 0.0
                max_error = max(idt_max_rel, lfs_max_rel)
                
                # log 空间误差（用于收敛判断，与 GA 优化目标一致）
                # log10(pred/true) = log10(pred) - log10(true)
                # 10% 相对误差对应 log10(1.1) ≈ 0.0414
                idt_log_error = np.abs(idt_pred_log - np.log10(idt_true))
                lfs_log_error = np.abs(lfs_pred_log - np.log10(lfs_true))
                idt_max_log_error = float(np.nanmax(idt_log_error))
                lfs_max_log_error = float(np.nanmax(lfs_log_error)) if use_lfs else 0.0
        
        iter_time = time.time() - iter_start
        
        iter_result = {
            'iteration': iteration,
            'ga_best_fitness': float(best_fitness),
            'logA_candidate': logA_candidate.tolist(),
            'surrogate_errors': {
                'idt': obj_result['idt_error'],
                'lfs': obj_result['lfs_error']
            },
            'validation_errors': {
                'idt': idt_error_result,
                'lfs': lfs_error_result
            },
            'max_validation_error': max_error,
            'iteration_time': iter_time
        }
        al_results['iterations'].append(iter_result)
        
        logger.info(f"Cantera 验证误差 (线性空间):")
        logger.info(f"  IDT: MSRE={idt_error_result['msre']:.6f}, RMSRE={idt_error_result['rmsre']:.4f} ({idt_error_result['rmsre']*100:.1f}%), 最大相对误差={idt_error_result['max_relative_error']:.6f} ({idt_error_result['max_relative_error']*100:.1f}%)")
        if use_lfs:
            logger.info(f"  LFS: MSRE={lfs_error_result['msre']:.6f}, RMSRE={lfs_error_result['rmsre']:.4f} ({lfs_error_result['rmsre']*100:.1f}%), 最大相对误差={lfs_error_result['max_relative_error']:.6f} ({lfs_error_result['max_relative_error']*100:.1f}%)")
        logger.info(f"收敛判断 (线性空间): IDT={idt_max_rel*100:.1f}%, LFS={lfs_max_rel*100:.1f}% (阈值={al_cfg['convergence_threshold']*100:.0f}%)")
        logger.info(f"迭代耗时: {iter_time:.1f}s")
        
        # 使用 log 空间误差进行收敛判断（与 GA 优化目标一致）
        # log10(1.1) ≈ 0.0414 对应 10% 相对误差
        log_convergence_threshold = np.log10(1 + al_cfg['convergence_threshold'])
        
        if idt_max_log_error < log_convergence_threshold and (not use_lfs or lfs_max_log_error < log_convergence_threshold):
            logger.info(f"\n收敛 (log 空间)! IDT_max_log_err={idt_max_log_error:.6f}, LFS_max_log_err={lfs_max_log_error:.6f} < 阈值={log_convergence_threshold:.6f}")
            al_results['converged'] = True
            al_results['final_solution'] = {
                'logA': logA_candidate.tolist(),
                'A': np.power(10, logA_candidate).tolist(),
                'validation_error': max_error,
                'idt_max_relative_error': idt_max_rel,
                'lfs_max_relative_error': lfs_max_rel,
                'idt_max_log_error': idt_max_log_error,
'lfs_max_log_error': lfs_max_log_error
            }
            break
        
        # 如果线性空间收敛也认为收敛（双重判断）
        if idt_max_rel < al_cfg['convergence_threshold'] and (not use_lfs or lfs_max_rel < al_cfg['convergence_threshold']):
            logger.info(f"收敛！(线性空间：IDT={idt_max_rel*100:.1f}%, LFS={lfs_max_rel*100:.1f}%)")
            al_results['converged'] = True
            al_results['final_solution'] = {
                'logA': logA_candidate.tolist(),
                'A': np.power(10, logA_candidate).tolist(),
                'validation_error': max_error,
                'idt_max_relative_error': idt_max_rel,
                'lfs_max_relative_error': lfs_max_rel,
                'idt_max_log_error': idt_max_log_error,
                'lfs_max_log_error': lfs_max_log_error
            }
            break

        logger.info("误差未达到阈值，继续迭代...")
        
        # 早停检查
        if max_error < best_error:
            best_error = max_error
            no_improve_count = 0
            logger.info(f"早停检测: 新最优误差={best_error:.6f}, 重置计数器")
        else:
            no_improve_count += 1
            logger.info(f"早停检测: 无改善次数={no_improve_count}/{patience}")
            
        if no_improve_count >= patience:
            logger.info(f"\n早停触发: 连续{patience}次迭代无改善")
            al_results['early_stopped'] = True
            al_results['final_solution'] = {
                'logA': logA_candidate.tolist(),
                'A': np.power(10, logA_candidate).tolist(),
                'validation_error': max_error,
                'idt_max_relative_error': idt_max_rel,
                'lfs_max_relative_error': lfs_max_rel,
                'idt_max_log_error': idt_max_log_error,
                'lfs_max_log_error': lfs_max_log_error
            }
            break

        if use_lfs and idt_train_df is not None:
            skip_retrain = al_cfg.get('skip_retrain', False)
            
            if skip_retrain:
                logger.info("【调试模式】跳过模型重训练，使用原始模型")
            else:
                logger.info("=" * 60)
                logger.info("执行模型重训练...")
                logger.info("=" * 60)
                
                skip_infill = al_cfg.get('skip_infill', False)
                infill_lfs = None
                
                if skip_infill:
                    logger.info("【调试模式】跳过回填样本，直接使用原始训练数据重训练")
                    merged_idt = idt_train_df
                else:
                    logger.info("创建回填样本...")
                    infill_idt, infill_lfs = create_infill_samples(
                        logA_candidate,
                        idt_conditions, lfs_conditions,
                        idt_true, lfs_true,
                        n_samples=al_cfg.get('n_infill_samples', 5),
                        perturbation=al_cfg.get('infill_perturbation', 0.05)
                    )
                    merged_idt = merge_training_data(idt_train_df, infill_idt, 'IDT')
                
                X_idt, y_idt = prepare_idt_training_data(merged_idt, idt_features)
                
                logger.info(f"【调试】重训练数据统计:")
                logger.info(f"  X_idt shape: {X_idt.shape}")
                logger.info(f"  y_idt range: [{y_idt.min():.4f}, {y_idt.max():.4f}]")
                logger.info(f"  y_idt mean: {y_idt.mean():.4f}")
                logger.info(f"  X_idt contains NaN: {np.isnan(X_idt).any()}")
                logger.info(f"  X_idt contains Inf: {np.isinf(X_idt).any()}")
                
                # ========== 超参数重优化逻辑 ==========
                retrain_cfg = al_cfg.get('model_retraining', {})
                hyperopt_strategy = retrain_cfg.get('hyperopt_strategy', 'none')
                reoptimize_freq = retrain_cfg.get('reoptimize_frequency', 3)
                
                need_reoptimize = False
                
                if hyperopt_strategy == 'none':
                    # 不重优化
                    pass
                elif hyperopt_strategy == 'periodic_only':
                    # 仅定期重优化
                    if iteration % reoptimize_freq == 0:
                        need_reoptimize = True
                        logger.info(f"触发定期超参数重优化（迭代 {iteration}）")
                elif hyperopt_strategy == 'periodic_with_validation':
                    # 定期 + 轻量级验证
                    if iteration % reoptimize_freq == 0:
                        need_reoptimize = True
                        logger.info(f"触发定期超参数重优化（迭代 {iteration}）")
                    else:
                        # 轻量级验证
                        validation_cfg = retrain_cfg.get('validation', {})
                        if validation_cfg.get('enabled', True):
                            logger.info("执行轻量级超参数验证...")
                            idt_params_path = 'output/models/idt/best_params.json'
                            if os.path.exists(idt_params_path):
                                with open(idt_params_path, 'r') as f:
                                    current_params = json.load(f)
                                is_valid = validate_hyperparams(
                                    X_idt, y_idt, idt_features, current_params,
                                    cv_folds=validation_cfg.get('cv_folds', 3),
                                    performance_threshold=validation_cfg.get('performance_drop_threshold', 0.1)
                                )
                                if not is_valid:
                                    need_reoptimize = True
                                    logger.warning("超参数验证失败，触发重优化")
                
                # 执行训练/重优化
                if need_reoptimize:
                    optuna_cfg = retrain_cfg.get('optuna', {})
                    n_trials = optuna_cfg.get('n_trials', 50)
                    use_prev_best = optuna_cfg.get('use_previous_best', True)
                    
                    prev_params = None
                    if use_prev_best:
                        idt_params_path = 'output/models/idt/best_params.json'
                        if os.path.exists(idt_params_path):
                            with open(idt_params_path, 'r') as f:
                                prev_params = json.load(f)
                    
                    logger.info(f"开始超参数优化: n_trials={n_trials}, use_prev_best={use_prev_best}")
                    idt_model, idt_best_params = retrain_with_optimization(
                        X_idt, y_idt, idt_features,
                        model_type='idt',
                        prev_best_params=prev_params,
                        n_trials=n_trials,
                        cv_folds=3
                    )
                    logger.info(f"IDT模型重训练完成（带优化）: {len(merged_idt)} 样本")
                else:
                    idt_model = retrain_xgboost(X_idt, y_idt, idt_features, model_type='idt')
                    logger.info(f"IDT模型重训练完成: {len(merged_idt)} 样本")
                
                merged_lfs = None
                if skip_infill:
                    merged_lfs = lfs_train_df
                elif lfs_train_df is not None and infill_lfs is not None and len(infill_lfs) > 0:
                    merged_lfs = merge_training_data(lfs_train_df, infill_lfs, 'LFS')
                
                if merged_lfs is not None:
                    X_lfs, y_lfs = prepare_lfs_training_data(merged_lfs, lfs_features)
                    
                    # LFS 同样的重优化逻辑
                    if need_reoptimize:
                        prev_params = None
                        if use_prev_best:
                            lfs_params_path = 'output/models/lfs/best_params.json'
                            if os.path.exists(lfs_params_path):
                                with open(lfs_params_path, 'r') as f:
                                    prev_params = json.load(f)
                        
                        lfs_model, lfs_best_params = retrain_with_optimization(
                            X_lfs, y_lfs, lfs_features,
                            model_type='lfs',
                            prev_best_params=prev_params,
                            n_trials=n_trials,
                            cv_folds=3
                        )
                        logger.info(f"LFS模型重训练完成（带优化）: {len(merged_lfs)} 样本")
                    else:
                        lfs_model = retrain_xgboost(X_lfs, y_lfs, lfs_features, model_type='lfs')
                        logger.info(f"LFS模型重训练完成: {len(merged_lfs)} 样本")
                
                idt_train_df = merged_idt
                lfs_train_df = merged_lfs if lfs_train_df is not None else None
                
                eval_fn = create_evaluation_function(
                    idt_model, lfs_model,
                    idt_features, lfs_features,
                    idt_conditions, lfs_conditions,
                    idt_reference, lfs_reference,
                    lambda_reg, logA_base
                )
        else:
            logger.info("跳过模型重训练（仅IDT模式或无训练数据）")
    
    if not al_results['converged']:
        best_iter = min(al_results['iterations'], key=lambda x: x['max_validation_error'])
        al_results['final_solution'] = {
            'logA': best_iter['logA_candidate'],
            'A': np.power(10, best_iter['logA_candidate']).tolist(),
            'validation_error': best_iter['max_validation_error']
        }
        logger.info(f"\n达到最大迭代次数，使用最优解（迭代{best_iter['iteration']}）")
    
    total_time = time.time() - start_time
    al_results['total_time'] = total_time
    
    al_results['alpha'] = final_alpha
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_results(al_results, output_dir, f"active_learning_results_{timestamp}.json")
    
    logger.info("\n" + "=" * 60)
    logger.info("主动学习优化完成!")
    logger.info("=" * 60)
    logger.info(f"总耗时: {total_time/60:.1f} 分钟")
    logger.info(f"收敛: {al_results['converged']}")
    final_max_rel = al_results['final_solution']['validation_error']
    logger.info(f"最终结果:")
    
    # 正确访问 validation_error 中的嵌套数据（添加类型检查）
    final_solution = al_results.get('final_solution', {})
    validation_error = final_solution.get('validation_error', {})
    
    # 类型检查：validation_error 可能是 dict 或 float
    if isinstance(validation_error, dict):
        if "initial_idt_max_rel" in al_results:
            init_idt = al_results["initial_idt_max_rel"] * 100
            final_idt = validation_error.get('idt', {}).get('max_relative_error', 0) * 100
            if init_idt > 0:
                logger.info(f"  IDT: {init_idt:.1f}% -> {final_idt:.1f}% (改善{(init_idt-final_idt)/init_idt*100:.1f}%)")
        
        if "initial_lfs_max_rel" in al_results:
            init_lfs = al_results["initial_lfs_max_rel"] * 100
            final_lfs = validation_error.get('lfs', {}).get('max_relative_error', 0) * 100
            if init_lfs > 0:
                logger.info(f"  LFS: {init_lfs:.1f}% -> {final_lfs:.1f}% (改善{(init_lfs-final_lfs)/init_lfs*100:.1f}%)")
        
        # 如果没有初始值，显示最终值
        if "initial_idt_max_rel" not in al_results:
            final_idt = validation_error.get('idt', {}).get('max_relative_error', 0) * 100
            final_lfs = validation_error.get('lfs', {}).get('max_relative_error', 0) * 100
            logger.info(f"  IDT: {final_idt:.1f}%")
            logger.info(f"  LFS: {final_lfs:.1f}%")
    else:
        # validation_error 是 float 类型（旧数据结构）
        logger.warning("validation_error 类型为 float，使用备用输出方式")
        final_idt = validation_error * 100 if isinstance(validation_error, (int, float)) else 0
        final_lfs = 0
        if "initial_idt_max_rel" in al_results:
            init_idt = al_results["initial_idt_max_rel"] * 100
            if init_idt > 0:
                logger.info(f"  IDT: {init_idt:.1f}% -> {final_idt:.1f}% (改善{(init_idt-final_idt)/init_idt*100:.1f}%)")
        logger.info(f"  最终 IDT 误差：{final_idt:.1f}%")

    return al_results


def main():
    parser = argparse.ArgumentParser(description='2.4 Active Learning GA Optimization')
    parser.add_argument('-c', '--config', default='config/ga_config.yaml',
                        help='配置文件路径')
    parser.add_argument('--skip-lfs', action='store_true',
                        help='跳过LFS验证（LFS模型未训练时使用）')
    parser.add_argument('--idt-only', action='store_true',
                        help='仅使用IDT模型（LFS模型不存在时）')
    parser.add_argument('--alpha', type=float, default=None,
                        help='IDT/LFS权重平衡系数 (覆盖配置文件)')
    args = parser.parse_args()
    
    config = load_config(args.config)
    results = run_active_learning(config, skip_lfs=args.skip_lfs, 
                                   idt_only=args.idt_only, alpha=args.alpha)


if __name__ == "__main__":
    main()
