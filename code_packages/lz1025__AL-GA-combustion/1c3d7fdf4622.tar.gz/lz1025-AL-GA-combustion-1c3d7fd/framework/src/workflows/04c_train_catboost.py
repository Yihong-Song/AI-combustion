# =============================================================================
# src/workflows/04c_train_catboost.py
# =============================================================================
# 工作流步骤 4c: 训练CatBoost模型 (XGBoost升级版)
# =============================================================================
#
# 功能：
#   - 使用CatBoost训练IDT和LFS预测模型
#   - 有序提升(Ordered Boosting)减少过拟合
#   - 对称树(Symmetric Trees)更好建模非线性关系
#   - 样本加权处理高IDT区域稀疏问题
#
# 输入文件：
#   - output/idt_results.csv: IDT计算结果
#   - output/lfs_results.csv: LFS计算结果
#   - config/config.yaml: 配置文件
#
# 输出文件：
#   - output/models/idt_catboost/model.cbm: CatBoost模型文件
#   - output/models/idt_catboost/metrics.json: 评估指标
#
# 使用方法：
#   python src/workflows/04c_train_catboost.py --target idt
#   python src/workflows/04c_train_catboost.py --target idt --iterations 2000
#
# =============================================================================
# -*- coding: utf-8 -*-

import os
import sys
import json
import logging
import argparse
import pickle
from datetime import datetime
from typing import Tuple, Dict, List, Optional

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupShuffleSplit
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import r2_score, mean_absolute_percentage_error
from scipy.stats import pearsonr, kendalltau

import catboost as cb
from catboost import CatBoostRegressor, Pool

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.core.config_loader import load_config_with_override

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    encoding='utf-8'
)
logger = logging.getLogger(__name__)

# =============================================================================
# 配置常量
# =============================================================================
LOG_A_COLS = [f'logA_{i}' for i in range(1, 21)]

# =============================================================================
# 数据处理函数 (复用04脚本)
# =============================================================================
def get_latest_file(pattern: str) -> str:
    """获取最新的文件（基于时间戳）"""
    import glob
    files = glob.glob(pattern)
    if not files:
        return None
    return max(files, key=os.path.getmtime)


def load_idt_data(csv_path: str = None) -> pd.DataFrame:
    """加载IDT计算结果"""
    if csv_path is None:
        csv_path = get_latest_file("output/idt_results*.csv")
        if csv_path is None:
            raise FileNotFoundError("未找到IDT结果文件")
    logger.info(f"加载IDT数据: {csv_path}")
    df = pd.read_csv(csv_path)
    logger.info(f"  加载 {len(df)} 条记录")
    return df


def load_lfs_data(csv_path: str = None) -> pd.DataFrame:
    """加载LFS计算结果"""
    if csv_path is None:
        csv_path = get_latest_file("output/lfs_results*.csv")
        if csv_path is None:
            raise FileNotFoundError("未找到LFS结果文件")
    logger.info(f"加载LFS数据: {csv_path}")
    df = pd.read_csv(csv_path)
    logger.info(f"  加载 {len(df)} 条记录")
    return df


def transform_idt_features(df: pd.DataFrame) -> pd.DataFrame:
    """转换IDT特征"""
    logger.info("转换IDT特征...")
    result = df.copy()
    
    result['T_inv'] = 1000.0 / result['T']
    result['logP'] = np.log10(result['P_bar'])
    
    total_fuel = result['X_NH3'] + result['X_H2']
    result['NH3_ratio'] = np.where(
        total_fuel > 0,
        result['X_NH3'] / total_fuel,
        0.0
    )
    result['C7_ratio'] = result['X_C7']
    
    result['log10_tau'] = np.where(
        result['tau_ign_us'] > 0,
        np.log10(result['tau_ign_us'] * 1e-6),
        np.nan
    )
    
    result = auto_generate_features(result)
    
    valid_count = result['log10_tau'].notna().sum()
    logger.info(f"  有效记录: {valid_count}/{len(result)}")
    
    return result


def transform_lfs_features(df: pd.DataFrame) -> pd.DataFrame:
    """转换LFS特征"""
    logger.info("转换LFS特征...")
    result = df.copy()
    
    if 'T_u' in result.columns:
        result['T'] = result['T_u']
    
    result['T_inv'] = 1000.0 / result['T']
    result['logP'] = np.log10(result['P_bar'])
    
    total_fuel = result['X_NH3'] + result['X_H2']
    result['NH3_ratio'] = np.where(
        total_fuel > 0,
        result['X_NH3'] / total_fuel,
        0.0
    )
    result['C7_ratio'] = result['X_C7']
    
    result['log10_SL'] = np.where(
        result['S_L_cm_s'] > 0,
        np.log10(result['S_L_cm_s'] * 0.01),
        np.nan
    )
    
    result = auto_generate_features(result)
    
    valid_count = result['log10_SL'].notna().sum()
    logger.info(f"  有效记录: {valid_count}/{len(result)}")
    
    return result


def auto_generate_features(df: pd.DataFrame) -> pd.DataFrame:
    """自动生成额外特征"""
    result = df.copy()
    
    if 'T_inv' not in result.columns or 'logP' not in result.columns:
        return result
    
    result['T_inv_phi'] = result['T_inv'] * result['phi']
    result['logP_phi'] = result['logP'] * result['phi']
    
    base_cols = ['T_inv', 'logP', 'phi', 'NH3_ratio', 'C7_ratio']
    
    for col in base_cols:
        if col in result.columns:
            result[f'{col}_sq'] = result[col] ** 2
    
    result['T_inv_logP'] = result['T_inv'] * result['logP']
    result['T_inv_NH3'] = result['T_inv'] * result['NH3_ratio']
    result['T_inv_C7'] = result['T_inv'] * result['C7_ratio']
    result['logP_NH3'] = result['logP'] * result['NH3_ratio']
    result['phi_NH3'] = result['phi'] * result['NH3_ratio']
    
    result['log_phi'] = np.log10(result['phi'] + 0.1)
    result['log_NH3'] = np.log10(result['NH3_ratio'] + 0.01)
    
    result['inv_P'] = 1.0 / result['P_bar']
    
    return result


def get_feature_cols() -> list:
    """特征列名"""
    base_features = [
        'T_inv', 'logP', 'phi', 'NH3_ratio', 'C7_ratio',
        'T_inv_phi', 'logP_phi'
    ]
    
    auto_features = [
        'T_inv_sq', 'logP_sq', 'phi_sq', 'NH3_ratio_sq', 'C7_ratio_sq',
        'T_inv_logP', 'T_inv_NH3', 'T_inv_C7', 'logP_NH3', 'phi_NH3',
        'log_phi', 'log_NH3', 'inv_P'
    ]
    
    return LOG_A_COLS + base_features + auto_features


def split_data(
    df: pd.DataFrame,
    target_col: str,
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    random_state: int,
    group_col: str = 'variant_id'
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """分割训练/验证/测试集（按variant_id分组）"""
    
    gss = GroupShuffleSplit(n_splits=1, test_size=test_ratio, random_state=random_state)
    train_val_idx, test_idx = next(gss.split(df, groups=df[group_col]))
    
    train_val = df.iloc[train_val_idx].reset_index(drop=True)
    test = df.iloc[test_idx].reset_index(drop=True)
    
    val_ratio_adjusted = val_ratio / (train_ratio + val_ratio)
    gss2 = GroupShuffleSplit(n_splits=1, test_size=val_ratio_adjusted, random_state=random_state)
    train_idx, val_idx = next(gss2.split(train_val, groups=train_val[group_col]))
    
    train = train_val.iloc[train_idx].reset_index(drop=True)
    val = train_val.iloc[val_idx].reset_index(drop=True)
    
    logger.info(f"  训练集: {len(train)} ({train[group_col].nunique()} variants)")
    logger.info(f"  验证集: {len(val)} ({val[group_col].nunique()} variants)")
    logger.info(f"  测试集: {len(test)} ({test[group_col].nunique()} variants)")
    
    return train, val, test


# =============================================================================
# CatBoost训练
# =============================================================================
def train_catboost_model(
    config: Dict,
    iterations: int = 2000,
    target: str = 'idt',
    output_dir: str = None
):
    """训练CatBoost模型"""
    
    # 加载数据
    if target == 'idt':
        df = load_idt_data()
        df = transform_idt_features(df)
        df = df.dropna(subset=['log10_tau'])
        target_col = 'log10_tau'
        target_name = 'IDT'
    else:
        df = load_lfs_data()
        df = transform_lfs_features(df)
        df = df.dropna(subset=['log10_SL'])
        target_col = 'log10_SL'
        target_name = 'LFS'
    
    logger.info(f"有效数据: {len(df)} 条")
    
    feature_cols = get_feature_cols()
    
    # 分割数据
    split_config = config['xgboost']['data_split']
    train, val, test = split_data(
        df, target_col,
        split_config['train_ratio'],
        split_config['val_ratio'],
        split_config['test_ratio'],
        split_config['random_state']
    )
    
    # 准备数据
    X_train = train[feature_cols]
    y_train = train[target_col]
    X_val = val[feature_cols]
    y_val = val[target_col]
    X_test = test[feature_cols]
    y_test = test[target_col]
    
    # 样本加权 (高IDT区域权重翻倍)
    sample_weights = np.where(y_train > -2, 2.0, 1.0)
    val_weights = np.where(y_val > -2, 2.0, 1.0)
    
    high_idt_count = (y_train > -2).sum() + (y_val > -2).sum()
    logger.info(f"样本加权: 高IDT区域 {high_idt_count} 个样本权重翻倍")
    
    # 创建CatBoost数据池
    train_pool = Pool(X_train, y_train, weight=sample_weights)
    val_pool = Pool(X_val, y_val, weight=val_weights)
    test_pool = Pool(X_test)
    
    # 确定输出目录
    if output_dir is None:
        output_dir = config['xgboost']['output']['models_dir']
    target_dir = os.path.join(output_dir, f'{target}_catboost')
    os.makedirs(target_dir, exist_ok=True)
    
    # CatBoost 参数 (CatBoost 默认参数已很优秀)
    # 从 config 读取模型重训练参数
    model_retraining_config = config.get('model_retraining', {})
    
    catboost_params = {
        'iterations': iterations,
        'depth': 8,
        'learning_rate': 0.03,
        'loss_function': 'RMSE',
        'eval_metric': 'RMSE',
        'random_seed': 42,
        'verbose': 100,
        'use_best_model': True,
        'early_stopping_rounds': 100,
        # CatBoost 特有参数
        'boosting_type': 'Ordered',  # 有序提升，减少过拟合
        'grow_policy': 'SymmetricTree',  # 对称树
        'l2_leaf_reg': model_retraining_config.get('l2_leaf_reg', 3.0),
        'random_strength': model_retraining_config.get('random_strength', 1.0),
        'border_count': 254,
    }
    
    # 可选参数：od_type 和 od_pval (用于早停)
    od_type = model_retraining_config.get('od_type', None)
    od_pval = model_retraining_config.get('od_pval', None)
    if od_type is not None:
        catboost_params['od_type'] = od_type
    if od_pval is not None:
        catboost_params['od_pval'] = od_pval
    
    logger.info("=" * 60)
    logger.info(f"开始训练 CatBoost {target_name} 模型")
    logger.info("=" * 60)
    
    # 训练模型
    model = CatBoostRegressor(**catboost_params)
    model.fit(train_pool, eval_set=val_pool, verbose=100)
    
    # 保存模型
    model_path = os.path.join(target_dir, 'model.cbm')
    model.save_model(model_path)
    logger.info(f"模型已保存: {model_path}")
    
    # 保存特征重要性
    feature_importance = model.get_feature_importance(train_pool, type='PredictionValuesChange')
    importance_df = pd.DataFrame({
        'feature': feature_cols,
        'importance': feature_importance
    }).sort_values('importance', ascending=False)
    
    importance_path = os.path.join(target_dir, 'feature_importance.csv')
    importance_df.to_csv(importance_path, index=False)
    logger.info(f"特征重要性已保存: {importance_path}")
    
    # 保存特征列表
    feature_list_path = os.path.join(target_dir, 'feature_list.json')
    with open(feature_list_path, 'w') as f:
        json.dump(feature_cols, f, indent=2)
    logger.info(f"特征列表已保存: {feature_list_path}")
    
    # 评估
    logger.info("=" * 60)
    logger.info("测试集评估")
    
    y_pred = model.predict(test_pool)
    
    rmse = np.sqrt(np.mean((y_pred - y_test) ** 2))
    mae = np.mean(np.abs(y_pred - y_test))
    r2 = r2_score(y_test, y_pred)
    bias = np.mean(y_pred - y_test)
    pearson_r, _ = pearsonr(y_test, y_pred)
    kendall_t, _ = kendalltau(y_test, y_pred)
    
    # MAPE
    mask = y_test != 0
    mape = np.mean(np.abs((y_test[mask] - y_pred[mask]) / y_test[mask])) * 100 if mask.sum() > 0 else 0
    
    metrics = {
        'RMSE': float(rmse),
        'MAE': float(mae),
        'R2': float(r2),
        'MAPE': float(mape),
        'Bias': float(bias),
        'Pearson_r': float(pearson_r),
        'Kendall_tau': float(kendall_t)
    }
    
    logger.info(f"  RMSE: {rmse:.6f}")
    logger.info(f"  MAE: {mae:.6f}")
    logger.info(f"  R2: {r2:.6f}")
    logger.info(f"  MAPE: {mape:.6f}")
    logger.info(f"  Bias: {bias:.6f}")
    logger.info(f"  Pearson_r: {pearson_r:.6f}")
    logger.info(f"  Kendall_tau: {kendall_t:.6f}")
    
    # 保存评估指标
    metrics_path = os.path.join(target_dir, 'metrics.json')
    with open(metrics_path, 'w') as f:
        json.dump(metrics, f, indent=2)
    logger.info(f"评估指标已保存: {metrics_path}")
    
    # 区域评估
    logger.info("\n分区域评估:")
    high_idt_mask = y_test > -2
    if np.any(high_idt_mask):
        high_rmse = np.sqrt(np.mean((y_pred[high_idt_mask] - y_test[high_idt_mask]) ** 2))
        high_bias = np.mean(y_pred[high_idt_mask] - y_test[high_idt_mask])
        logger.info(f"  高IDT区域 (log10_tau > -2):")
        logger.info(f"    RMSE: {high_rmse:.6f}, Bias: {high_bias:.6f}, n={np.sum(high_idt_mask)}")
    
    # Parity Plot
    generate_parity_plot(y_test, y_pred, os.path.join(target_dir, 'parity.png'), target_name)
    
    # 保存Parity数据
    parity_df = pd.DataFrame({
        'y_true': y_test,
        'y_pred': y_pred,
        'error': y_pred - y_test
    })
    parity_df.to_csv(os.path.join(target_dir, 'parity_data.csv'), index=False)
    
    logger.info("=" * 60)
    logger.info(f"CatBoost {target_name} 模型训练完成!")
    logger.info("=" * 60)
    
    return model, metrics


def generate_parity_plot(y_true, y_pred, output_path, name):
    """生成Parity Plot"""
    fig, ax = plt.subplots(figsize=(8, 8))
    
    min_val = min(y_true.min(), y_pred.min())
    max_val = max(y_true.max(), y_pred.max())
    margin = (max_val - min_val) * 0.1
    
    ax.scatter(y_true, y_pred, alpha=0.5, s=20, c='blue', label='Predictions')
    ax.plot([min_val - margin, max_val + margin],
            [min_val - margin, max_val + margin],
            'k--', linewidth=1.5, label='Perfect Prediction')
    
    # 误差线 (log10空间相对误差)
    error_margin_15 = np.log10(1.15)
    error_margin_30 = np.log10(1.30)
    
    ax.plot([min_val - margin, max_val + margin],
            [min_val - margin + error_margin_15, max_val + margin + error_margin_15],
            'r-.', linewidth=1, alpha=0.7, label='±15%')
    ax.plot([min_val - margin, max_val + margin],
            [min_val - margin - error_margin_15, max_val + margin - error_margin_15],
            'r-.', linewidth=1, alpha=0.7)
    ax.plot([min_val - margin, max_val + margin],
            [min_val - margin + error_margin_30, max_val + margin + error_margin_30],
            'g-.', linewidth=1, alpha=0.7, label='±30%')
    ax.plot([min_val - margin, max_val + margin],
            [min_val - margin - error_margin_30, max_val + margin - error_margin_30],
            'g-.', linewidth=1, alpha=0.7)
    
    ax.set_xlabel('True Value')
    ax.set_ylabel('Predicted Value')
    ax.set_title(f'{name} Parity Plot (CatBoost)')
    ax.legend(loc='upper left')
    ax.set_xlim(min_val - margin, max_val + margin)
    ax.set_ylim(min_val - margin, max_val + margin)
    ax.set_aspect('equal', adjustable='box')
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    
    logger.info(f"Parity Plot已保存: {output_path}")


def main():
    parser = argparse.ArgumentParser(description='训练CatBoost模型')
    parser.add_argument('-c', '--config', default='config/config.yaml', help='Config file path')
    parser.add_argument('--target', choices=['idt', 'lfs', 'all'], default='idt', help='Target to train')
    parser.add_argument('--iterations', type=int, default=2000, help='Number of iterations')
    parser.add_argument('--output-dir', default=None, help='Output directory')
    
    args = parser.parse_args()
    
    config = load_config_with_override(args.config)
    
    if args.target in ['idt', 'all']:
        train_catboost_model(
            config,
            iterations=args.iterations,
            target='idt',
            output_dir=args.output_dir
        )
    
    if args.target in ['lfs', 'all']:
        train_catboost_model(
            config,
            iterations=args.iterations,
            target='lfs',
            output_dir=args.output_dir
        )


if __name__ == "__main__":
    main()