# =============================================================================
# src/workflows/06_lambda_selection.py
# =============================================================================
# 工作流步骤 6/9: 正则化系数λ选择
# =============================================================================
#
# 功能：
#   - 通过GA优化+Cantera验证选择最优正则化系数λ
#   - 对每个λ候选值运行遗传算法优化
#   - 使用Cantera验证优化结果的物理可行性
#   - 选择验证误差最小的λ值
#
# 核心函数：
#   - run_lambda_selection(): 主流程函数
#   - run_ga_for_lambda(): 对单个λ运行GA优化
#   - cantera_validate(): Cantera物理验证
#
# 输入文件：
#   - output/models/idt/model.json: IDT代理模型（来自步骤4）
#   - output/models/lfs/model.json: LFS代理模型（来自步骤4）
#   - data/ground_truth/idt_det_reference.csv: IDT Ground Truth（来自步骤5）
#   - data/ground_truth/lfs_exp_reference.csv: LFS Ground Truth（来自步骤5）
#   - data/logA_base.npy: 基线logA值
#
# 输出文件：
#   - output/lambda_selection/lambda_selection_TIMESTAMP.json: λ选择结果
#     包含：
#     - 各λ候选值的验证误差
#     - 最优λ值
#     - 优化轨迹
#
# 使用方法：
#   python src/workflows/06_lambda_selection.py -c config/ga_config.yaml
#   python src/workflows/06_lambda_selection.py --lambdas 0.001 0.01 0.1
#   python src/workflows/06_lambda_selection.py --alpha 0.85
#
# λ的物理意义：
#   - λ=0: 无约束，优化结果可能大幅偏离基线机理
#   - λ大: 保守优化，结果接近基线机理
#   - 推荐范围: 0.001 - 0.1
#
# 计算时间：
#   - 每个λ候选值：约10-15分钟（GA+Cantera验证）
#   - 6个候选值总计：约1-1.5小时
#
# 前置步骤：
#   - 04_train_xgboost.py: 训练代理模型
#   - 05_prepare_ground_truth.py: 准备Ground Truth
#
# 后续步骤：
#   - 07_active_learning_ga.py: 主动学习优化（使用选定λ）
#
# =============================================================================
# -*- coding: utf-8 -*-



import os
import sys
import json
import yaml
import logging
import argparse
import time
from datetime import datetime
from typing import Dict, List, Any, Tuple

import numpy as np
import pandas as pd
import xgboost as xgb

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.core.objective import (
    load_surrogate_models, load_feature_lists, load_ground_truth,
    build_features_batch, predict_idt, predict_lfs, compute_objective
)
from src.core.ga_optimizer import (
    create_bounds, setup_toolbox, run_ga_with_callback,
    create_evaluation_function
)
from src.core.cantera_validator import validate_candidate, compute_validation_error

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - INFO - %(message)s'
)
logger = logging.getLogger(__name__)


def load_config(config_path: str) -> Dict[str, Any]:
    """加载配置文件"""
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def run_ga_for_lambda(logA_base: np.ndarray,
                      idt_model: xgb.Booster, lfs_model: xgb.Booster,
                      idt_features: List[str], lfs_features: List[str],
                      idt_conditions: pd.DataFrame, lfs_conditions: pd.DataFrame,
                      idt_reference: np.ndarray, lfs_reference: np.ndarray,
                      lambda_reg: float,
                      ga_cfg: Dict[str, Any],
                      bounds: Tuple[np.ndarray, np.ndarray],
                      alpha: float = 0.5,
                      n_generations: int = 50,
                      idt_only: bool = False) -> Tuple[np.ndarray, float, List[Dict]]:
    """
    对给定λ运行GA优化
    
    返回: (最优logA, 最优适应度, GA历史)
    """
    def eval_fn(individual):
        logA = np.array(individual)
        error_type = config.get('objective', {}).get('error_type', 'log_mse')
        idt_unit = config.get('objective', {}).get('idt_unit', 'us')
        lfs_unit = config.get('objective', {}).get('lfs_unit', 'cm/s')
        result = compute_objective(
            logA, idt_model, lfs_model,
            idt_features, lfs_features,
            idt_conditions, lfs_conditions,
            idt_reference, lfs_reference,
            lambda_reg, logA_base, alpha,
            error_type, idt_unit, lfs_unit,  # 新增参数
            idt_only
        )
        return (result['total'],)
    
    toolbox = setup_toolbox(bounds, eval_fn, ga_cfg)
    
    best_ind, best_fitness, ga_history = run_ga_with_callback(
        toolbox, 
        {'n_generations': n_generations, **ga_cfg},
        callback=None,
        verbose=False
    )
    
    return np.array(best_ind), float(best_fitness), ga_history


def cantera_validate(logA_array: np.ndarray,
                     mech_path: str,
                     reaction_indices: List[int],
                     idt_conditions: pd.DataFrame,
                     lfs_conditions: pd.DataFrame,
                     idt_reference: np.ndarray,
                     lfs_reference: np.ndarray,
                     idt_model: xgb.Booster, lfs_model: xgb.Booster,
                     idt_features: List[str], lfs_features: List[str],
                     use_lfs: bool = True,
                     n_workers: int = 12) -> Dict[str, Any]:
    """
    Cantera验证
    
    返回: {
        'idt_msre': IDT均方相对误差,
        'lfs_msre': LFS均方相对误差,
        'idt_max_relative_error': IDT最大相对误差,
        'lfs_max_relative_error': LFS最大相对误差,
        'max_relative_error': 最大相对误差
    }
    """
    # Cantera验证
    idt_true, lfs_true = validate_candidate(
        logA_array, mech_path, reaction_indices,
        idt_conditions, lfs_conditions, n_workers=n_workers
    )
    
    # 代理模型预测
    idt_pred_feat = build_features_batch(logA_array, idt_conditions, idt_features)
    idt_pred_log = predict_idt(idt_model, idt_pred_feat, idt_features)
    idt_pred = 10 ** idt_pred_log
    
    # IDT验证误差
    idt_result = compute_validation_error(idt_pred, idt_true, error_type='idt')
    idt_msre = idt_result['msre']
    idt_max_rel = idt_result['max_relative_error']
    
    # IDT相对误差方差
    idt_valid_mask = np.isfinite(idt_pred) & np.isfinite(idt_true) & (idt_true > 0)
    idt_rel_errors = np.abs(idt_pred[idt_valid_mask] - idt_true[idt_valid_mask]) / idt_true[idt_valid_mask]
    idt_rel_var = float(np.var(idt_rel_errors)) if len(idt_rel_errors) > 0 else 0.0
    
    # LFS验证误差
    if use_lfs:
        lfs_pred_feat = build_features_batch(logA_array, lfs_conditions, lfs_features)
        lfs_pred_log = predict_lfs(lfs_model, lfs_pred_feat, lfs_features)
        lfs_pred = 10 ** lfs_pred_log
        
        lfs_result = compute_validation_error(lfs_pred, lfs_true, error_type='lfs')
        lfs_msre = lfs_result['msre']
        lfs_max_rel = lfs_result['max_relative_error']
        
        # LFS相对误差方差
        lfs_valid_mask = np.isfinite(lfs_pred) & np.isfinite(lfs_true) & (np.abs(lfs_true) > 1e-30)
        lfs_rel_errors = np.abs(lfs_pred[lfs_valid_mask] - lfs_true[lfs_valid_mask]) / np.abs(lfs_true[lfs_valid_mask])
        lfs_rel_var = float(np.var(lfs_rel_errors)) if len(lfs_rel_errors) > 0 else 0.0
    else:
        lfs_msre = 0.0
        lfs_max_rel = 0.0
        lfs_rel_var = 0.0
    
    max_rel_error = max(idt_max_rel, lfs_max_rel)
    
    return {
        'idt_msre': idt_msre,
        'lfs_msre': lfs_msre,
        'idt_max_relative_error': idt_max_rel,
        'lfs_max_relative_error': lfs_max_rel,
        'idt_relative_error_var': idt_rel_var,
        'lfs_relative_error_var': lfs_rel_var,
        'max_relative_error': max_rel_error
    }


def run_lambda_selection(config: Dict[str, Any],
                          lambda_candidates: List[float] = None,
                          n_generations: int = 50,
                          alpha: float = None) -> Dict[str, Any]:
    """
    运行λ选择
    
    参数:
        config: 配置字典
        lambda_candidates: λ候选值列表
        n_generations: GA代数（减少以加速）
        alpha: IDT/LFS权重
    """
    start_time = time.time()
    
    models_cfg = config['models']
    gt_cfg = config['ground_truth']
    mech_cfg = config['mechanism']
    ga_cfg = config['genetic_algorithm']
    
    # 获取Cantera并行进程数
    cantera_workers = config.get('cantera', {}).get('n_workers', 12)
    
    # 从配置文件获取λ候选值（命令行参数可覆盖）
    if lambda_candidates is None:
        lambda_cfg = config.get('lambda_cv', {})
        lambda_candidates = lambda_cfg.get('candidates', [0, 0.001, 0.01, 0.1, 1.0])
    
    # 获取alpha
    if alpha is None:
        alpha = config.get('objective', {}).get('alpha', 0.5)
    
    logger.info("=" * 60)
    logger.info("λ正则化系数选择")
    logger.info("=" * 60)
    logger.info(f"λ候选值: {lambda_candidates}")
    logger.info(f"GA代数: {n_generations}")
    logger.info(f"α: {alpha}")
    logger.info(f"Cantera并行进程数: {cantera_workers}")
    
    # 加载模型
    logger.info("加载模型...")
    idt_model, _ = load_surrogate_models(models_cfg['idt_model'], models_cfg['idt_model'])
    _, lfs_model = load_surrogate_models(models_cfg['idt_model'], models_cfg['lfs_model'])
    
    idt_features, _ = load_feature_lists(models_cfg['idt_feature_list'], models_cfg['idt_feature_list'])
    _, lfs_features = load_feature_lists(models_cfg['idt_feature_list'], models_cfg['lfs_feature_list'])
    
    # 加载GT数据
    logger.info("加载Ground Truth数据...")
    idt_conditions, lfs_conditions = load_ground_truth(gt_cfg['idt_reference'], gt_cfg['lfs_reference'])
    idt_reference = idt_conditions['reference_idt'].values
    lfs_reference = lfs_conditions['reference_lfs_ms'].values
    use_lfs = True
    
    # 加载基线
    logA_base = np.load(mech_cfg['logA_base_file'])
    reaction_indices = mech_cfg['reaction_indices']
    mech_path = mech_cfg['path']
    
    # 创建搜索边界
    bounds = create_bounds(logA_base, config['search_space']['offset_range'])
    
    # 结果存储
    results = {
        'lambda_candidates': lambda_candidates,
        'alpha': alpha,
        'n_generations': n_generations,
        'selection_results': [],
        'best_lambda': None,
        'total_time': 0
    }
    
    logger.info("\n" + "=" * 60)
    logger.info("开始λ扫描...")
    logger.info("=" * 60)
    
    for i, lam in enumerate(lambda_candidates):
        logger.info(f"\n[{i+1}/{len(lambda_candidates)}] 测试 λ = {lam}")
        logger.info("-" * 40)
        
        iter_start = time.time()
        
        # 1. 运行GA优化
        logger.info(f"  运行GA优化 (λ={lam})...")
        best_logA, best_fitness, ga_history = run_ga_for_lambda(
            logA_base, idt_model, lfs_model,
            idt_features, lfs_features,
            idt_conditions, lfs_conditions,
            idt_reference, lfs_reference,
            lam, ga_cfg, bounds, alpha, n_generations
        )
        
        # 2. Cantera验证
        logger.info(f"  Cantera验证 ({cantera_workers}进程)...")
        val_result = cantera_validate(
            best_logA, mech_path, reaction_indices,
            idt_conditions, lfs_conditions,
            idt_reference, lfs_reference,
            idt_model, lfs_model,
            idt_features, lfs_features, use_lfs,
            n_workers=cantera_workers
        )
        
        # 3. 计算参数偏离度
        param_deviation = np.max(np.abs(best_logA - logA_base))
        avg_param_deviation = np.mean(np.abs(best_logA - logA_base))
        
        # 4. 提取GA收敛信息
        ga_best_history = [h['best_fitness'] for h in ga_history]
        ga_avg_history = [h['avg_fitness'] for h in ga_history]
        
        iter_time = time.time() - iter_start
        
        # 记录结果（包含GA历史便于后续作图）
        result = {
            'lambda': lam,
            'ga_fitness': float(best_fitness),
            'idt_msre': float(val_result['idt_msre']),
            'lfs_msre': float(val_result['lfs_msre']),
            'idt_max_relative_error': float(val_result['idt_max_relative_error']),
            'lfs_max_relative_error': float(val_result['lfs_max_relative_error']),
            'idt_relative_error_var': float(val_result['idt_relative_error_var']),
            'lfs_relative_error_var': float(val_result['lfs_relative_error_var']),
            'max_relative_error': float(val_result['max_relative_error']),
            'param_deviation_max': float(param_deviation),
            'param_deviation_avg': float(avg_param_deviation),
            'logA_optimal': best_logA.tolist(),
            'ga_history_best': ga_best_history,
            'ga_history_avg': ga_avg_history,
            'iteration_time': iter_time
        }
        results['selection_results'].append(result)
        
        # 输出结果
        logger.info(f"  结果:")
        logger.info(f"    GA适应度: {best_fitness:.6f}")
        logger.info(f"    IDT: MSRE={val_result['idt_msre']:.6f}, var={val_result['idt_relative_error_var']:.6f}, max_rel={val_result['idt_max_relative_error']:.6f}")
        logger.info(f"    LFS: MSRE={val_result['lfs_msre']:.6f}, var={val_result['lfs_relative_error_var']:.6f}, max_rel={val_result['lfs_max_relative_error']:.6f}")
        logger.info(f"    参数偏离: {param_deviation:.4f} log10")
        logger.info(f"    耗时: {iter_time:.1f}s")
        logger.info(f"    [作图数据] IDT: MSRE={val_result['idt_msre']:.6f}, max_rel={val_result['idt_max_relative_error']:.6f} | LFS: MSRE={val_result['lfs_msre']:.6f}, max_rel={val_result['lfs_max_relative_error']:.6f}")
    
    # 选择最优λ（基于IDT_MSRE + LFS_MSRE总和最低）
    best_result = min(results['selection_results'], key=lambda x: x['idt_msre'] + x['lfs_msre'])
    results['best_lambda'] = best_result['lambda']
    results['best_result'] = best_result
    results['total_time'] = time.time() - start_time
    
    # 输出总结
    logger.info("\n" + "=" * 60)
    logger.info("λ扫描结果汇总（按IDT_MSRE+LFS_MSRE排序）")
    logger.info("=" * 60)
    logger.info(f"{'λ':>8} | {'IDT_MSRE':>12} | {'LFS_MSRE':>12} | {'IDT_var':>12} | {'LFS_var':>12} | {'参数偏离':>10}")
    logger.info("-" * 80)
    
    for r in sorted(results['selection_results'], key=lambda x: x['idt_msre'] + x['lfs_msre']):
        marker = " ← 最优" if r['lambda'] == results['best_lambda'] else ""
        logger.info(f"{r['lambda']:>8.4f} | {r['idt_msre']:>12.6f} | {r['lfs_msre']:>12.6f} | {r['idt_relative_error_var']:>12.6f} | {r['lfs_relative_error_var']:>12.6f} | {r['param_deviation_max']:>10.4f}{marker}")
    
    logger.info("\n" + "=" * 60)
    logger.info(f"最优λ = {results['best_lambda']} (基于IDT_MSRE+LFS_MSRE最低)")
    logger.info(f"  IDT: MSRE={best_result['idt_msre']:.6f}, var={best_result['idt_relative_error_var']:.6f}, max_rel={best_result['idt_max_relative_error']:.6f}")
    logger.info(f"  LFS: MSRE={best_result['lfs_msre']:.6f}, var={best_result['lfs_relative_error_var']:.6f}, max_rel={best_result['lfs_max_relative_error']:.6f}")
    logger.info(f"  参数偏离: {best_result['param_deviation_max']:.4f}")
    logger.info("=" * 60)
    logger.info(f"总耗时: {results['total_time']/60:.1f} 分钟")
    
    return results


def save_results(results: Dict[str, Any], output_dir: str, filename: str):
    """保存结果"""
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    logger.info(f"结果已保存: {filepath}")


def main():
    parser = argparse.ArgumentParser(description='λ正则化系数选择')
    parser.add_argument('-c', '--config', default='config/ga_config.yaml',
                       help='配置文件路径')
    parser.add_argument('--lambdas', type=float, nargs='+', default=None,
                       help='λ候选值列表（覆盖配置文件）')
    parser.add_argument('--n-generations', type=int, default=50,
                       help='GA代数（减少以加速）')
    parser.add_argument('--alpha', type=float, default=None,
                       help='IDT/LFS权重（覆盖配置文件）')
    parser.add_argument('--output-dir', default='output/lambda_selection',
                       help='输出目录')
    args = parser.parse_args()
    
    config = load_config(args.config)
    
    results = run_lambda_selection(
        config,
        lambda_candidates=args.lambdas,
        n_generations=args.n_generations,
        alpha=args.alpha
    )
    
    # 保存结果
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    save_results(results, args.output_dir, f"lambda_selection_{timestamp}.json")
    
    # 输出推荐配置
    logger.info("\n" + "=" * 60)
    logger.info("推荐配置 (添加到 ga_config.yaml):")
    logger.info("=" * 60)
    logger.info(f"lambda_cv:")
    logger.info(f"  candidates: {args.lambdas}")
    logger.info(f"  selected_lambda: {results['best_lambda']}")


if __name__ == "__main__":
    main()
