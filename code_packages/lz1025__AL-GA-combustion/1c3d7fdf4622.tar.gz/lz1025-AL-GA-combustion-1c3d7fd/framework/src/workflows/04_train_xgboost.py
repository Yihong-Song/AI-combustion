# =============================================================================
# src/workflows/04_train_xgboost.py
# =============================================================================
# 工作流步骤 4/9: 训练XGBoost代理模型
# =============================================================================
#
# 功能：
#   - 使用Cantera计算结果训练IDT和LFS预测模型
#   - Optuna贝叶斯超参数优化（默认300次试验）
#   - 5折交叉验证评估模型性能
#   - 生成综合评估报告和可视化图表
#
# 核心函数：
#   - train_target_model(): 训练单个目标模型
#   - optimize_hyperparameters(): Optuna超参数优化
#   - train_model(): 训练XGBoost模型
#   - evaluate_comprehensive(): 综合模型评估
#
# 输入文件：
#   - output/idt_results.csv: IDT计算结果（来自步骤3）
#   - output/lfs_results.csv: LFS计算结果（来自步骤3）
#   - config/config.yaml: 配置文件
#
# 输出文件：
#   - output/models/idt/model.json: IDT模型文件
#   - output/models/lfs/model.json: LFS模型文件
#   - output/models/idt/feature_list.json: IDT特征列表
#   - output/models/lfs/feature_list.json: LFS特征列表
#   - output/models/idt/best_params.json: IDT最优超参数
#   - output/models/lfs/best_params.json: LFS最优超参数
#   - output/models/idt/metrics.json: IDT评估指标
#   - output/models/lfs/metrics.json: LFS评估指标
#   - output/models/idt/parity.png: IDT Parity Plot
#   - output/models/lfs/parity.png: LFS Parity Plot
#   - output/models/idt/learning_curve.png: IDT学习曲线
#   - output/models/lfs/learning_curve.png: LFS学习曲线
#
# 使用方法：
#   python src/workflows/04_train_xgboost.py --target idt   # 仅训练IDT
#   python src/workflows/04_train_xgboost.py --target lfs   # 仅训练LFS
#   python src/workflows/04_train_xgboost.py                # 训练两者
#   python src/workflows/04_train_xgboost.py --n-trials 50  # 快速训练
#
# 训练时间：
#   - IDT: 约30-60分钟（300次Optuna试验）
#   - LFS: 约20-40分钟（300次Optuna试验）
#
# 前置步骤：
#   - 03_run_compute.py: 生成训练数据
#
# 后续步骤：
#   - 05_prepare_ground_truth.py: 准备Ground Truth
#   - 07_active_learning_ga.py: 主动学习优化
#
# =============================================================================
# -*- coding: utf-8 -*-



import os
import sys
import json
import logging
import glob
import argparse
from datetime import datetime
from typing import Tuple, Dict, Any, Optional

import numpy as np
import pandas as pd
import xgboost as xgb
import optuna
from optuna.samplers import TPESampler
from sklearn.model_selection import train_test_split, learning_curve, GroupShuffleSplit
from sklearn.metrics import mean_absolute_percentage_error, r2_score
from scipy.stats import pearsonr, kendalltau
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.core.config_loader import load_config_with_override

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    encoding='utf-8'
)
logger = logging.getLogger(__name__)


LOG_A_COLS = [f'logA_{i}' for i in range(1, 21)]


def get_latest_file(pattern: str) -> str:
    """获取最新的文件（基于时间戳）"""
    files = glob.glob(pattern)
    if not files:
        return None
    return max(files, key=os.path.getmtime)


def load_idt_data(csv_path: str = None) -> pd.DataFrame:
    """加载IDT计算结果"""
    if csv_path is None:
        csv_path = get_latest_file("output/idt_results*.csv")
        if csv_path is None:
            raise FileNotFoundError("未找到IDT结果文件，请先运行02_run_compute.py")
    logger.info(f"加载IDT数据: {csv_path}")
    df = pd.read_csv(csv_path)
    logger.info(f"  加载 {len(df)} 条记录")
    return df


def load_lfs_data(csv_path: str = None) -> pd.DataFrame:
    """加载LFS计算结果"""
    if csv_path is None:
        csv_path = get_latest_file("output/lfs_results*.csv")
        if csv_path is None:
            raise FileNotFoundError("未找到LFS结果文件，请先运行02_run_compute.py")
    logger.info(f"加载LFS数据: {csv_path}")
    df = pd.read_csv(csv_path)
    logger.info(f"  加载 {len(df)} 条记录")
    return df


def transform_idt_features(df: pd.DataFrame) -> pd.DataFrame:
    """转换IDT特征"""
    logger.info("转换IDT特征...")
    result = df.copy()
    
    result['T_inv'] = 1000.0 / result['T']
    result['logP'] = np.log10(result['P_bar'])
    
    total_fuel = result['X_NH3'] + result['X_H2']
    result['NH3_ratio'] = np.where(
        total_fuel > 0,
        result['X_NH3'] / total_fuel,
        0.0
    )
    result['C7_ratio'] = result['X_C7']
    
    result['log10_tau'] = np.where(
        result['tau_ign_us'] > 0,
        np.log10(result['tau_ign_us'] * 1e-6),
        np.nan
    )
    
    result = auto_generate_features(result)
    
    valid_count = result['log10_tau'].notna().sum()
    logger.info(f"  有效记录: {valid_count}/{len(result)}")
    
    return result


def transform_lfs_features(df: pd.DataFrame) -> pd.DataFrame:
    """转换LFS特征"""
    logger.info("转换LFS特征...")
    result = df.copy()
    
    if 'T_u' in result.columns:
        result['T'] = result['T_u']
    
    result['T_inv'] = 1000.0 / result['T']
    result['logP'] = np.log10(result['P_bar'])
    
    total_fuel = result['X_NH3'] + result['X_H2']
    result['NH3_ratio'] = np.where(
        total_fuel > 0,
        result['X_NH3'] / total_fuel,
        0.0
    )
    result['C7_ratio'] = result['X_C7']
    
    result['log10_SL'] = np.where(
        result['S_L_cm_s'] > 0,
        np.log10(result['S_L_cm_s'] * 0.01),
        np.nan
    )
    
    result = auto_generate_features(result)
    
    valid_count = result['log10_SL'].notna().sum()
    logger.info(f"  有效记录: {valid_count}/{len(result)}")
    
    return result


def auto_generate_features(df: pd.DataFrame) -> pd.DataFrame:
    """自动生成额外特征"""
    result = df.copy()
    
    if 'T_inv' not in result.columns or 'logP' not in result.columns:
        return result
    
    result['T_inv_phi'] = result['T_inv'] * result['phi']
    result['logP_phi'] = result['logP'] * result['phi']
    
    base_cols = ['T_inv', 'logP', 'phi', 'NH3_ratio', 'C7_ratio']
    
    for col in base_cols:
        if col in result.columns:
            result[f'{col}_sq'] = result[col] ** 2
    
    result['T_inv_logP'] = result['T_inv'] * result['logP']
    result['T_inv_NH3'] = result['T_inv'] * result['NH3_ratio']
    result['T_inv_C7'] = result['T_inv'] * result['C7_ratio']
    result['logP_NH3'] = result['logP'] * result['NH3_ratio']
    result['phi_NH3'] = result['phi'] * result['NH3_ratio']
    
    result['log_phi'] = np.log10(result['phi'] + 0.1)
    result['log_NH3'] = np.log10(result['NH3_ratio'] + 0.01)
    
    result['inv_P'] = 1.0 / result['P_bar']
    
    return result


def get_feature_cols() -> list:
    """特征列名"""
    base_features = [
        'T_inv', 'logP', 'phi', 'NH3_ratio', 'C7_ratio',
        'T_inv_phi', 'logP_phi'
    ]
    
    auto_features = [
        'T_inv_sq', 'logP_sq', 'phi_sq', 'NH3_ratio_sq', 'C7_ratio_sq',
        'T_inv_logP', 'T_inv_NH3', 'T_inv_C7', 'logP_NH3', 'phi_NH3',
        'log_phi', 'log_NH3', 'inv_P'
    ]
    
    return LOG_A_COLS + base_features + auto_features


def split_data(
    df: pd.DataFrame,
    target_col: str,
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    random_state: int,
    group_col: str = 'variant_id'
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    分割训练/验证/测试集（按variant_id分组，防止数据泄露）
    
    修复: 使用GroupShuffleSplit确保同一variant的所有工况在同一集合
    """
    
    # 第一次分割：train+val vs test（按variant_id分组）
    gss = GroupShuffleSplit(n_splits=1, test_size=test_ratio, random_state=random_state)
    train_val_idx, test_idx = next(gss.split(df, groups=df[group_col]))
    
    train_val = df.iloc[train_val_idx].reset_index(drop=True)
    test = df.iloc[test_idx].reset_index(drop=True)
    
    # 第二次分割：train vs val（按variant_id分组）
    val_ratio_adjusted = val_ratio / (train_ratio + val_ratio)
    gss2 = GroupShuffleSplit(n_splits=1, test_size=val_ratio_adjusted, random_state=random_state)
    train_idx, val_idx = next(gss2.split(train_val, groups=train_val[group_col]))
    
    train = train_val.iloc[train_idx].reset_index(drop=True)
    val = train_val.iloc[val_idx].reset_index(drop=True)
    
    # 统计variant分布
    train_variants = train[group_col].nunique()
    val_variants = val[group_col].nunique()
    test_variants = test[group_col].nunique()
    
    logger.info(f"  训练集: {len(train)} ({train_variants} variants)")
    logger.info(f"  验证集: {len(val)} ({val_variants} variants)")
    logger.info(f"  测试集: {len(test)} ({test_variants} variants)")
    
    # 验证无variant泄露
    train_variant_set = set(train[group_col].unique())
    val_variant_set = set(val[group_col].unique())
    test_variant_set = set(test[group_col].unique())
    
    assert len(train_variant_set & val_variant_set) == 0, "训练集和验证集有variant泄露"
    assert len(train_variant_set & test_variant_set) == 0, "训练集和测试集有variant泄露"
    assert len(val_variant_set & test_variant_set) == 0, "验证集和测试集有variant泄露"
    
    return train, val, test


def optimize_hyperparameters(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_val: pd.DataFrame,
    y_val: pd.Series,
    optuna_config: Dict,
    target_name: str = "Model",
    use_cv: bool = True,
    cv_folds: int = 5
) -> Tuple[Dict, float, list]:
    """
    Optuna贝叶斯超参数寻优
    
    参数:
        use_cv: 是否使用5折交叉验证
        cv_folds: 交叉验证折数
    
    返回: (best_params, best_value, history)
    """
    param_space = optuna_config.get('param_space', {})
    n_trials = optuna_config.get('n_trials', 100)
    
    if use_cv:
        logger.info(f"开始{target_name} Optuna超参数寻优 ({n_trials}轮, {cv_folds}折交叉验证)...")
    else:
        logger.info(f"开始{target_name} Optuna超参数寻优 ({n_trials}轮)...")
    
    def objective(trial):
        # 从config读取参数空间，默认值与config.yaml一致
        params = {
            'max_depth': trial.suggest_int('max_depth', *param_space.get('max_depth', [4, 12])),
            'learning_rate': trial.suggest_float('learning_rate', *param_space.get('learning_rate', [0.01, 0.3])),
            'n_estimators': trial.suggest_int('n_estimators', *param_space.get('n_estimators', [300, 1500])),
            'subsample': trial.suggest_float('subsample', *param_space.get('subsample', [0.6, 0.9])),
            'colsample_bytree': trial.suggest_float('colsample_bytree', *param_space.get('colsample_bytree', [0.6, 0.9])),
            'min_child_weight': trial.suggest_int('min_child_weight', *param_space.get('min_child_weight', [1, 5])),
            'gamma': trial.suggest_float('gamma', *param_space.get('gamma', [0.1, 2])),
            'reg_alpha': trial.suggest_float('reg_alpha', *param_space.get('reg_alpha', [0, 0.5])),
            'reg_lambda': trial.suggest_float('reg_lambda', *param_space.get('reg_lambda', [1, 5])),
        }
        
        if use_cv:
            # 5折交叉验证
            from sklearn.model_selection import KFold
            
            kf = KFold(n_splits=cv_folds, shuffle=True, random_state=42)
            cv_scores = []
            
            for train_idx, val_idx in kf.split(X_train):
                X_tr = X_train.iloc[train_idx].values
                X_vl = X_train.iloc[val_idx].values
                y_tr = y_train.iloc[train_idx].values
                y_vl = y_train.iloc[val_idx].values
                
                model = xgb.XGBRegressor(
                    objective='reg:squarederror',
                    random_state=42,
                    n_jobs=-1,
                    **params
                )
                
                model.fit(X_tr, y_tr, verbose=False)
                y_pred = model.predict(X_vl)
                rmse = np.sqrt(np.mean((y_pred - y_vl) ** 2))
                cv_scores.append(rmse)
            
            rmse = np.mean(cv_scores)
        else:
            # 单次验证
            model = xgb.XGBRegressor(
                objective='reg:squarederror',
                random_state=42,
                n_jobs=-1,
                early_stopping_rounds=optuna_config.get('early_stopping', 50),
                **params
            )
            
            model.fit(
                X_train, y_train,
                eval_set=[(X_val, y_val)],
                verbose=False
            )
            
            y_pred = model.predict(X_val)
            rmse = np.sqrt(np.mean((y_pred - y_val) ** 2))
        
        return rmse
    
    sampler = TPESampler(seed=42)
    study = optuna.create_study(
        direction=optuna_config.get('direction', 'minimize'),
        sampler=sampler
    )
    
    timeout = optuna_config.get('timeout', None)
    n_jobs = optuna_config.get('n_jobs', 1)
    
    study.optimize(objective, n_trials=n_trials, timeout=timeout, n_jobs=n_jobs, show_progress_bar=True)
    
    # 导出寻优历史
    history = []
    for trial in study.trials:
        history.append({
            'number': trial.number,
            'value': trial.value if trial.value is not None else float('inf'),
            'params': trial.params,
            'state': trial.state.name
        })
    
    logger.info(f"{target_name} 最优RMSE: {study.best_value:.6f}")
    logger.info(f"{target_name} 最优参数: {study.best_params}")
    
    return study.best_params, study.best_value, history


def train_model(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_val: pd.DataFrame,
    y_val: pd.Series,
    params: Dict,
    target_name: str = "Model"
) -> xgb.XGBRegressor:
    """训练XGBoost模型"""
    
    model = xgb.XGBRegressor(
        objective='reg:squarederror',
        random_state=42,
        n_jobs=-1,
        **params
    )
    
    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],
        verbose=50
    )
    
    return model


def evaluate_comprehensive(
    model: xgb.XGBRegressor,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    name: str = "Model"
) -> Dict:
    """综合模型评估"""
    
    y_pred = model.predict(X_test)
    
    # 基础指标
    mse = np.mean((y_pred - y_test) ** 2)
    rmse = np.sqrt(mse)
    mae = np.mean(np.abs(y_pred - y_test))
    
    # R²
    ss_res = np.sum((y_test - y_pred) ** 2)
    ss_tot = np.sum((y_test - y_test.mean()) ** 2)
    r2 = 1 - (ss_res / ss_tot) if ss_tot > 0 else 0
    
    # MAPE
    mask = y_test != 0
    if mask.any():
        mape = np.mean(np.abs((y_test[mask] - y_pred[mask]) / y_test[mask])) * 100
    else:
        mape = np.nan
    
    # Bias
    bias = np.mean(y_pred - y_test)
    
    # 相关系数
    pearson_r, _ = pearsonr(y_test, y_pred)
    kendall_tau_val, _ = kendalltau(y_test, y_pred)
    
    metrics = {
        'RMSE': float(rmse),
        'MAE': float(mae),
        'R2': float(r2),
        'MAPE': float(mape) if not np.isnan(mape) else None,
        'Bias': float(bias),
        'Pearson_r': float(pearson_r),
        'Kendall_tau': float(kendall_tau_val),
    }
    
    logger.info(f"{name} 测试集评估:")
    for k, v in metrics.items():
        if v is not None:
            logger.info(f"  {k}: {v:.6f}")
        else:
            logger.info(f"  {k}: N/A")
    
    return metrics, y_pred


def compute_learning_curve(
    model: xgb.XGBRegressor,
    X: pd.DataFrame,
    y: pd.Series,
    output_path: str,
    name: str = "Model"
) -> pd.DataFrame:
    """计算学习曲线"""
    logger.info(f"计算{name}学习曲线...")
    
    train_sizes = np.linspace(0.1, 1.0, 10)
    
    # 移除 early_stopping_rounds 参数（learning_curve 会重新训练模型）
    model_params = model.get_params()
    model_params.pop('early_stopping_rounds', None)
    model_for_lc = xgb.XGBRegressor(**model_params)
    
    train_sizes_abs, train_scores, val_scores = learning_curve(
        model_for_lc, X, y,
        train_sizes=train_sizes,
        cv=5,
        scoring='neg_root_mean_squared_error',
        n_jobs=-1
    )
    
    train_scores = -train_scores
    val_scores = -val_scores
    
    result = pd.DataFrame({
        'train_size': train_sizes_abs,
        'train_mean': train_scores.mean(axis=1),
        'train_std': train_scores.std(axis=1),
        'val_mean': val_scores.mean(axis=1),
        'val_std': val_scores.std(axis=1)
    })
    
    # 绘制学习曲线图
    fig, ax = plt.subplots(figsize=(10, 6))
    ax.fill_between(train_sizes_abs, 
                   result['train_mean'] - result['train_std'],
                   result['train_mean'] + result['train_std'], alpha=0.1, color='blue')
    ax.fill_between(train_sizes_abs,
                   result['val_mean'] - result['val_std'],
                   result['val_mean'] + result['val_std'], alpha=0.1, color='orange')
    ax.plot(train_sizes_abs, result['train_mean'], 'o-', color='blue', label='Training Score')
    ax.plot(train_sizes_abs, result['val_mean'], 'o-', color='orange', label='Validation Score')
    ax.set_xlabel('Training Examples')
    ax.set_ylabel('RMSE')
    ax.set_title(f'{name} Learning Curve')
    ax.legend(loc='best')
    ax.grid(True)
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    
    logger.info(f"学习曲线已保存: {output_path}")
    
    return result


def generate_parity_plot(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    output_path: str,
    name: str = "Model"
) -> pd.DataFrame:
    """生成Parity Plot"""
    logger.info(f"生成{name} Parity Plot...")
    
    # 计算相对误差
    rel_error = (y_pred - y_true) / y_true * 100
    
    result = pd.DataFrame({
        'y_true': y_true,
        'y_pred': y_pred,
        'error': y_pred - y_true,
        'relative_error': rel_error
    })
    
    # 绘制Parity Plot
    fig, ax = plt.subplots(figsize=(8, 8))
    
    min_val = min(y_true.min(), y_pred.min())
    max_val = max(y_true.max(), y_pred.max())
    margin = (max_val - min_val) * 0.1
    
    # 绘制数据点
    ax.scatter(y_true, y_pred, alpha=0.5, s=20, c='blue', label='Predictions')
    
    # 绘制完美预测线
    ax.plot([min_val - margin, max_val + margin], 
            [min_val - margin, max_val + margin], 
            'k--', linewidth=1.5, label='Perfect Prediction')
    
    # 绘制误差线（log10空间中的相对误差）
    # ±15%相对误差: log10(1.15) ≈ 0.061
    # ±30%相对误差: log10(1.30) ≈ 0.114
    error_margin_15 = np.log10(1.15)  # ≈ 0.061
    error_margin_30 = np.log10(1.30)  # ≈ 0.114
    
    ax.plot([min_val - margin, max_val + margin],
            [min_val - margin + error_margin_15, max_val + margin + error_margin_15],
            'r-.', linewidth=1, alpha=0.7, label='±15%')
    ax.plot([min_val - margin, max_val + margin],
            [min_val - margin - error_margin_15, max_val + margin - error_margin_15],
            'r-.', linewidth=1, alpha=0.7)
    ax.plot([min_val - margin, max_val + margin],
            [min_val - margin + error_margin_30, max_val + margin + error_margin_30],
            'g-.', linewidth=1, alpha=0.7, label='±30%')
    ax.plot([min_val - margin, max_val + margin],
            [min_val - margin - error_margin_30, max_val + margin - error_margin_30],
            'g-.', linewidth=1, alpha=0.7)
    
    ax.set_xlabel('True Value')
    ax.set_ylabel('Predicted Value')
    ax.set_title(f'{name} Parity Plot')
    ax.legend(loc='upper left')
    ax.set_xlim(min_val - margin, max_val + margin)
    ax.set_ylim(min_val - margin, max_val + margin)
    ax.set_aspect('equal', adjustable='box')
    ax.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    
    logger.info(f"Parity Plot已保存: {output_path}")
    
    return result


def compute_feature_importance(
    model: xgb.XGBRegressor,
    feature_names: list,
    output_path: str,
    name: str = "Model"
) -> pd.DataFrame:
    """计算特征重要性"""
    logger.info(f"计算{name}特征重要性...")
    
    importance = model.feature_importances_
    
    result = pd.DataFrame({
        'feature': feature_names,
        'importance': importance
    }).sort_values('importance', ascending=False)
    
    # 绘制特征重要性图
    fig, ax = plt.subplots(figsize=(12, 8))
    n_show = min(20, len(result))
    top_features = result.head(n_show)
    
    ax.barh(range(n_show), top_features['importance'].values[::-1])
    ax.set_yticks(range(n_show))
    ax.set_yticklabels(top_features['feature'].values[::-1])
    ax.set_xlabel('Importance')
    ax.set_title(f'{name} Feature Importance (Top {n_show})')
    ax.grid(True, alpha=0.3, axis='x')
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150)
    plt.close()
    
    logger.info(f"特征重要性图已保存: {output_path}")
    
    return result


def train_target_model(
    target: str,
    config: Dict,
    use_optuna: bool = True,
    n_trials: int = 100,
    output_dir: str = None
):
    """训练目标模型 (IDT或LFS)"""
    
    xgboost_config = config['xgboost']
    split_config = xgboost_config['data_split']
    optuna_config = xgboost_config.get('optuna', {}).copy()  # 复制避免修改原config
    eval_config = xgboost_config.get('evaluation', {})
    
    # 确保n_trials参数被正确设置（函数参数优先）
    if n_trials is not None:
        optuna_config['n_trials'] = n_trials
    
    # 确定输出目录
    if output_dir is None:
        output_dir = xgboost_config['output']['models_dir']
    target_dir = os.path.join(output_dir, target)
    os.makedirs(target_dir, exist_ok=True)
    
    logger.info("=" * 60)
    logger.info(f"开始训练 {target.upper()} 模型")
    logger.info("=" * 60)
    
    # 加载数据
    if target == 'idt':
        df = load_idt_data()
        df = transform_idt_features(df)
        df = df.dropna(subset=['log10_tau'])
        target_col = 'log10_tau'
        target_name = 'IDT'
    else:
        df = load_lfs_data()
        df = transform_lfs_features(df)
        df = df.dropna(subset=['log10_SL'])
        target_col = 'log10_SL'
        target_name = 'LFS'
    
    logger.info(f"有效数据: {len(df)} 条")
    
    feature_cols = get_feature_cols()
    
    # 分割数据
    train, val, test = split_data(
        df, target_col,
        split_config['train_ratio'],
        split_config['val_ratio'],
        split_config['test_ratio'],
        split_config['random_state']
    )
    
    X_train = train[feature_cols]
    y_train = train[target_col]
    X_val = val[feature_cols]
    y_val = val[target_col]
    X_test = test[feature_cols]
    y_test = test[target_col]
    
    # ========== 样本加权 (仅IDT模型) ==========
    # 对高IDT区域样本增加权重，改善稀疏区域预测
    # 注意: log10_tau = log10(tau_ign_us * 1e-6) = log10(tau_ign_us) - 6
    # 所以 log10_tau > -2 等价于原始 log10(tau_ign_us) > 4
    sample_weights = None
    if target == 'idt':
        # 基于log10_tau加权 (log10_tau = log10(tau_ign_us) - 6)
        # 高IDT区域 (原始 log10(tau_ign_us) > 4, 即 log10_tau > -2) 权重翻倍
        train_weights = np.where(train[target_col] > -2, 2.0, 1.0)
        val_weights = np.where(val[target_col] > -2, 2.0, 1.0)
        sample_weights = np.concatenate([train_weights, val_weights])
        
        high_idt_count = (train[target_col] > -2).sum() + (val[target_col] > -2).sum()
        logger.info(f"样本加权: 高IDT区域(log10_tau>-2, 即原始>10^4us) {high_idt_count}个样本权重翻倍")
    # 对于CV寻优，使用train+val合并数据
    X_train_full = pd.concat([train, val])[feature_cols]
    y_train_full = pd.concat([train[target_col], val[target_col]]).reset_index(drop=True)
    
    # 超参数寻优 (使用5折交叉验证)
    if use_optuna:
        best_params, best_rmse, history = optimize_hyperparameters(
            X_train_full, y_train_full, X_val, y_val,
            optuna_config, target_name,
            use_cv=True, cv_folds=5
        )
        
        # 保存寻优历史
        study_df = pd.DataFrame(history)
        study_path = os.path.join(target_dir, 'optuna_study.csv')
        study_df.to_csv(study_path, index=False)
        logger.info(f"寻优历史已保存: {study_path}")
        
        # 保存最优参数（包含early_stopping_rounds）
        best_params_path = os.path.join(target_dir, 'best_params.json')
        best_params_to_save = best_params.copy()
        best_params_to_save['early_stopping_rounds'] = optuna_config.get('early_stopping', 50)
        with open(best_params_path, 'w') as f:
            json.dump(best_params_to_save, f, indent=2)
        logger.info(f"最优参数已保存: {best_params_path}")
        
        # 使用最优参数训练
        model_params = xgboost_config.get(target, {}).copy()
        model_params.update(best_params)
        model_params['early_stopping_rounds'] = optuna_config.get('early_stopping', 50)
    else:
        model_params = xgboost_config.get(target, {})
        best_rmse = None
    
    # 训练最终模型（使用train+val全部数据，不再分割验证集）
    # 修复P0-1: 避免数据泄露 - CV已选定最优超参数，最终训练无需验证集
    logger.info(f"训练{target_name}模型（使用全部训练数据，无验证集）...")
    X_train_full = pd.concat([X_train, X_val])
    y_train_full = pd.concat([y_train, y_val])
    
    # 移除early_stopping_rounds，因为不再使用验证集
    model_params_final = model_params.copy()
    model_params_final.pop('early_stopping_rounds', None)
    
    model = xgb.XGBRegressor(
        objective='reg:squarederror',
        random_state=42,
        n_jobs=-1,
        **model_params_final
    )
    
    # 使用样本权重训练（如果有）
    if sample_weights is not None:
        logger.info("使用样本加权训练...")
        model.fit(X_train_full, y_train_full, sample_weight=sample_weights, verbose=50)
    else:
        model.fit(X_train_full, y_train_full, verbose=50)
    
    # 保存模型
    model_path = os.path.join(target_dir, 'model.json')
    model.save_model(model_path)
    logger.info(f"模型已保存: {model_path}")
    
    # 保存特征列表
    feature_list_path = os.path.join(target_dir, 'feature_list.json')
    with open(feature_list_path, 'w') as f:
        json.dump(feature_cols, f, indent=2)
    logger.info(f"特征列表已保存: {feature_list_path}")
    
    # 综合评估
    logger.info("=" * 60)
    logger.info("测试集评估")
    metrics, y_pred = evaluate_comprehensive(model, X_test, y_test, target_name)
    
    # 保存评估指标
    metrics_path = os.path.join(target_dir, 'metrics.json')
    with open(metrics_path, 'w') as f:
        json.dump(metrics, f, indent=2)
    logger.info(f"评估指标已保存: {metrics_path}")
    
    # Parity Plot
    if eval_config.get('compute_parity', True):
        parity_data = generate_parity_plot(
            y_test.values, y_pred,
            os.path.join(target_dir, 'parity.png'),
            target_name
        )
        parity_path = os.path.join(target_dir, 'parity_data.csv')
        parity_data.to_csv(parity_path, index=False)
        logger.info(f"Parity数据已保存: {parity_path}")
    
    # 学习曲线
    if eval_config.get('compute_learning_curve', True):
        learning_curve_data = compute_learning_curve(
            model, 
            pd.concat([X_train, X_val]).reset_index(drop=True),
            pd.concat([y_train, y_val]).reset_index(drop=True),
            os.path.join(target_dir, 'learning_curve.png'),
            target_name
        )
        lc_path = os.path.join(target_dir, 'learning_curve.csv')
        learning_curve_data.to_csv(lc_path, index=False)
        logger.info(f"学习曲线数据已保存: {lc_path}")
    
    # 特征重要性
    if eval_config.get('compute_feature_importance', True):
        importance_data = compute_feature_importance(
            model, feature_cols,
            os.path.join(target_dir, 'feature_importance.png'),
            target_name
        )
        fi_path = os.path.join(target_dir, 'feature_importance.csv')
        importance_data.to_csv(fi_path, index=False)
        logger.info(f"特征重要性数据已保存: {fi_path}")
    
    logger.info("=" * 60)
    logger.info(f"{target_name}模型训练完成!")
    logger.info("=" * 60)
    
    return metrics


def load_trained_model(model_dir: str, target: str) -> Tuple[xgb.XGBRegressor, list, Dict]:
    """
    加载训练好的模型
    
    参数:
        model_dir: 模型目录路径 (如 output/models)
        target: 'idt' 或 'lfs'
    
    返回:
        model: XGBoost模型
        feature_cols: 特征列表
        params: 模型参数
    """
    target_dir = os.path.join(model_dir, target)
    model_path = os.path.join(target_dir, 'model.json')
    params_path = os.path.join(target_dir, 'best_params.json')
    
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"模型文件不存在: {model_path}")
    
    model = xgb.XGBRegressor()
    model.load_model(model_path)
    
    feature_cols = get_feature_cols()
    
    params = {}
    if os.path.exists(params_path):
        with open(params_path, 'r') as f:
            params = json.load(f)
    
    logger.info(f"已加载模型: {model_path}")
    return model, feature_cols, params


def prepare_features(conditions: Dict) -> np.ndarray:
    """
    根据工况条件准备特征向量
    
    参数:
        conditions: 包含以下键的字典:
            - T: 温度 (K)
            - P_bar: 压力
            - phi: 当量比
            - X_NH3, X_H2, X_C7: 组分摩尔分数
            - logA_1 ~ logA_20: 20个反应的logA值
    
    返回:
        features: 特征向量 (1 x 40)
    """
    T = conditions['T']
    P_bar = conditions['P_bar']
    phi = conditions['phi']
    X_NH3 = conditions.get('X_NH3', 0)
    X_H2 = conditions.get('X_H2', 0)
    X_C7 = conditions.get('X_C7', 0)
    
    logA_values = [conditions.get(f'logA_{i}', 0) for i in range(1, 21)]
    
    T_inv = 1000.0 / T
    logP = np.log10(P_bar)
    
    total_fuel = X_NH3 + X_H2
    NH3_ratio = X_NH3 / total_fuel if total_fuel > 0 else 0.0
    C7_ratio = X_C7
    
    T_inv_phi = T_inv * phi
    logP_phi = logP * phi
    
    T_inv_sq = T_inv ** 2
    logP_sq = logP ** 2
    phi_sq = phi ** 2
    NH3_ratio_sq = NH3_ratio ** 2
    C7_ratio_sq = C7_ratio ** 2
    
    T_inv_logP = T_inv * logP
    T_inv_NH3 = T_inv * NH3_ratio
    T_inv_C7 = T_inv * C7_ratio
    logP_NH3 = logP * NH3_ratio
    phi_NH3 = phi * NH3_ratio
    
    log_phi = np.log10(phi + 0.1)
    log_NH3 = np.log10(NH3_ratio + 0.01)
    inv_P = 1.0 / P_bar
    
    features = np.array([
        *logA_values,
        T_inv, logP, phi, NH3_ratio, C7_ratio,
        T_inv_phi, logP_phi,
        T_inv_sq, logP_sq, phi_sq, NH3_ratio_sq, C7_ratio_sq,
        T_inv_logP, T_inv_NH3, T_inv_C7, logP_NH3, phi_NH3,
        log_phi, log_NH3, inv_P
    ]).reshape(1, -1)
    
    return features


def predict_idt(model: xgb.XGBRegressor, conditions: Dict) -> float:
    """
    预测点火延迟时间
    
    参数:
        model: 训练好的IDT模型
        conditions: 工况条件字典
    
    返回:
        tau_ign: 预测的点火延迟时间 (秒)
    """
    features = prepare_features(conditions)
    log10_tau = model.predict(features)[0]
    tau_ign = 10 ** log10_tau
    return tau_ign


def predict_lfs(model: xgb.XGBRegressor, conditions: Dict) -> float:
    """
    预测层流火焰速度
    
    参数:
        model: 训练好的LFS模型
        conditions: 工况条件字典
    
    返回:
        S_L: 预测的层流火焰速度 (m/s)
    """
    features = prepare_features(conditions)
    log10_SL = model.predict(features)[0]
    S_L = 10 ** log10_SL
    return S_L


def main():
    parser = argparse.ArgumentParser(description='Train XGBoost surrogate models')
    parser.add_argument('-c', '--config', default='config/config.yaml', help='Config file path')
    parser.add_argument('--target', choices=['idt', 'lfs', 'all'], default='all',
                       help='Target model: idt, lfs, or all')
    parser.add_argument('--no-optuna', action='store_true',
                       help='Skip Optuna optimization, use config params')
    parser.add_argument('--n-trials', type=int, default=100,
                       help='Number of Optuna trials')
    parser.add_argument('--output-dir', default=None,
                       help='Output directory for models')
    args = parser.parse_args()
    
    config = load_config_with_override(args.config)
    
    # 设置optuna轮数 (命令行参数优先，否则使用config.yaml中的值)
    if 'optuna' not in config['xgboost']:
        config['xgboost']['optuna'] = {}
    if args.n_trials != 100:  # 用户在命令行指定了非默认值
        config['xgboost']['optuna']['n_trials'] = args.n_trials
    # 否则保留config.yaml中的值
    
    if args.target in ['idt', 'all']:
        train_target_model('idt', config, 
                         use_optuna=not args.no_optuna,
                         n_trials=args.n_trials,
                         output_dir=args.output_dir)
    
    if args.target in ['lfs', 'all']:
        train_target_model('lfs', config,
                         use_optuna=not args.no_optuna,
                         n_trials=args.n_trials,
                         output_dir=args.output_dir)


if __name__ == "__main__":
    main()
