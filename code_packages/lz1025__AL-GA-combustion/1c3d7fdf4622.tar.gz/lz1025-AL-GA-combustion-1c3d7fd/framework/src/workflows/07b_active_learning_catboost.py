# =============================================================================
# src/workflows/07b_active_learning_catboost.py
# =============================================================================
# 工作流步骤 7b: 主动学习驱动的遗传算法优化（CatBoost版本）
# =============================================================================
#
# 功能：
#   - 使用CatBoost代理模型进行快速优化
#   - 自动寻找最优A因子组合
#
# CatBoost优势：
#   - 有序提升(Ordered Boosting): 减少过拟合
#   - 对称树(Symmetric Trees): 推理更快，GA评估加速
#   - 增量训练: init_model参数更稳定
#   - 样本加权: 延续高IDT区域加权策略
#
# 核心函数：
#   - run_active_learning(): 主动学习主循环
#   - cross_validate_lambda(): λ交叉验证
#   - check_and_train_models(): 检查并训练模型
#
# 目标函数（统一对数空间MSE）：
#   - IDT: ε_IDT = (1/N) Σ (log10(τ_sim/s) - log10(τ_ref/s))²
#   - LFS: ε_LFS = (1/N) Σ (log10(S_sim/m/s) - log10(S_ref/m/s))²
#   - 总目标: J(x) = α·ε_IDT + (1-α)·ε_LFS + λ||x - x_base||²
#
# 误差指标说明（v5统一使用log空间）：
#   [GA优化] 使用 Log-MSE (对数空间均方误差)
#     - 适用于跨越多个数量级的IDT/LFS数据
#     - 确保大误差和小误差得到公平惩罚
#   [Cantera验证] 使用 Log空间最大误差 (v5改进)
#     - Max Log Error = max(|log10(pred) - log10(true)|)
#     - 对称性：预测偏高/偏低同等对待
#     - 跨数量级公平：适用于IDT跨越3-4个数量级
#   阈值对应关系：
#     - 0.06 ≈ 15% 线性误差 (10^0.06 ≈ 1.15)
#     - 0.13 ≈ 35% 线性误差 (10^0.13 ≈ 1.35)
#     - 0.20 ≈ 58% 线性误差 (10^0.20 ≈ 1.58)
#
#   - output/models/idt_catboost/model.cbm: IDT代理模型
#   - output/models/lfs_catboost/model.cbm: LFS代理模型
#   - data/ground_truth/idt_det_reference.csv: IDT Ground Truth
#   - data/ground_truth/lfs_exp_reference.csv: LFS Ground Truth
#   - data/logA_base.npy: 基线logA值
#   - 02-Reduced-Wang_fuel_2023.yaml: 机理文件
#
# 输出文件：
#   - output/active_learning/active_learning_results_TIMESTAMP.json
#
# 使用方法：
#   python src/workflows/07b_active_learning_catboost.py -c config/ga_config.yaml
#   python src/workflows/07b_active_learning_catboost.py --skip-lfs    # 跳过LFS验证
#   python src/workflows/07b_active_learning_catboost.py --idt-only    # 仅IDT模式
#   python src/workflows/07b_active_learning_catboost.py --alpha 0.9   # 调整IDT权重
#
# =============================================================================
# -*- coding: utf-8 -*-

import os
import sys
import json
import yaml
import logging
import argparse
import time
from datetime import datetime
from typing import Dict, List, Any, Tuple, Optional

import numpy as np
import pandas as pd
import catboost as cb
from catboost import CatBoostRegressor, Pool

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.core.objective import (
    load_surrogate_models, load_feature_lists, load_ground_truth,
    build_features_batch, predict_idt, predict_lfs, compute_objective
)
from src.core.ga_optimizer import (
    create_bounds, setup_toolbox, run_ga_with_callback,
    create_evaluation_function
)
from src.core.cantera_validator import (
    validate_candidate, compute_validation_error
)
from src.core.afactor_manager import AFactorManager, load_reactions_with_validation
from src.core.model_retrainer import (
create_infill_samples,
create_enhanced_infill_samples,  # Enhanced infill strategy (Proposal D)
create_targeted_infill_samples,  # Phase 1: Targeted infill for max error (Proposal B)
create_targeted_infill_samples_with_cantera,  # NEW: Uses Cantera for correct target values
prepare_idt_training_data, prepare_lfs_training_data,
merge_training_data,
retrain_catboost, retrain_catboost_with_fallback
)
from src.core.mechanism_writer import MechanismWriter


# =============================================================================
# 日志配置
# =============================================================================
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    encoding='utf-8'
)
logger = logging.getLogger(__name__)


# =============================================================================
# 辅助函数
# =============================================================================

def load_config(config_path: str) -> Dict[str, Any]:
    """加载配置文件"""
    with open(config_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def check_and_train_catboost_models(config: Dict[str, Any]) -> Tuple[bool, bool]:
    """
    检查CatBoost模型是否存在，返回可用状态
    
    Returns:
        (idt_available, lfs_available): IDT和LFS模型的可用状态
    """
    models_cfg = config.get('models', {})
    
    idt_model_path = models_cfg.get('idt_model', 'output/models/idt_catboost/model.cbm')
    lfs_model_path = models_cfg.get('lfs_model', 'output/models/lfs_catboost/model.cbm')
    
    idt_available = os.path.exists(idt_model_path)
    lfs_available = os.path.exists(lfs_model_path)
    
    logger.info(f"模型检查:")
    logger.info(f"  IDT模型: {idt_model_path} ({'存在' if idt_available else '不存在'})")
    logger.info(f"  LFS模型: {lfs_model_path} ({'存在' if lfs_available else '不存在'})")
    
    if not idt_available:
        logger.warning(f"IDT模型不存在: {idt_model_path}")
        logger.warning("请先运行: python src/workflows/04c_train_catboost.py --target all")
    
    return idt_available, lfs_available


def check_surrogate_health(
    idt_model: CatBoostRegressor,
    lfs_model: CatBoostRegressor,
    idt_conditions: pd.DataFrame,
    lfs_conditions: pd.DataFrame,
    idt_reference: np.ndarray,
    lfs_reference: np.ndarray,
    idt_features: List[str],
    lfs_features: List[str],
    logA_base: np.ndarray,
    check_nan: bool = True,
    check_range: bool = True,
    check_variance: bool = True,
    check_correlation: bool = True,
    min_correlation: float = 0.0,
    expected_idt_range: tuple = (-10, 5),  # log10(seconds)
    expected_lfs_range: tuple = (-2, 2),   # log10(m/s)
    logger_instance: logging.Logger = None
) -> Tuple[bool, Dict[str, Any]]:
    """
    Check surrogate model prediction health before GA optimization.

    v5: Added to detect model collapse before GA runs.

    This function validates:
    1. NaN/Inf predictions - model should not produce invalid values
    2. Prediction range - predictions should be within expected bounds
    3. Prediction variance - model should not collapse to constant output
    4. Correlation with reference - predictions should positively correlate

    Parameters:
        idt_model, lfs_model: Trained surrogate models
        idt_conditions, lfs_conditions: Condition DataFrames
        idt_reference, lfs_reference: Ground truth values
        idt_features, lfs_features: Feature name lists
        logA_base: Baseline logA values
        check_nan: Check for NaN/Inf predictions
        check_range: Check prediction range bounds
        check_variance: Check for zero variance (collapsed model)
        check_correlation: Check correlation with reference
        min_correlation: Minimum acceptable correlation
        expected_idt_range: Expected IDT prediction range (log10(s))
        expected_lfs_range: Expected LFS prediction range (log10(m/s))
        logger_instance: Logger instance (uses module logger if None)

    Returns:
        (is_healthy, details): Health status and detailed validation results
    """
    if logger_instance is None:
        logger_instance = logger

    details = {
        'is_healthy': True,
        'errors': [],
        'warnings': [],
        'idt': {},
        'lfs': {}
    }

    # Build features for baseline
    idt_feat = build_features_batch(logA_base, idt_conditions, idt_features)
    idt_pred = idt_model.predict(idt_feat)

    # IDT Checks
    # 1. NaN/Inf check
    if check_nan:
        idt_nan_count = (~np.isfinite(idt_pred)).sum()
        details['idt']['nan_count'] = int(idt_nan_count)
        if idt_nan_count > 0:
            details['is_healthy'] = False
            details['errors'].append(f"IDT model produces {idt_nan_count} NaN/Inf predictions")

    # 2. Range check
    if check_range:
        idt_min, idt_max = float(idt_pred.min()), float(idt_pred.max())
        details['idt']['pred_range'] = (idt_min, idt_max)
        if idt_min < expected_idt_range[0] or idt_max > expected_idt_range[1]:
            details['warnings'].append(
                f"IDT prediction range [{idt_min:.1f}, {idt_max:.1f}] "
                f"outside expected {expected_idt_range}"
            )

    # 3. Variance check
    if check_variance:
        idt_std = float(np.std(idt_pred))
        details['idt']['std'] = idt_std
        if idt_std < 0.01:
            details['is_healthy'] = False
            details['errors'].append(
                f"IDT model has near-zero variance (std={idt_std:.4f}) - collapsed!"
            )

    # 4. Correlation check
    if check_correlation and len(idt_reference) > 0:
        log_ref = np.log10(np.maximum(idt_reference, 1e-30))
        idt_corr = float(np.corrcoef(idt_pred, log_ref)[0, 1])
        details['idt']['correlation'] = idt_corr
        if not np.isfinite(idt_corr):
            details['warnings'].append("IDT correlation could not be computed")
        elif idt_corr < min_correlation:
            details['warnings'].append(
                f"IDT correlation ({idt_corr:.3f}) below threshold ({min_correlation})"
            )

    # LFS Checks (if model available)
    if lfs_model is not None:
        lfs_feat = build_features_batch(logA_base, lfs_conditions, lfs_features)
        lfs_pred = lfs_model.predict(lfs_feat)

        # 1. NaN/Inf check
        if check_nan:
            lfs_nan_count = (~np.isfinite(lfs_pred)).sum()
            details['lfs']['nan_count'] = int(lfs_nan_count)
            if lfs_nan_count > 0:
                details['is_healthy'] = False
                details['errors'].append(f"LFS model produces {lfs_nan_count} NaN/Inf predictions")

        # 2. Range check
        if check_range:
            lfs_min, lfs_max = float(lfs_pred.min()), float(lfs_pred.max())
            details['lfs']['pred_range'] = (lfs_min, lfs_max)
            if lfs_min < expected_lfs_range[0] or lfs_max > expected_lfs_range[1]:
                details['warnings'].append(
                    f"LFS prediction range [{lfs_min:.1f}, {lfs_max:.1f}] "
                    f"outside expected {expected_lfs_range}"
                )

        # 3. Variance check
        if check_variance:
            lfs_std = float(np.std(lfs_pred))
            details['lfs']['std'] = lfs_std
            if lfs_std < 0.01:
                details['is_healthy'] = False
                details['errors'].append(
                    f"LFS model has near-zero variance (std={lfs_std:.4f}) - collapsed!"
                )

        # 4. Correlation check
        if check_correlation and len(lfs_reference) > 0:
            log_ref = np.log10(np.maximum(lfs_reference, 1e-30))
            lfs_corr = float(np.corrcoef(lfs_pred, log_ref)[0, 1])
            details['lfs']['correlation'] = lfs_corr
            if not np.isfinite(lfs_corr):
                details['warnings'].append("LFS correlation could not be computed")
            elif lfs_corr < min_correlation:
                details['warnings'].append(
                    f"LFS correlation ({lfs_corr:.3f}) below threshold ({min_correlation})"
                )

    # Log results
    if details['is_healthy']:
        logger_instance.info("✓ Surrogate health check passed")
        if details['warnings']:
            for w in details['warnings']:
                logger_instance.warning(f"  Warning: {w}")
    else:
        logger_instance.error("✗ Surrogate health check FAILED")
        for e in details['errors']:
            logger_instance.error(f"  Error: {e}")
        for w in details['warnings']:
            logger_instance.warning(f"  Warning: {w}")

    return details['is_healthy'], details


def check_surrogate_validation_gap(
    surrogate_pred: np.ndarray,
    cantera_true: np.ndarray,
    target_type: str = 'idt',
    gap_threshold: float = 0.15,
    correlation_threshold: float = 0.5,
    logger_instance: logging.Logger = None
) -> Tuple[bool, Dict[str, Any]]:
    """
    检测代理模型预测与Cantera验证之间的偏差（v7新增）

    当偏差过大或相关性过低时，表明代理模型在错误区域过度拟合，
    需要触发全量训练重置来纠正偏差。

    Parameters:
        surrogate_pred: 代理模型预测值（log10空间）
        cantera_true: Cantera计算的真实值（线性空间，会转换为log10）
        target_type: 'idt' 或 'lfs'
        gap_threshold: 最大允许的对数空间偏差
        correlation_threshold: 最小允许的相关性
        logger_instance: Logger实例

    Returns:
        (is_valid, details): 偏差检测结果
    """
    if logger_instance is None:
        logger_instance = logger

    details = {
        'is_valid': True,
        'warnings': [],
        'target_type': target_type,
        'max_gap': None,
        'mean_gap': None,
        'correlation': None
    }

    # 转换为log10空间
    cantera_log = np.log10(np.maximum(cantera_true, 1e-30))

    # 确保数组有效
    valid_mask = np.isfinite(surrogate_pred) & np.isfinite(cantera_log)
    n_valid = valid_mask.sum()

    if n_valid < 5:
        details['is_valid'] = False
        details['warnings'].append(f"有效样本数不足 ({n_valid} < 5)")
        return details['is_valid'], details

    # 计算偏差
    gap = np.abs(surrogate_pred[valid_mask] - cantera_log[valid_mask])
    max_gap = float(np.max(gap))
    mean_gap = float(np.mean(gap))

    details['max_gap'] = max_gap
    details['mean_gap'] = mean_gap

    # 计算相关性
    correlation = float(np.corrcoef(surrogate_pred[valid_mask], cantera_log[valid_mask])[0, 1])
    details['correlation'] = correlation

    # 偏差阈值检测
    if max_gap > gap_threshold:
        details['is_valid'] = False
        details['warnings'].append(f"{target_type}最大偏差 {max_gap:.4f} > 阈值 {gap_threshold:.4f}")

    # 相关性检测（低相关表明代理模型欺骗）
    if not np.isfinite(correlation):
        details['warnings'].append(f"{target_type}相关性无法计算")
    elif correlation < correlation_threshold:
        details['warnings'].append(
            f"{target_type}相关性 {correlation:.3f} < 阈值 {correlation_threshold:.3f}（代理模型可能欺骗）"
        )

    # 日志输出
    if details['is_valid']:
        logger_instance.info(f"偏差检测通过 [{target_type}]: max_gap={max_gap:.4f}, corr={correlation:.3f}")
    else:
        logger_instance.warning(f"偏差检测异常 [{target_type}]: 代理模型可能欺骗")
        for w in details['warnings']:
            logger_instance.warning(f"  {w}")

    return details['is_valid'], details


def save_results(results: Dict, output_dir: str, filename: str):
    """保存结果到JSON文件"""
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False, default=str)
    logger.info(f"结果已保存: {filepath}")


def cross_validate_lambda(idt_model: CatBoostRegressor, lfs_model: CatBoostRegressor,
                          idt_features: List[str], lfs_features: List[str],
                          idt_conditions: pd.DataFrame, lfs_conditions: pd.DataFrame,
                          idt_reference: np.ndarray, lfs_reference: np.ndarray,
                          logA_base: np.ndarray,
                          lambda_candidates: List[float],
                          alpha: float = 0.5,
                          n_folds: int = 5,
                          n_samples_per_fold: int = 20,
                          sampling_range: float = 1.0,
                          idt_only: bool = False) -> float:
    """
    K折交叉验证确定最优正则化系数λ
    """
    logger.info("开始K折交叉验证确定λ...")
    logger.info(f"  K={n_folds}, 每折{n_samples_per_fold}样本, 采样范围±{sampling_range}")
    
    n_dim = len(logA_base)
    n_total = n_folds * n_samples_per_fold
    
    # 生成所有采样点
    np.random.seed(42)
    all_samples = []
    for _ in range(n_total):
        noise = np.random.uniform(-1, 1, n_dim)
        logA_test = logA_base + noise * sampling_range
        all_samples.append(logA_test)
    all_samples = np.array(all_samples)
    
    best_lambda = 0.0
    best_score = float('inf')
    lambda_results = {}
    
    for lam in lambda_candidates:
        fold_scores = []
        
        # K折交叉验证
        for fold in range(n_folds):
            val_start = fold * n_samples_per_fold
            val_end = val_start + n_samples_per_fold
            
            val_indices = list(range(val_start, val_end))
            
            # 计算验证集误差（不含正则化项）
            fold_errors = []
            for idx in val_indices:
                logA_test = all_samples[idx]
                
                result = compute_objective(
                    logA_test, idt_model, lfs_model,
                    idt_features, lfs_features,
                    idt_conditions, lfs_conditions,
                    idt_reference, lfs_reference,
                    lam, logA_base, alpha, 
                    error_type='log_mse', idt_only=idt_only,
                    model_type='catboost',
                    idt_unit='us', lfs_unit='cm/s'
                )
                
                if idt_only:
                    fold_errors.append(result['idt_error'])
                else:
                    fold_errors.append(result['total'] - result['reg_term'])
            
            fold_scores.append(np.mean(fold_errors))
        
        avg_score = np.mean(fold_scores)
        std_score = np.std(fold_scores)
        lambda_results[lam] = avg_score
        
        logger.info(f"  λ={lam}: 平均误差={avg_score:.6f} ± {std_score:.6f}")
        
        if avg_score < best_score:
            best_score = avg_score
            best_lambda = lam
    
    logger.info(f"交叉验证选择: λ={best_lambda}")
    
    return best_lambda




def run_active_learning(config: Dict[str, Any],
                        skip_lfs: bool = False,
                        idt_only: bool = False,
                        alpha: float = None) -> Dict[str, Any]:
    """
    运行主动学习优化循环（CatBoost版本）
    """
    start_time = time.time()
    
    models_cfg = config['models']
    gt_cfg = config['ground_truth']
    mech_cfg = config['mechanism']
    al_cfg = config['active_learning']
    ga_cfg = config['genetic_algorithm']
    lambda_cfg = config['lambda_cv']
    output_cfg = config['output']
    retrain_cfg = config.get('model_retraining', {})
    
    # 将 retrain_cfg 合并到 al_cfg
    if retrain_cfg:
        al_cfg['model_retraining'] = retrain_cfg
    
    # 获取 Cantera 并行进程数
    cantera_workers = config.get('cantera', {}).get('n_workers', 12)
    logger.info(f"Cantera并行进程数: {cantera_workers}")
    
    # 获取 LFS 计算参数
    lfs_cfg = config.get('cantera', {}).get('lfs', {})
    lfs_max_time = lfs_cfg.get('max_time', 1200.0)
    lfs_max_levels = lfs_cfg.get('max_levels', 4)
    lfs_max_time_step_count = lfs_cfg.get('max_time_step_count', 2000)
    
    # 获取alpha参数
    if alpha is not None:
        final_alpha = alpha
    else:
        final_alpha = config.get('objective', {}).get('alpha', 0.5)
    logger.info(f"IDT/LFS权重平衡系数 α = {final_alpha}")
    
    # 获取最大误差惩罚参数
    obj_cfg = config.get('objective', {})
    gamma_idt = obj_cfg.get('gamma_idt', 0.0)
    gamma_lfs = obj_cfg.get('gamma_lfs', 0.0)
    use_max_error_penalty = obj_cfg.get('use_max_error_penalty', False)
    
    if use_max_error_penalty:
        logger.info(f"最大误差惩罚已启用: γ_IDT={gamma_idt}, γ_LFS={gamma_lfs}")
    else:
        logger.info("最大误差惩罚未启用")
    
    
    output_dir = output_cfg['results_dir']
    
    # 创建带时间戳的输出目录
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    catboost_output_dir = os.path.join(
        output_dir,
        f'catboost_results_{timestamp}'
    )
    os.makedirs(catboost_output_dir, exist_ok=True)
    os.makedirs(os.path.join(catboost_output_dir, 'iterations'), exist_ok=True)
    logger.info(f"CatBoost结果输出目录: {catboost_output_dir}")
    os.makedirs(output_dir, exist_ok=True)
    
    logger.info("=" * 60)
    logger.info("检查并训练CatBoost模型...")
    logger.info("=" * 60)
    
    idt_available, lfs_available = check_and_train_catboost_models(config)
    
    logger.info("=" * 60)
    logger.info("加载CatBoost模型和数据...")
    logger.info("=" * 60)
    
    if not idt_available:
        raise FileNotFoundError(f"IDT模型不可用: {models_cfg['idt_model']}")
    
    # 加载CatBoost模型
    # 加载CatBoost模型（带异常处理）
    try:
        idt_model, _ = load_surrogate_models(
            models_cfg['idt_model'], models_cfg['idt_model'],
            model_type='catboost'
        )
    except Exception as e:
        logger.error(f"IDT模型加载失败: {e}")
        raise RuntimeError(f"IDT模型加载失败，请检查模型路径: {models_cfg['idt_model']}")
    idt_features, _ = load_feature_lists(
        models_cfg['idt_feature_list'], models_cfg['idt_feature_list']
    )
    idt_conditions, lfs_conditions = load_ground_truth(
        gt_cfg['idt_reference'], gt_cfg['lfs_reference']
    )
    
    if idt_only or (skip_lfs and not lfs_available):
        logger.info("仅IDT模式：LFS模型未加载")
        lfs_model = None
        lfs_features = idt_features
        lfs_reference = np.ones(len(lfs_conditions))
        use_lfs = False
    elif not lfs_available:
        logger.info("LFS模型不可用，仅使用IDT")
        lfs_model = None
        lfs_features = idt_features
        lfs_reference = np.ones(len(lfs_conditions))
        use_lfs = False
    else:
        try:
            _, lfs_model = load_surrogate_models(
                models_cfg['idt_model'], models_cfg['lfs_model'],
                model_type='catboost'
            )
        except Exception as e:
            logger.warning(f"LFS模型加载失败: {e}，仅使用IDT模式")
            lfs_model = None
            lfs_features = idt_features
            lfs_reference = np.ones(len(lfs_conditions))
            use_lfs = False
        _, lfs_features = load_feature_lists(
            models_cfg['idt_feature_list'], models_cfg['lfs_feature_list']
        )
        lfs_reference = lfs_conditions['reference_lfs_ms'].values
        use_lfs = True
    
    idt_reference = idt_conditions['reference_idt'].values
    
    # 使用 load_reactions_with_validation 动态加载并验证反应索引
    mech_path = mech_cfg['path']
    config_reaction_file = config.get('mechanism', {}).get('reaction_file', 'config/top20_reactions.txt')
    logger.info(f"从配置文件加载反应索引：{config_reaction_file}")
    reaction_indices, reaction_info = load_reactions_with_validation(
        config_path=config_reaction_file,
        mechanism_path=mech_path
    )
    target_pressure = mech_cfg.get('target_pressure', 101325.0)
    
    # 输出反应类型统计
    logger.info("反应类型统计:")
    type_stats = {}
    for idx, info in reaction_info.items():
        rtype = info['type']
        type_stats[rtype] = type_stats.get(rtype, 0) + 1
        logger.info(f"  反应 {idx} (YAML#{info.get('yaml_number', 'N/A')}): {info['type']} - {info['equation']}")
    
    logger.info(f"反应类型汇总:")
    for rtype, count in sorted(type_stats.items()):
        logger.info(f"  {rtype}: {count} 个")
    
    logger.info("使用 AFactorManager 动态提取基线 A 值...")
    afactor_manager = AFactorManager(mech_path, reaction_indices, target_pressure)
    logA_base = afactor_manager.logA_base
    
    logger.info(f"IDT工况: {len(idt_conditions)} 条")
    logger.info(f"LFS工况: {len(lfs_conditions)} 条")
    
    logger.info(f"反应数: {len(reaction_indices)}")
    
    logger.info("=" * 60)
    logger.info("加载原始训练数据...")
    logger.info("=" * 60)
    
    idt_train_df = None
    lfs_train_df = None
    
    if use_lfs:
        from src.core.objective import load_training_data
        idt_train_path = config.get('training_data', {}).get('idt_results', 'output/idt_results.csv')
        lfs_train_path = config.get('training_data', {}).get('lfs_results', 'output/lfs_results.csv')
        
        if os.path.exists(idt_train_path):
            idt_train_df, lfs_train_df = load_training_data(idt_train_path, lfs_train_path)
            logger.info(f"训练数据: IDT={len(idt_train_df)}, LFS={len(lfs_train_df)}")
        else:
            logger.warning(f"训练数据文件不存在: {idt_train_path}")
    
    logger.info("=" * 60)
    logger.info("设置正则化系数λ...")
    logger.info("=" * 60)
    
    # 优先使用配置文件中选定的λ值
    if 'selected_lambda' in lambda_cfg:
        lambda_reg = lambda_cfg['selected_lambda']
        logger.info(f"使用配置文件选定的λ: {lambda_reg}")
    else:
        logger.info("配置文件中未指定selected_lambda，使用交叉验证...")
        lambda_reg = cross_validate_lambda(
            idt_model, lfs_model,
            idt_features, lfs_features,
            idt_conditions, lfs_conditions,
            idt_reference, lfs_reference,
            logA_base,
            lambda_cfg.get('candidates', [0, 0.001, 0.01, 0.1, 1.0]),
            alpha=final_alpha,
            idt_only=(not use_lfs)
        )
    
    logger.info(f"最终λ值: {lambda_reg}")
    
    bounds = create_bounds(logA_base, config['search_space']['offset_range'])
    
    al_results = {
        'config': config,
        'lambda_reg': lambda_reg,
        'iterations': [],
        'converged': False,
        'final_solution': None,
        'early_stopped': False
    }

    # 移动平均收敛机制参数
    use_ma_convergence = al_cfg.get('use_moving_average_convergence', False)
    ma_window_size = al_cfg.get('convergence_window_size', 3)
    stability_threshold = al_cfg.get('stability_threshold', 0.02)
    max_error_history = []  # 存储最近几次迭代的最大误差

    
    # 早停机制参数
    best_error = float('inf')
    no_improve_count = 0
    patience = al_cfg.get('early_stopping_patience', 3)

    # 最优解追踪 (防止早停覆盖好解)
    best_logA_candidate = None
    best_obj_result = None
    best_idt_max_rel = None
    best_lfs_max_rel = None
    best_iteration = None

    # === 历史验证数据追踪（用于偏差校正） ===
    # 解决问题：IDT代理模型与验证结果负相关（-0.27）
    validation_history = {
        'logA_candidates': [],       # logA向量列表
        'surrogate_idt_pred': [],    # 代理预测IDT (log空间)
        'surrogate_lfs_pred': [],    # 代理预测LFS (log空间)
        'cantera_idt_actual': [],    # Cantera计算IDT (log空间)
        'cantera_lfs_actual': [],    # Cantera计算LFS (log空间)
        'validation_errors': []      # 验证误差
    }
    use_bias_correction = al_cfg.get('use_bias_correction', True)
    logger.info(f"偏差校正: {'启用' if use_bias_correction else '禁用'}")
    logger.info("=" * 60)
    logger.info("开始主动学习循环（CatBoost）...")
    logger.info("=" * 60)
    # ============================================================
    # 迭代 0: 验证原始机理性能
    # ============================================================
    logger.info("=" * 60)
    logger.info("迭代 0: 验证原始机理性能（logA_base）")
    logger.info("=" * 60)
    
    try:
        idt_true_baseline, lfs_true_baseline = validate_candidate(
            logA_base, mech_path, reaction_indices,
            idt_conditions, lfs_conditions,
            lfs_max_time=lfs_max_time,
            lfs_max_levels=lfs_max_levels,
            lfs_max_time_step_count=lfs_max_time_step_count,
            n_workers=cantera_workers
        )
        
        baseline_idt_error = compute_validation_error(idt_true_baseline, idt_reference, error_type='idt')
        baseline_lfs_error = compute_validation_error(lfs_true_baseline, lfs_reference, error_type='lfs')
        
        logger.info(f"原始机理验证误差:")
        logger.info(f"  IDT Max Log Error: {baseline_idt_error['max_log_error']:.4f}")
        logger.info(f"  LFS Max Log Error: {baseline_lfs_error['max_log_error']:.4f}")
        
        # 保存到结果
        al_results['baseline_validation'] = {
            'idt_max_log_error': float(baseline_idt_error['max_log_error']),
            'lfs_max_log_error': float(baseline_lfs_error['max_log_error']),
            'logA_base': logA_base.tolist()
        }
    except Exception as e:
        logger.warning(f"原始机理验证失败：{e}")
        logger.warning("继续 GA 优化...")
    
    logger.info("=" * 60)
    
    for iteration in range(1, al_cfg['max_iterations'] + 1):
        iter_start = time.time()
        force_full_retrain = False  # v7: 初始化偏差重置标志
        logger.info(f"\n{'='*60}")
        logger.info(f"Active Learning 迭代 {iteration}/{al_cfg['max_iterations']}")
        logger.info(f"{'='*60}")
        
        # 创建迭代输出目录
        iter_output_dir = os.path.join(catboost_output_dir, 'iterations', f'iter_{iteration:03d}')
        os.makedirs(iter_output_dir, exist_ok=True)
        
        
        # 创建评估函数（使用CatBoost）
        eval_fn = create_evaluation_function(
            idt_model, lfs_model,
            idt_features, lfs_features,
            idt_conditions, lfs_conditions,
            idt_reference, lfs_reference,
            lambda_reg, logA_base,
            model_type='catboost',
            alpha=final_alpha,
            idt_only=idt_only,
            gamma_idt=gamma_idt,
            gamma_lfs=gamma_lfs,
            use_max_error_penalty=use_max_error_penalty,
            validation_history=validation_history,
            use_bias_correction=use_bias_correction
        )
        
        # 调试：验证单位参数
        logger.info(f"Debug: eval_fn created with idt_unit='us', lfs_unit='cm/s'")
        
        toolbox = setup_toolbox(bounds, eval_fn, ga_cfg, logA_base)

        # v5: Surrogate model health check before GA
        check_surrogate = al_cfg.get('check_surrogate_health', True)
        abort_on_collapse = al_cfg.get('abort_on_model_collapse', True)

        if check_surrogate:
            logger.info("检查代理模型健康状态...")
            is_healthy, health_details = check_surrogate_health(
                idt_model, lfs_model,
                idt_conditions, lfs_conditions,
                idt_reference, lfs_reference,
                idt_features, lfs_features,
                logA_base,
                check_nan=True,
                check_range=True,
                check_variance=True,
                check_correlation=True,
                min_correlation=0.0,
                logger_instance=logger
            )

            if not is_healthy and abort_on_collapse:
                logger.error("代理模型健康检查失败，跳过当前迭代")
                logger.error(f"详细信息: {health_details['errors']}")

                # 记录跳过原因
                al_results['skip_retrain_reason'] = 'surrogate_health_failed'

                # 继续下一次迭代而不是崩溃
                iteration_time = time.time() - iteration_start
                continue

        logger.info("运行GA优化...")
        
        # GA历史记录
        ga_detailed_history = {
            'generation': [],
            'best_fitness': [],
            'avg_fitness': [],
            'best_idt_error': [],
            'best_lfs_error': [],
        }
        
        # 保存最后一次GA回调的compute_objective结果，避免重复计算
        last_ga_obj_result = {}
        
        def ga_callback(gen, best_ind, best_fitness):
            nonlocal last_ga_obj_result
            ga_detailed_history['generation'].append(gen)
            ga_detailed_history['best_fitness'].append(float(best_fitness))
            
            best_logA = np.array(best_ind)
            obj = compute_objective(
                best_logA, idt_model, lfs_model,
                idt_features, lfs_features,
                idt_conditions, lfs_conditions,
                idt_reference, lfs_reference,
                lambda_reg, logA_base, final_alpha, 
                error_type='log_mse', idt_only=idt_only,
                model_type='catboost',
                gamma_idt=gamma_idt,
                gamma_lfs=gamma_lfs,
                use_max_error_penalty=use_max_error_penalty
            )
            last_ga_obj_result = obj  # 保存最后一次结果
            ga_detailed_history['best_idt_error'].append(float(obj['idt_error']))
            ga_detailed_history['best_lfs_error'].append(float(obj['lfs_error']))
            
            if gen % 10 == 0:
                logger.info(f"  GA Gen {gen}: fitness={best_fitness:.6f}, IDT_LogMSE={obj['idt_error']:.6f}")
        
        # === 创建Cantera验证函数（用于GA过程中嵌入验证） ===
        # v4改进：GA过程中每隔validation_interval代执行一次Cantera验证
        # 用于实时记录代理模型偏差，辅助后续校正
        ga_validation_interval = ga_cfg.get('validation_interval', 20)

        def ga_cantera_validation_fn(logA_candidate: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
            """GA过程中嵌入的Cantera验证函数"""
            return validate_candidate(
                logA_candidate, mech_path, reaction_indices,
                idt_conditions, lfs_conditions,
                lfs_max_time=lfs_max_time,
                lfs_max_levels=lfs_max_levels,
                lfs_max_time_step_count=lfs_max_time_step_count,
                n_workers=cantera_workers
            )

        # 准备种子：优先使用历史最优解（修复v7）
        seed_logA = None
        checkpoint_path = os.path.join(catboost_output_dir, 'best_checkpoint.json')

        if iteration > 1:
            # 优先级1: 从best_checkpoint.json加载历史最优解
            if os.path.exists(checkpoint_path):
                try:
                    with open(checkpoint_path, 'r', encoding='utf-8') as f:
                        checkpoint = json.load(f)
                    seed_logA = np.array(checkpoint['logA'])
                    logger.info(f"【种子注入】使用历史最优解(迭代{checkpoint['iteration']}, 误差={checkpoint['validation_error']:.6f})")
                except Exception as e:
                    logger.warning(f"读取 best_checkpoint.json 失败: {e}，尝试其他种子来源")
                    seed_logA = None  # 明确重置为None

            # 优先级2: 内存中的best_logA_candidate
            if seed_logA is None and best_logA_candidate is not None:
                seed_logA = best_logA_candidate.copy()
                logger.info(f"【种子注入】使用内存历史最优解(迭代{best_iteration}, 误差={best_error:.6f})")

            # 优先级3: 仅当无历史最优时使用上一迭代解
            if seed_logA is None and 'logA_candidate' in al_results['iterations'][-1]:
                seed_logA = np.array(al_results['iterations'][-1]['logA_candidate'])
                logger.warning("【种子注入】无历史最优，使用上一迭代解(可能退化)")
        elif iteration == 1:
            # 第一轮迭代：检查是否有外部种子文件
            external_seed_file = al_cfg.get('seed_file', None)
            if external_seed_file and os.path.exists(external_seed_file):
                try:
                    with open(external_seed_file, 'r', encoding='utf-8') as f:
                        seed_data = json.load(f)
                    seed_logA = np.array(seed_data['logA'])
                    logger.info(f"【种子注入】使用外部种子文件: {external_seed_file}")
                    if 'validation_error' in seed_data:
                        logger.info(f"  种子来源验证误差: {seed_data['validation_error']*100:.2f}%")
                except Exception as e:
                    logger.warning(f"读取外部种子文件失败: {e}，使用logA_base")
                    seed_logA = logA_base.copy()
            else:
                # 使用logA_base作为初始种子
                seed_logA = logA_base.copy()
                logger.info("【种子注入】首轮迭代，使用logA_base作为种子")

        best_ind, best_fitness, ga_history = run_ga_with_callback(
            toolbox, ga_cfg, seed_individual=seed_logA, callback=ga_callback,
            validation_fn=ga_cantera_validation_fn if use_lfs else None,
            validation_interval=ga_validation_interval,
            verbose=False
        )
        
        # 保存GA详细历史到迭代目录
        ga_history_path = os.path.join(iter_output_dir, 'ga_detailed_history.json')
        with open(ga_history_path, 'w', encoding='utf-8') as f:
            json.dump(ga_detailed_history, f, indent=2, ensure_ascii=False, default=str)
        logger.info(f"  [迭代保存] GA历史已保存到: {ga_history_path}")
        logA_candidate = np.array(best_ind)
        
        logger.info(f"GA最优适应度: {best_fitness:.6f}")
        
        # 使用GA回调中保存的结果，避免重复计算
        if last_ga_obj_result:
            obj_result = last_ga_obj_result
        else:
            # 如果GA回调没有执行（极少情况），则重新计算
            obj_result = compute_objective(
                logA_candidate, idt_model, lfs_model,
                idt_features, lfs_features,
                idt_conditions, lfs_conditions,
                idt_reference, lfs_reference,
                lambda_reg, logA_base, final_alpha,
                error_type='log_mse', idt_only=idt_only,
                model_type='catboost',
                gamma_idt=gamma_idt,
                gamma_lfs=gamma_lfs,
                use_max_error_penalty=use_max_error_penalty
            )

        # === 最优解保护机制已移至Cantera验证后（行885-910）===
        # 原：基于代理误差的保护（此处已删除，因为代理误差与验证误差负相关）
        # 新：基于验证误差的保护在Cantera验证后执行，更加可靠

        logger.info(f"代理模型预测误差 (对数空间):")
        logger.info(f"  IDT Log-MSE: {obj_result['idt_error']:.6f}")
        if use_lfs:
            logger.info(f"  LFS Log-MSE: {obj_result['lfs_error']:.6f}")
            logger.info(f"  加权总误差: {obj_result['total'] - obj_result['reg_term']:.6f}")
        
        # Cantera验证
        if skip_lfs:
            # LFS模型未就绪时，跳过Cantera验证，使用代理模型预测与Ground Truth的误差
            # 注意：这不是最终优化效果的度量，仅用于迭代过程跟踪
            logger.info("跳过 Cantera 验证（LFS 模型未就绪），使用代理模型预测")
            idt_pred_feat = build_features_batch(logA_candidate, idt_conditions, idt_features)
            idt_pred_log = predict_idt(idt_model, idt_pred_feat, idt_features, model_type='catboost')
            idt_pred = 10 ** idt_pred_log
            
            # 代理模型预测 vs Ground Truth（临时度量）
            idt_error_result = compute_validation_error(idt_pred, idt_reference, error_type='idt')
            
            idt_max_rel = idt_error_result['max_log_error']
            lfs_max_rel = 0.0
            max_error = idt_max_rel
            
            idt_true = None
            lfs_true = None
            lfs_error_result = {'msre': 0, 'rmsre': 0, 'max_log_error': 0, 'max_rel_error_linear': 0, 'valid_count': 0}
            
            idt_log_error = np.abs(idt_pred_log - np.log10(idt_reference))
            idt_max_log_error = float(np.max(idt_log_error))
            lfs_max_log_error = 0.0

        else:
            logger.info(f"Cantera 验证 ({cantera_workers}进程)...")
            
            try:
                idt_true, lfs_true = validate_candidate(
                    logA_candidate, mech_path, reaction_indices,
                    idt_conditions, lfs_conditions,
                    lfs_max_time=lfs_max_time,
                    lfs_max_levels=lfs_max_levels,
                    lfs_max_time_step_count=lfs_max_time_step_count,
                    n_workers=cantera_workers
                )
            except Exception as e:
                logger.error(f"Cantera 验证失败 (迭代{iteration}): {e}")
                logger.warning("跳过本次迭代的验证，继续下一次迭代")
                continue
            
            # === 代理模型预测（用于评估代理模型精度） ===
            idt_pred_feat = build_features_batch(logA_candidate, idt_conditions, idt_features)
            idt_pred_log = predict_idt(idt_model, idt_pred_feat, idt_features, model_type='catboost')
            # 数值稳定性：检查NaN/Inf
            idt_pred = np.where(np.isfinite(idt_pred_log), 10 ** idt_pred_log, np.nan)  # 秒
            
            lfs_pred_feat = build_features_batch(logA_candidate, lfs_conditions, lfs_features)
            lfs_pred_log = predict_lfs(lfs_model, lfs_pred_feat, lfs_features, model_type='catboost')
            # 数值稳定性：检查NaN/Inf
            lfs_pred = np.where(np.isfinite(lfs_pred_log), 10 ** lfs_pred_log, np.nan)  # m/s

            # === 验证误差计算：Cantera计算值 vs Ground Truth基准值 ===
            # 这是最终优化效果的度量：机理与实验的偏差
            # idt_true: Cantera计算的IDT值（秒）
            # idt_reference: Ground Truth基准IDT值（秒）
            idt_error_result = compute_validation_error(idt_true, idt_reference, error_type='idt')
            lfs_error_result = compute_validation_error(lfs_true, lfs_reference, error_type='lfs')
            
            idt_max_rel = idt_error_result['p95_log_error']
            lfs_max_rel = lfs_error_result['p95_log_error'] if use_lfs else 0.0
            max_error = max(idt_max_rel, lfs_max_rel)
            
            # 代理模型与Cantera的对数空间误差（用于评估代理模型精度）
            idt_log_error = np.abs(idt_pred_log - np.log10(idt_true))
            lfs_log_error = np.abs(lfs_pred_log - np.log10(lfs_true))
            idt_max_log_error = float(np.nanmax(idt_log_error))
            lfs_max_log_error = float(np.nanmax(lfs_log_error)) if use_lfs else 0.0

            # === v7新增: Surrogate-Validation偏差检测 ===
            # 检测代理模型预测与Cantera验证的偏差，识别"代理欺骗"问题
            try:
                idt_gap_valid, idt_gap_details = check_surrogate_validation_gap(
                    surrogate_pred=idt_pred_log,
                    cantera_true=idt_true,
                    target_type='idt',
                    gap_threshold=0.15,
                    correlation_threshold=0.5,
                    logger_instance=logger
                )

                if use_lfs:
                    lfs_gap_valid, lfs_gap_details = check_surrogate_validation_gap(
                        surrogate_pred=lfs_pred_log,
                        cantera_true=lfs_true,
                        target_type='lfs',
                        gap_threshold=0.15,
                        correlation_threshold=0.5,
                        logger_instance=logger
                    )
                else:
                    lfs_gap_valid = True
                    lfs_gap_details = {}

                # 偏差过大时触发全量训练重置
                if not idt_gap_valid or not lfs_gap_valid:
                    logger.warning("【偏差警告】代理模型偏差过大，触发全量训练重置")
                    logger.warning(f"  IDT gap details: {idt_gap_details}")
                    if use_lfs:
                        logger.warning(f"  LFS gap details: {lfs_gap_details}")
                    force_full_retrain = True

            except Exception as e:
                logger.warning(f"偏差检测失败: {e}，跳过检测")
                idt_gap_valid = True
                lfs_gap_valid = True
                idt_gap_details = {'error': str(e)}
                lfs_gap_details = {}
        
        iter_time = time.time() - iter_start
        
        iter_result = {
            'iteration': iteration,
            'ga_best_fitness': float(best_fitness),
            'logA_candidate': logA_candidate.tolist(),
            'surrogate_errors': {
                'idt_log_mse': obj_result['idt_error'],
                'lfs_log_mse': obj_result['lfs_error'],
                'metric': 'log_mse (log10(s for IDT, m/s for LFS), GA optimization)'
            },
            'validation_errors': {
                'idt': {
                    'msre': idt_error_result['msre'],
                    'rmsre': idt_error_result['rmsre'],
                    'p95_log_error': idt_error_result['p95_log_error'],
                    'max_log_error': idt_error_result['max_log_error'],
                    'max_rel_error_linear': idt_error_result.get('max_rel_error_linear', 0),
                    'valid_count': idt_error_result['valid_count'],
                    'metric': 'msre (Cantera vs Ground Truth, 机理与实验偏差)'
                },
                'lfs': {
                    'msre': lfs_error_result['msre'],
                    'rmsre': lfs_error_result['rmsre'],
                    'p95_log_error': lfs_error_result['p95_log_error'],
                    'max_log_error': lfs_error_result['max_log_error'],
                    'max_rel_error_linear': lfs_error_result.get('max_rel_error_linear', 0),
                    'valid_count': lfs_error_result['valid_count'],
                    'metric': 'msre (Cantera vs Ground Truth, 机理与实验偏差)'
                }

            },
            'max_validation_error': max_error,
            'iteration_time': iter_time
        }
        al_results['iterations'].append(iter_result)

        # === 更新历史验证数据（用于下一轮偏差校正） ===
        if use_bias_correction and not skip_lfs:
            validation_history['logA_candidates'].append(logA_candidate.tolist())
            validation_history['surrogate_idt_pred'].append(idt_pred_log.tolist() if isinstance(idt_pred_log, np.ndarray) else list(idt_pred_log))
            validation_history['surrogate_lfs_pred'].append(lfs_pred_log.tolist() if isinstance(lfs_pred_log, np.ndarray) else list(lfs_pred_log) if use_lfs else [])
            validation_history['cantera_idt_actual'].append(np.log10(idt_true).tolist() if isinstance(idt_true, np.ndarray) else list(np.log10(idt_true)))
            validation_history['cantera_lfs_actual'].append(np.log10(lfs_true).tolist() if isinstance(lfs_true, np.ndarray) and use_lfs else list(np.log10(lfs_true)) if use_lfs else [])
            validation_history['validation_errors'].append(max_error)
            logger.info(f"  [偏差校正] 历史数据已更新，共{len(validation_history['logA_candidates'])}条记录")

        # 保存当前迭代结果到独立目录
        iter_result_path = os.path.join(iter_output_dir, 'iteration_result.json')
        with open(iter_result_path, 'w', encoding='utf-8') as f:
            json.dump(iter_result, f, indent=2, ensure_ascii=False, default=str)
        logger.info(f"  [迭代保存] 结果已保存到: {iter_result_path}")
        
        
        logger.info("验证误差 (Cantera vs Ground Truth, 机理与实验偏差):")

        logger.info(f"  IDT: MSRE={idt_error_result['msre']:.6f}, RMSRE={idt_error_result['rmsre']:.4f}, P95 Log Error={idt_error_result['p95_log_error']:.4f}, Max Log Error={idt_error_result['max_log_error']:.4f} (线性≈{idt_error_result.get('max_rel_error_linear', 0)*100:.1f}%)")
        if use_lfs:
            logger.info(f"  LFS: MSRE={lfs_error_result['msre']:.6f}, RMSRE={lfs_error_result['rmsre']:.4f}, P95 Log Error={lfs_error_result['p95_log_error']:.4f}, Max Log Error={lfs_error_result['max_log_error']:.4f} (线性≈{lfs_error_result.get('max_rel_error_linear', 0)*100:.1f}%)")
        logger.info(f"迭代耗时: {iter_time:.1f}s")
        
        # 中间保存：每5次迭代保存一次结果（防止崩溃丢失数据）
        if iteration % 5 == 0 or iteration == 1:
            try:
                save_results(al_results, catboost_output_dir, 'catboost_active_learning_results.json')
                logger.info(f"  [中间保存] 已保存前{iteration}次迭代结果")
            except Exception as e:
                logger.warning(f"  [中间保存] 失败: {e}")
        
        # 移动平均收敛判断（方案A - 减少振荡）
        max_error_history.append(max_error)
        if len(max_error_history) > ma_window_size:
            max_error_history.pop(0)
        
        ma_converged = False
        if use_ma_convergence and len(max_error_history) >= ma_window_size:
            ma_avg = np.mean(max_error_history)
            ma_std = np.std(max_error_history)
            ma_cv = ma_std / ma_avg if ma_avg > 0 else float('inf')  # 变异系数
            max_rel_threshold = al_cfg.get('max_rel_error_threshold', 0.15)
            
            logger.info(f"\n移动平均收敛检查（窗口={ma_window_size}）:")
            logger.info(f"  历史最大误差: {[f'{e:.4f}' for e in max_error_history]}")
            logger.info(f"  平均值: {ma_avg:.4f}, 标准差: {ma_std:.4f}, 变异系数: {ma_cv:.2%}")
            
            
            # 收敛条件：平均值低于阈值 且 变异系数小于稳定性阈值
            if ma_avg < max_rel_threshold and ma_cv < stability_threshold:
                ma_converged = True
                logger.info(f"  ✓ 移动平均收敛达成! (平均值<{max_rel_threshold:.4f} 且 变异系数<{stability_threshold:.2%})")

        # 收敛判断 (双收敛标准)
        use_dual = al_cfg.get('use_dual_convergence', True)

        if use_dual:
            # 双标准收敛：Log-MSE尽量小 + Max Log Error < 阈值
            max_rel_threshold = al_cfg.get('max_rel_error_threshold', 0.15)
            # log_mse_threshold 动态计算，应略小于 max_rel_threshold^2 / 3 (经验公式)
            default_log_mse = (max_rel_threshold ** 2) / 3  # ≈ 0.0075 for 0.15
            log_mse_threshold = al_cfg.get('log_mse_threshold', default_log_mse)

            # 当前迭代的Log-MSE
            current_idt_log_mse = obj_result['idt_error']
            current_lfs_log_mse = obj_result.get('lfs_error', 0.0) if use_lfs else 0.0

            # 收敛条件1：Max Log Error < 阈值（硬性约束）
            idt_rel_converged = idt_max_rel < max_rel_threshold
            lfs_rel_converged = (not use_lfs) or (lfs_max_rel < max_rel_threshold)

            # 收敛条件2：Log-MSE 低于阈值（质量约束）
            idt_mse_converged = current_idt_log_mse < log_mse_threshold
            lfs_mse_converged = (not use_lfs) or (current_lfs_log_mse < log_mse_threshold)

            # 双条件同时满足
            idt_converged = idt_rel_converged and idt_mse_converged
            lfs_converged = lfs_rel_converged and lfs_mse_converged

            logger.info(f"\n收敛性检查（双标准）:")
            logger.info(f"  P95 Log Error: IDT={idt_max_rel:.4f}({'✓' if idt_rel_converged else '✗'}), LFS={lfs_max_rel:.4f}({'✓' if lfs_rel_converged else '✗'}), 阈值={max_rel_threshold:.4f}")
            logger.info(f"  Log-MSE: IDT={current_idt_log_mse:.6f}({'✓' if idt_mse_converged else '✗'}), LFS={current_lfs_log_mse:.6f}({'✓' if lfs_mse_converged else '✗'}), 阈值={log_mse_threshold:.6f}")
        else:
            # 单标准收敛：仅使用Max Relative Error
            convergence_threshold = al_cfg.get('convergence_threshold', 0.15)
            idt_converged = idt_max_rel < convergence_threshold
            lfs_converged = (not use_lfs) or (lfs_max_rel < convergence_threshold)
            logger.info(f"\n收敛性检查（单标准）:")
            logger.info(f"  P95 Log Error: IDT={idt_max_rel:.4f}, LFS={lfs_max_rel:.4f}, 阈值={convergence_threshold:.4f}")
        
        if idt_converged and lfs_converged:
            logger.info(f"\n✓ 收敛达成! IDT和LFS均满足双标准")
            al_results['converged'] = True
            al_results['final_solution'] = {
                'logA': logA_candidate.tolist(),
                'A': np.power(10, logA_candidate).tolist(),
                'validation_error': max_error,
                'idt_max_relative_error': idt_max_rel,
                'lfs_max_relative_error': lfs_max_rel,
                'idt_log_mse': obj_result['idt_error'],
                'lfs_log_mse': obj_result.get('lfs_error', 0.0) if use_lfs else 0.0,
                'convergence_type': 'standard',  # 标准收敛
            }
            break
        
        # 移动平均收敛（作为备选收敛方式）
        if use_ma_convergence and ma_converged:
            logger.info(f"\n✓ 移动平均收敛达成! 连续{ma_window_size}次迭代稳定")
            al_results['converged'] = True
            al_results['final_solution'] = {
                'logA': logA_candidate.tolist(),
                'A': np.power(10, logA_candidate).tolist(),
                'validation_error': max_error,
                'idt_max_relative_error': idt_max_rel,
                'lfs_max_relative_error': lfs_max_rel,
                'idt_log_mse': obj_result['idt_error'],
                'lfs_log_mse': obj_result.get('lfs_error', 0.0) if use_lfs else 0.0,
                'convergence_type': 'moving_average',  # 移动平均收敛
                'ma_window_size': ma_window_size,
                'ma_average': float(np.mean(max_error_history)),
                'ma_std': float(np.std(max_error_history)),
            }
            break
        
        # 保存最优解检查点（防止后续迭代退化）
        if max_error < best_error:
            best_error = max_error
            best_logA_candidate = logA_candidate.copy()
            best_obj_result = obj_result.copy()
            best_idt_max_rel = idt_max_rel
            best_lfs_max_rel = lfs_max_rel
            best_iteration = iteration
            no_improve_count = 0
            logger.info(f"早停检测: 新最优误差={best_error:.6f} (迭代{iteration}), 重置计数器")
            
            # CRITICAL: 保存检查点到磁盘
            checkpoint = {
                'iteration': iteration,
                'logA': logA_candidate.tolist(),
                'validation_error': float(max_error),
                'idt_error': float(idt_max_rel),
                'lfs_error': float(lfs_max_rel),
                'timestamp': time.strftime('%Y%m%d_%H%M%S')
            }
            checkpoint_path = os.path.join(catboost_output_dir, 'best_checkpoint.json')
            with open(checkpoint_path, 'w', encoding='utf-8') as f:
                json.dump(checkpoint, f, indent=2, ensure_ascii=False)
                logger.info(f"  [检查点] 最优解已保存: {checkpoint_path}")
        else:
            no_improve_count += 1
            logger.info(f"早停检测: 无改善次数={no_improve_count}/{patience}")

            # === 基于验证误差的最优解保护 ===
            # 如果当前验证误差比历史最优差，用历史最优解替代（用于下一轮种子注入）
            if best_logA_candidate is not None:
                logger.info(f"【验证保护】当前误差({max_error:.6f})差于历史最优({best_error:.6f})，使用历史最优解")
                logA_candidate = best_logA_candidate.copy()
                # CRITICAL: 同时更新已保存的迭代结果，确保下一轮种子注入使用正确解
                if al_results['iterations']:
                    al_results['iterations'][-1]['logA_candidate'] = logA_candidate.tolist()
                    logger.info(f"  [种子更新] 已更新迭代{iteration}的种子为历史最优解")
        
        if no_improve_count >= patience:
            logger.info(f"\n早停触发: 连续{patience}次迭代无改善")
            al_results['early_stopped'] = True
            if best_logA_candidate is not None:
                logger.info(f"使用历史最优解 (迭代{best_iteration}, 误差={best_error:.6f})")
                al_results['final_solution'] = {
                    'logA': best_logA_candidate.tolist(),
                    'A': np.power(10, best_logA_candidate).tolist(),
                    'validation_error': best_error,
                    'idt_max_relative_error': best_idt_max_rel,
                    'lfs_max_relative_error': best_lfs_max_rel,
                    'convergence_type': 'early_stopped_best',
                    'best_iteration': best_iteration,
                }
            else:
                logger.warning("未找到任何最优解，使用当前迭代解")
                al_results['final_solution'] = {
                    'logA': logA_candidate.tolist(),
                    'A': np.power(10, logA_candidate).tolist(),
                    'validation_error': max_error,
                    'idt_max_relative_error': idt_max_rel,
                    'lfs_max_relative_error': lfs_max_rel,
                }
            break
        # === 三级早停决策逻辑（双标准收敛） ===
        # 1. 完全收敛：双标准同时满足，直接退出优化
        # 2. 接近收敛：仅 P95 接近阈值，跳过重训练，继续 GA 探索
        # 3. 未收敛：正常重训练

        convergence_threshold = al_cfg.get('max_rel_error_threshold', 0.08)
        close_threshold = convergence_threshold * 1.05  # 5% 容差
        
        # 双标准收敛检查
        max_rel_threshold = al_cfg.get('max_rel_error_threshold', 0.08)
        default_log_mse = (max_rel_threshold ** 2) / 3  # ≈ 0.0021 for 0.08
        log_mse_threshold = al_cfg.get('log_mse_threshold', default_log_mse)
        
        # 当前迭代的 Log-MSE
        current_idt_log_mse = obj_result['idt_error']
        current_lfs_log_mse = obj_result.get('lfs_error', 0.0) if use_lfs else 0.0
        
        # 收敛条件 1：P95 Log Error < 阈值（硬性约束）
        idt_p95_ok = idt_error_result['p95_log_error'] <= convergence_threshold
        lfs_p95_ok = (not use_lfs) or (lfs_error_result['p95_log_error'] <= convergence_threshold)
        
        # 收敛条件 2：Log-MSE < 阈值（质量约束）
        idt_mse_ok = current_idt_log_mse <= log_mse_threshold
        lfs_mse_ok = (not use_lfs) or (current_lfs_log_mse <= log_mse_threshold)
        
        # 双条件同时满足
        idt_converged = idt_p95_ok and idt_mse_ok
        lfs_converged = lfs_p95_ok and lfs_mse_ok
        
        logger.info(f"\n早停收敛检查（双标准）:")
        logger.info(f"  P95 Log Error: IDT={idt_error_result['p95_log_error']:.4f}({'✓' if idt_p95_ok else '✗'}), LFS={lfs_error_result['p95_log_error']:.4f}({'✓' if lfs_p95_ok else '✗'}), 阈值={convergence_threshold:.4f}")
        logger.info(f"  Log-MSE: IDT={current_idt_log_mse:.6f}({'✓' if idt_mse_ok else '✗'}), LFS={current_lfs_log_mse:.6f}({'✓' if lfs_mse_ok else '✗'}), 阈值={log_mse_threshold:.6f}")
        
        if idt_converged and lfs_converged:
            # 完全收敛：双标准同时满足，直接退出整个优化
            logger.info(f"\n【早停】双标准收敛达成！P95={max_error:.4f}, MSE_IDT={current_idt_log_mse:.6f}")
            al_results['skip_retrain_reason'] = 'converged'
            al_results['converged'] = True
            al_results['final_solution'] = {
                'logA': logA_candidate.tolist(),
                'A': np.power(10, logA_candidate).tolist(),
                'validation_error': max_error,
                'idt_max_relative_error': idt_max_rel,
                'lfs_max_relative_error': lfs_max_rel,
                'idt_p95_log_error': idt_error_result['p95_log_error'],
                'lfs_p95_log_error': lfs_error_result['p95_log_error'] if use_lfs else 0.0,
                'idt_log_mse': current_idt_log_mse,
                'lfs_log_mse': current_lfs_log_mse if use_lfs else 0.0,
                'best_iteration': iteration,
                'convergence_type': 'dual_convergence_early_stop',
            }
            break  # 退出主动学习循环

        elif max_error <= close_threshold:
            # 接近收敛：仅 P95 接近阈值，跳过重训练，继续 GA 探索
            logger.info(f"\n【早停策略】接近收敛：{max_error:.4f} <= {close_threshold:.4f} (阈值={convergence_threshold:.4f})")
            logger.info("跳过模型重训练，保留当前最优模型（防止灾难性遗忘）")
            al_results['skip_retrain_reason'] = 'close_to_threshold'
            al_cfg['skip_retrain'] = True

        else:
            # 未收敛：正常流程
            al_results['skip_retrain_reason'] = 'none'
            al_cfg['skip_retrain'] = False
        
        # 模型重训练（CatBoost）
        if use_lfs and idt_train_df is not None:
            skip_retrain = al_cfg.get('skip_retrain', False)
            
            if skip_retrain:
                logger.info("【调试模式】跳过模型重训练")
            else:
                logger.info("=" * 60)
                logger.info("执行CatBoost模型重训练...")
                logger.info("=" * 60)
                
                skip_infill = al_cfg.get('skip_infill', False)
                infill_lfs = None
                
                if skip_infill:
                    logger.info("【调试模式】跳过回填样本")
                    merged_idt = idt_train_df
                else:
                    # Check infill strategy (use if-elif to prevent overwrite)
                    use_targeted = al_cfg.get('use_targeted_infill', True)  # Phase 1: 默认启用针对性采样
                    use_enhanced = al_cfg.get('use_enhanced_infill', False)
                    
                    infill_idt = None
                    infill_lfs = None
                    
                    if use_targeted:
                        # Phase 1: 使用针对性采样，专注最大误差点
                        # 使用 Cantera 计算回填样本目标值（特征与目标值一一对应）
                        logger.info("Creating targeted infill samples with Cantera (Phase 1 optimization)...")
                        max_error_ratio = al_cfg.get('max_error_sampling_ratio', 0.5)
                        top_k = al_cfg.get('top_k_errors', 5)
                        logger.info(f"  Targeted sampling: {max_error_ratio*100:.0f}% samples for top-{top_k} max error conditions")
                        
                        # 读取高级配置
                        infill_cfg = al_cfg.get('infill_config', {})
                        cantera_cfg = config.get('cantera', {})
                        n_infill_workers = infill_cfg.get('n_infill_workers', cantera_cfg.get('n_workers', 4))
                        
                        infill_idt, infill_lfs = create_targeted_infill_samples_with_cantera(
                            logA_candidate,
                            idt_conditions, lfs_conditions,
                            idt_pred=idt_pred,
                            lfs_pred=lfs_pred,
                            idt_reference=idt_reference,  # Ground Truth IDT (秒)
                            lfs_reference=lfs_reference,  # Ground Truth LFS (m/s)
                            mech_path=mech_path,
                            reaction_indices=reaction_indices,
                            n_samples=al_cfg.get('n_infill_samples', 300),
                            perturbation=al_cfg.get('infill_perturbation', 0.08),
                            max_error_sampling_ratio=max_error_ratio,
                            top_k_errors=top_k,
                            lfs_max_error_ratio=al_cfg.get('lfs_max_error_sampling_ratio', max_error_ratio),
                            lfs_top_k=al_cfg.get('lfs_top_k_errors', top_k),
                            adaptive_perturbation=al_cfg.get('adaptive_perturbation', True),
                            logA_base=logA_base,
                            offset_range=config['search_space']['offset_range'],
                            idt_true=idt_true,  # Cantera计算的IDT（秒）
                            lfs_true=lfs_true,   # Cantera计算的LFS（m/s）
                            # 高级参数
                            n_workers=n_infill_workers,
                            exploration_ratio=infill_cfg.get('exploration_ratio', 0.0),
                            exploration_strategy=infill_cfg.get('exploration_strategy', 'uniform'),
                            boundary_ratio=infill_cfg.get('boundary_ratio', 0.0),
                            # LFS计算参数（从配置读取）
                            lfs_domain_width=cantera_cfg.get('lfs', {}).get('domain_width', 0.02),
                            lfs_max_grid_points=cantera_cfg.get('lfs', {}).get('max_grid_points', 5000),
                            lfs_max_levels=cantera_cfg.get('lfs', {}).get('max_levels', 4),
                            lfs_max_time=cantera_cfg.get('lfs', {}).get('max_time', 1200.0),
                        )

                    elif use_enhanced:
                        # Phase 2: 使用增强多策略采样
                        logger.info("Creating enhanced infill samples (multi-strategy)...")
                        strategy_ratios = tuple(al_cfg.get('infill_strategy_ratios', [0.5, 0.3, 0.2]))
                        logger.info(f"  Strategy ratios: error_weighted={strategy_ratios[0]}, "
                                    f"space_filling={strategy_ratios[1]}, boundary={strategy_ratios[2]}")
                        
                        infill_idt, infill_lfs = create_enhanced_infill_samples(
                            logA_candidate,
                            idt_conditions, lfs_conditions,
                            idt_true, lfs_true,
                            logA_base,  # Required for boundary sampling
                            idt_pred=idt_pred,
                            lfs_pred=lfs_pred,
                            n_total_samples=al_cfg.get('n_infill_samples', 100),
                            perturbation=al_cfg.get('infill_perturbation', 0.05),
                            offset_range=config['search_space']['offset_range'],
                            strategy_ratios=strategy_ratios,
                            idt_reference=idt_reference,  # For LFS fallback
                            lfs_reference=lfs_reference   # For LFS fallback
                        )
                    else:
                        # Default: 使用简单误差加权采样
                        logger.info("Creating infill samples (error-weighted sampling)...")
                        infill_idt, infill_lfs = create_infill_samples(
                            logA_candidate,
                            idt_conditions, lfs_conditions,
                            idt_true, lfs_true,
                            idt_pred=idt_pred,
                            lfs_pred=lfs_pred,
                            n_samples=al_cfg.get('n_infill_samples', 5),
                            perturbation=al_cfg.get('infill_perturbation', 0.05),
                            strategy='error_weighted',
                            logA_base=logA_base,
                            offset_range=config['search_space']['offset_range']
                        )
                    
                    # Merge infill samples with training data
                    
                    if infill_idt is not None and len(infill_idt) > 0:
                        merged_idt = merge_training_data(
                            idt_train_df, infill_idt, 'IDT'
                        )
                    else:
                        merged_idt = idt_train_df
                        logger.info(f"无 IDT 回填样本，使用原始数据：{len(merged_idt)}")
                X_idt, y_idt = prepare_idt_training_data(merged_idt, idt_features)
                
                logger.info(f"重训练数据统计:")
                logger.info(f"  X_idt shape: {X_idt.shape}")
                logger.info(f"  y_idt range: [{y_idt.min():.4f}, {y_idt.max():.4f}]")
                
                # 使用CatBoost重训练
                # 创建迭代特定的模型目录
                iter_model_dir = os.path.join(iter_output_dir, 'models')
                os.makedirs(iter_model_dir, exist_ok=True)
                
                # 确定基础模型路径（第一次用基准，后续用前一次迭代的模型）
                if iteration == 1:
                    idt_base_model = models_cfg['idt_model']
                    lfs_base_model = models_cfg.get('lfs_model')
                else:
                    # 使用上一次迭代的模型
                    prev_iter = iteration - 1
                    prev_iter_dir = os.path.join(catboost_output_dir, 'iterations', f'iter_{prev_iter:03d}')
                    idt_base_model = os.path.join(prev_iter_dir, 'models', 'idt_catboost', 'model.cbm')
                    lfs_base_model = os.path.join(prev_iter_dir, 'models', 'lfs_catboost', 'model.cbm')
                    
                    # 如果上一次迭代的模型不存在，回退到基准模型
                    if not os.path.exists(idt_base_model):
                        logger.warning(f"上一次迭代的IDT模型不存在，使用基准模型: {models_cfg['idt_model']}")
                        idt_base_model = models_cfg['idt_model']
                    if lfs_base_model and not os.path.exists(lfs_base_model):
                        logger.warning(f"上一次迭代的LFS模型不存在，使用基准模型: {models_cfg.get('lfs_model')}")
                        lfs_base_model = models_cfg.get('lfs_model')

                # === v7新增: 定期全量训练重置偏差 ===
                full_retrain_interval = al_cfg.get('full_retrain_interval', 3)
                use_incremental = retrain_cfg.get('use_transfer_learning', True)

                # 条件1: 偏差检测触发全量训练（force_full_retrain在Cantera验证后设置）
                # 条件2: 定期重置（每N次迭代）
                if force_full_retrain:
                    use_incremental = False
                    logger.info(f"【全量训练重置】迭代{iteration}: 偏差检测触发")
                elif full_retrain_interval > 0 and iteration > 1 and (iteration % full_retrain_interval == 0):
                    use_incremental = False
                    logger.info(f"【全量训练重置】迭代{iteration}: 定期重置（间隔{full_retrain_interval}）")
                else:
                    logger.info(f"【增量训练】迭代{iteration}: 使用迁移学习")

                # 使用CatBoost重训练
                idt_model = retrain_catboost_with_fallback(
                    X_idt, y_idt, idt_features,
                    model_type='idt',
                    base_model_path=idt_base_model,
                    use_incremental=use_incremental,
                    fine_tune_rounds=retrain_cfg.get('fine_tune_rounds', 100),
                    model_dir=os.path.join(iter_model_dir, 'idt_catboost')
                )

                logger.info(f"IDT CatBoost模型重训练完成: {len(merged_idt)} 样本")
                
                merged_lfs = None
                if skip_infill:
                    merged_lfs = lfs_train_df
                elif lfs_train_df is not None and infill_lfs is not None and len(infill_lfs) > 0:
                    merged_lfs = merge_training_data(
                        lfs_train_df, infill_lfs, 'LFS'
                    )
                
                if merged_lfs is not None:
                    X_lfs, y_lfs = prepare_lfs_training_data(merged_lfs, lfs_features)

                    lfs_model = retrain_catboost_with_fallback(
                        X_lfs, y_lfs, lfs_features,
                        model_type='lfs',
                        base_model_path=lfs_base_model,
                        use_incremental=use_incremental,  # v7: 使用相同的增量/全量训练策略
                        fine_tune_rounds=retrain_cfg.get('fine_tune_rounds', 100),
                        model_dir=os.path.join(iter_model_dir, 'lfs_catboost')
                    )

                    logger.info(f"LFS CatBoost模型重训练完成: {len(merged_lfs)} 样本")
                
                idt_train_df = merged_idt
                lfs_train_df = merged_lfs if lfs_train_df is not None else None
                
                # 更新评估函数
                eval_fn = create_evaluation_function(
                    idt_model, lfs_model,
                    idt_features, lfs_features,
                    idt_conditions, lfs_conditions,
                    idt_reference, lfs_reference,
                    lambda_reg, logA_base,
                    model_type='catboost',
                    alpha=final_alpha,
                    idt_only=idt_only,
                    gamma_idt=gamma_idt,
                    gamma_lfs=gamma_lfs,
                    use_max_error_penalty=use_max_error_penalty,
                    validation_history=validation_history,
                    use_bias_correction=use_bias_correction
                )
        else:
            logger.info("跳过模型重训练（仅IDT模式或无训练数据）")
    
    if not al_results['converged']:
        # 优先使用早停时保存的最优解
        if best_logA_candidate is not None:
            logger.info(f"\n使用早停时保存的最优解 (迭代{best_iteration}, 误差={best_error:.6f})")
            al_results['final_solution'] = {
                'logA': best_logA_candidate.tolist(),
                'A': np.power(10, best_logA_candidate).tolist(),
                'validation_error': best_error,
                'idt_max_relative_error': al_results['iterations'][best_iteration-1]['validation_errors']['idt']['max_rel_error_linear'] if best_iteration > 0 else 0.0,
                'lfs_max_relative_error': al_results['iterations'][best_iteration-1]['validation_errors']['lfs']['max_rel_error_linear'] if best_iteration > 0 and use_lfs else 0.0,
                'convergence_type': 'max_iterations_best',
                'best_iteration': best_iteration,
            }
        else:
            # 回退：从历史记录中查找最优解
            best_iter = min(al_results['iterations'], key=lambda x: x['max_validation_error'])
            al_results['final_solution'] = {
                'logA': best_iter['logA_candidate'],
                'A': np.power(10, best_iter['logA_candidate']).tolist(),
                'validation_error': best_iter['max_validation_error'],
                'convergence_type': 'max_iterations_history',
                'best_iteration': best_iter['iteration'],
            }
            logger.info(f"\n达到最大迭代次数，使用最优解（迭代{best_iter['iteration']}）")
    total_time = time.time() - start_time
    al_results['total_time'] = total_time
    al_results['alpha'] = final_alpha
    al_results['model_type'] = 'catboost'
    
    # 保存结果到带时间戳的目录
    save_results(al_results, catboost_output_dir, 'catboost_active_learning_results.json')
    
    # 同时保存一份配置副本
    config_copy_path = os.path.join(catboost_output_dir, 'config_used.yaml')
    with open(config_copy_path, 'w', encoding='utf-8') as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True)
    logger.info(f"配置已保存到: {config_copy_path}")

    # =============================================================================
    # A 因子写回：保存优化后的机理
    # =============================================================================
    logger.info("\n" + "=" * 60)
    logger.info("保存优化后的机理...")
    logger.info("=" * 60)
    
    # 获取最优 logA 值
    final_logA = np.array(al_results['final_solution']['logA'])
    
    # 创建 MechanismWriter 并写回
    writer = MechanismWriter(mech_path, output_dir=catboost_output_dir)
    output_mech_path = writer.write_optimized(
        reaction_indices=reaction_indices,
        logA_values=final_logA,
        metadata={
            'optimization_type': 'active_learning_catboost',
            'final_validation_error': al_results['final_solution']['validation_error'],
            'idt_max_error': al_results['final_solution'].get('idt_max_relative_error', 0.0),
            'lfs_max_error': al_results['final_solution'].get('lfs_max_relative_error', 0.0),
            'total_iterations': al_results['final_solution'].get('best_iteration', 1),
            'convergence_type': al_results['final_solution'].get('convergence_type', 'unknown'),
            'alpha': final_alpha,
            'lambda_reg': lambda_reg,
        }
    )
    
    logger.info(f"优化机理已保存：{output_mech_path}")
    logger.info(f"  - 验证误差：{al_results['final_solution']['validation_error']:.4f}")
    logger.info(f"  - IDT 最大误差：{al_results['final_solution']['idt_max_relative_error']:.4f}")
    if use_lfs:
        logger.info(f"  - LFS 最大误差：{al_results['final_solution']['lfs_max_relative_error']:.4f}")
    logger.info(f"  - 修改反应数：{len(reaction_indices)}")
    logger.info(f"  - 总迭代次数：{al_results['final_solution'].get('best_iteration', 1)}")
    
    # 更新结果字典
    al_results['optimized_mechanism_path'] = output_mech_path
    

    logger.info("主动学习优化完成 (CatBoost)!")
    logger.info("=" * 60)
    logger.info(f"总耗时: {total_time/60:.1f} 分钟")
    logger.info(f"收敛: {al_results['converged']}")
    logger.info(f"最终验证误差: {al_results['final_solution']['validation_error']:.4f}")
    
    return al_results


def main():
    parser = argparse.ArgumentParser(description='Active Learning GA Optimization with CatBoost')
    parser.add_argument('-c', '--config', default='config/ga_config_10percent.yaml',
                        help='配置文件路径')
    parser.add_argument('--skip-lfs', action='store_true',
                        help='跳过LFS验证')
    parser.add_argument('--idt-only', action='store_true',
                        help='仅使用IDT模型')
    parser.add_argument('--alpha', type=float, default=None,
                        help='IDT/LFS权重平衡系数')
    args = parser.parse_args()
    
    config = load_config(args.config)
    results = run_active_learning(config, skip_lfs=args.skip_lfs, 
                                   idt_only=args.idt_only, alpha=args.alpha)


if __name__ == "__main__":
    main()