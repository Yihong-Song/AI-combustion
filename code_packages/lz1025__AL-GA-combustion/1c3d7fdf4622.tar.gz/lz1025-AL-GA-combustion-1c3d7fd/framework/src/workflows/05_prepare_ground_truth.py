# =============================================================================
# src/workflows/05_prepare_ground_truth.py
# =============================================================================
# 工作流步骤 5/9: 准备Ground Truth参考数据
# =============================================================================
#
# 功能：
#   - 从test_ai项目提取IDT详细机理计算结果
#   - 从test_ai项目提取LFS实验测量数据
#   - 生成Ground Truth参考值用于优化验证
#
# 核心函数：
#   - load_detailed_mech_results(): 加载详细机理结果
#   - compute_idt_ensemble(): 计算IDT ensemble平均值
#   - prepare_idt_ground_truth(): 准备IDT Ground Truth
#   - prepare_lfs_ground_truth(): 准备LFS Ground Truth
#
# 输入文件：
#   - test_ai/results/calc_Dong*.csv: Dong机理IDT结果
#   - test_ai/results/calc_Pratali*.csv: Pratali机理IDT结果
#   - test_ai/data/experimental/experimental_template*.csv: LFS实验数据
#
# 输出文件：
#   - data/ground_truth/idt_det_reference.csv: IDT详细机理参考值
#     （包含：T, P, phi, X_NH3, X_H2, X_C7, reference_idt）
#   - data/ground_truth/lfs_exp_reference.csv: LFS实验参考值
#     （包含：T_u, P, phi, X_NH3, X_H2, X_C7, reference_lfs）
#
# 使用方法：
#   python src/workflows/05_prepare_ground_truth.py
#   python src/workflows/05_prepare_ground_truth.py --test-ai-dir path/to/test_ai
#
# 数据来源：
#   - IDT: 详细机理（Dong 2022 + Pratali 2023）ensemble平均
#   - LFS: 实验测量值（Miller 1984, 1985等）
#
# 前置步骤：
#   - test_ai项目需先完成详细机理计算
#
# 后续步骤：
#   - 06_lambda_selection.py: Lambda选择
#   - 07_active_learning_ga.py: 主动学习优化
#
# =============================================================================
# -*- coding: utf-8 -*-



import os
import sys
import argparse
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

OUTPUT_DIR = "data/ground_truth"


def find_latest_file(directory: str, pattern_prefix: str) -> str:
    """查找目录下最新的匹配文件"""
    if not os.path.exists(directory):
        return None
    
    files = [f for f in os.listdir(directory) if f.startswith(pattern_prefix)]
    if not files:
        return None
    
    latest = max(files, key=lambda f: os.path.getmtime(os.path.join(directory, f)))
    return os.path.join(directory, latest)


def load_detailed_mech_results(test_ai_dir: str):
    """加载详细机理计算结果"""
    results_dir = os.path.join(test_ai_dir, "results")
    
    if not os.path.exists(results_dir):
        raise FileNotFoundError(f"Results directory not found: {results_dir}")
    
    dong_path = find_latest_file(results_dir, "calc_Dong")
    pratali_path = find_latest_file(results_dir, "calc_Pratali")
    
    if dong_path is None:
        raise FileNotFoundError(f"Dong result file not found in {results_dir}")
    if pratali_path is None:
        raise FileNotFoundError(f"Pratali result file not found in {results_dir}")
    
    print(f"  Loading Dong: {os.path.basename(dong_path)}")
    print(f"  Loading Pratali: {os.path.basename(pratali_path)}")
    
    dong_df = pd.read_csv(dong_path)
    pratali_df = pd.read_csv(pratali_path)
    
    return dong_df, pratali_df

def compute_idt_ensemble(dong_df, pratali_df):
    """计算IDT ensemble平均值"""
    merged = dong_df.merge(
        pratali_df[['condition_id', 'simulated_value']], 
        on='condition_id', 
        suffixes=('_dong', '_pratali')
    )
    
    merged = merged[merged['status'] == 'success'].copy()
    
    merged['simulated_value_dong'] = pd.to_numeric(merged['simulated_value_dong'], errors='coerce')
    merged['simulated_value_pratali'] = pd.to_numeric(merged['simulated_value_pratali'], errors='coerce')
    
    valid_mask = merged['simulated_value_dong'].notna() & merged['simulated_value_pratali'].notna()
    merged = merged[valid_mask].copy()
    
    merged['reference_idt'] = (merged['simulated_value_dong'] + merged['simulated_value_pratali']) / 2
    
    return merged

def prepare_idt_ground_truth(ensemble_df):
    """准备IDT ground truth文件
    
    列名说明:
    - X_NH3: 氨的摩尔分数
    - X_H2: 氢的摩尔分数
    - X_C7: 正庚烷的摩尔分数
    """
    idt_gt = ensemble_df[['condition_id', 'temperature', 'pressure', 
                          'equivalence_ratio', 'fuel_NH3', 'fuel_H2', 'fuel_C7',
                          'reference_idt']].copy()
    
    idt_gt.columns = ['condition_id', 'T', 'P', 'phi', 'X_NH3', 'X_H2', 'X_C7', 'reference_idt']
    
    idt_gt['P_bar'] = idt_gt['P'] / 1e5
    idt_gt['T_inv'] = 1000.0 / idt_gt['T']
    idt_gt['logP'] = np.log10(idt_gt['P_bar'])
    
    return idt_gt

def load_lfs_experimental(test_ai_dir: str):
    """加载LFS实验数据"""
    exp_dir = os.path.join(test_ai_dir, "data", "experimental")
    
    if not os.path.exists(exp_dir):
        raise FileNotFoundError(f"Experimental directory not found: {exp_dir}")
    
    exp_path = find_latest_file(exp_dir, "experimental_template")
    
    if exp_path is None:
        raise FileNotFoundError(f"Experimental template file not found in {exp_dir}")
    
    print(f"  Loading: {os.path.basename(exp_path)}")
    
    encodings = ['utf-8', 'gbk', 'gb2312']
    exp_df = None
    
    for enc in encodings:
        try:
            with open(exp_path, 'r', encoding=enc) as f:
                lines = f.readlines()
            
            data_start = 0
            for i, line in enumerate(lines):
                if 'condition_id,target_type' in line:
                    data_start = i
                    break
            
            exp_df = pd.read_csv(exp_path, skiprows=data_start, encoding=enc)
            break
        except UnicodeDecodeError:
            continue
    
    if exp_df is None:
        raise RuntimeError(f"Failed to read {exp_path} with any encoding")
    
    lfs_exp = exp_df[exp_df['target_type'] == 'LFS'].copy()
    
    return lfs_exp

def prepare_lfs_ground_truth(lfs_exp):
    """准备LFS ground truth文件
    
    列名说明:
    - X_NH3: 氨的摩尔分数
    - X_H2: 氢的摩尔分数
    - X_C7: 正庚烷的摩尔分数
    """
    lfs_gt = lfs_exp[['condition_id', 'temperature', 'pressure', 
                      'equivalence_ratio', 'fuel_NH3', 'fuel_H2', 'fuel_C7',
                      'experimental_value']].copy()
    
    lfs_gt.columns = ['condition_id', 'T_u', 'P', 'phi', 'X_NH3', 'X_H2', 'X_C7', 'reference_lfs']
    
    lfs_gt['P_bar'] = lfs_gt['P'] / 1e5
    lfs_gt['T_inv'] = 1000.0 / lfs_gt['T_u']
    lfs_gt['logP'] = np.log10(lfs_gt['P_bar'])
    
    # reference_lfs_ms 是 reference_lfs 的副本，两者单位均为 m/s
    # experimental_value 来源：实验测量值，单位已经是 m/s
    # 典型范围：0.089~0.33 m/s (NH3/H2 火焰速度 8.9~33 cm/s)
    lfs_gt['reference_lfs_ms'] = lfs_gt['reference_lfs']
    
    return lfs_gt

def main():
    parser = argparse.ArgumentParser(description='Extract Ground Truth data from test_ai project')
    parser.add_argument('--test-ai-dir', default=r"D:\Codes\test_ai",
                       help='Path to test_ai project directory')
    parser.add_argument('--output-dir', default='data/ground_truth',
                       help='Output directory for ground truth files')
    args = parser.parse_args()
    
    test_ai_dir = args.test_ai_dir
    output_dir = args.output_dir
    
    print("=" * 60)
    print("提取 Ground Truth 数据")
    print(f"test_ai dir: {test_ai_dir}")
    print("=" * 60)
    
    os.makedirs(output_dir, exist_ok=True)
    
    print("\n1. 加载详细机理IDT计算结果...")
    dong_df, pratali_df = load_detailed_mech_results(test_ai_dir)
    print(f"   Dong: {len(dong_df)} 条")
    print(f"   Pratali: {len(pratali_df)} 条")
    
    print("\n2. 计算IDT ensemble平均值...")
    ensemble_df = compute_idt_ensemble(dong_df, pratali_df)
    print(f"   有效工况: {len(ensemble_df)} 条")
    
    idt_gt = prepare_idt_ground_truth(ensemble_df)
    idt_path = os.path.join(output_dir, "idt_det_reference.csv")
    idt_gt.to_csv(idt_path, index=False)
    print(f"   保存: {idt_path}")
    
    print("\n3. 加载LFS实验数据...")
    lfs_exp = load_lfs_experimental(test_ai_dir)
    print(f"   LFS实验点: {len(lfs_exp)} 条")
    
    lfs_gt = prepare_lfs_ground_truth(lfs_exp)
    lfs_path = os.path.join(output_dir, "lfs_exp_reference.csv")
    lfs_gt.to_csv(lfs_path, index=False)
    print(f"   保存: {lfs_path}")
    
    print("\n" + "=" * 60)
    print("Ground Truth 数据提取完成")
    print("=" * 60)
    print(f"IDT工况: {len(idt_gt)} 条")
    print(f"LFS工况: {len(lfs_gt)} 条")
    
    print("\nIDT参考值统计:")
    print(f"  范围: {idt_gt['reference_idt'].min():.2e} ~ {idt_gt['reference_idt'].max():.2e} s")
    
    print("\nLFS参考值统计:")
    print(f"  范围: {lfs_gt['reference_lfs_ms'].min():.4f} ~ {lfs_gt['reference_lfs_ms'].max():.4f} m/s")

if __name__ == "__main__":
    main()
