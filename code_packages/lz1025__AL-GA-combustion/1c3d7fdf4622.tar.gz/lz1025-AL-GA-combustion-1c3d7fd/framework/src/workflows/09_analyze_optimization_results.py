#!/usr/bin/env python
# =============================================================================
# src/workflows/09_analyze_optimization_results.py
# =============================================================================
# 工作流步骤 9/9: 分析优化结果和A因子演化
# =============================================================================
#
# 功能：
#   - 分析主动学习优化的收敛过程
#   - 分析A因子的演化规律
#   - 生成优化结果报告
#   - 可视化A因子变化趋势
#
# 核心函数：
#   - load_data(): 加载优化结果数据
#   - analyze_logA_evolution(): 分析logA演化规律
#   - generate_report(): 生成分析报告
#
# 输入文件：
#   - output/active_learning/logA_comparison.json: logA对比数据
#   - output/active_learning/convergence_summary.json: 收敛摘要
#   - output/active_learning/reaction_mapping.json: 反应映射
#   - output/active_learning/logA_iter_*.npy: 各迭代logA值
#   - data/top20_indices.json: Top 20反应索引
#
# 输出文件：
#   - output/analysis/A_factor_evolution_report.md: A因子演化报告
#   - output/analysis/A_factor_evolution.csv: A因子演化数据
#   - output/analysis/convergence_plot.png: 收敛曲线图
#   - output/analysis/A_factor_changes.png: A因子变化图
#
# 使用方法：
#   python src/workflows/09_analyze_optimization_results.py output/active_learning
#
# 分析内容：
#   - 收敛速度分析
#   - A因子调整幅度
#   - 敏感反应识别
#   - 优化效率评估
#   - Pareto前沿分析（多目标模式）
#
# 前置步骤：
#   - 07_active_learning_ga.py: 运行主动学习优化
#
# 备注：
#   此为工作流最后一步，用于生成最终分析报告。
#
# =============================================================================
# -*- coding: utf-8 -*-

import numpy as np
import pandas as pd
import json
import glob
import sys
import os
from datetime import datetime

def load_data(output_dir):
    """加载优化数据"""
    print("="*80)
    print("加载优化数据")
    print("="*80)
    
    with open(f'{output_dir}/logA_comparison.json', 'r') as f:
        comparison = json.load(f)
    print(f"[OK] logA_comparison.json")
    
    with open(f'{output_dir}/convergence_summary.json', 'r') as f:
        summary = json.load(f)
    print(f"[OK] convergence_summary.json")
    
    with open(f'{output_dir}/reaction_mapping.json', 'r') as f:
        reactions = json.load(f)
    print(f"[OK] reaction_mapping.json ({len(reactions)} reactions)")
    
    return comparison, summary, reactions

def analyze_logA_evolution(output_dir):
    """分析 A 因子演化规律"""
    print("\n" + "="*80)
    print("A Factor Evolution Analysis")
    print("="*80)
    
    logA_files = sorted(glob.glob(f'{output_dir}/logA_iter*.npy'))
    
    if not logA_files:
        print("No iteration logA files found")
        return
    
    print(f"\nFound {len(logA_files)} iterations")
    
    # Load all iterations
    iterations = []
    for f in logA_files:
        iter_num = int(f.split('_iter')[-1].split('.')[0])
        logA = np.load(f)
        iterations.append({'iter': iter_num, 'logA': logA})
    
    # Load baseline
    try:
        with open(f'{output_dir}/logA_comparison.json', 'r') as f:
            base_logA = np.array(json.load(f)['base_logA'])
    except:
        base_logA = None
    
    # Load reactions
    try:
        with open(f'{output_dir}/reaction_mapping.json', 'r') as f:
            reactions = json.load(f)
    except:
        reactions = None
    
    n_rxn = len(iterations[0]['logA'])
    print(f"\nAnalyzing {len(iterations)} iterations, {n_rxn} reactions")
    
    # Analyze each reaction
    print("\n" + "-"*80)
    print("Reaction-wise A-factor Evolution")
    print("-"*80)
    
    for idx in range(n_rxn):
        name = reactions[idx]['equation'][:50] if reactions else f"Rx{idx}"
        evo = np.array([it['logA'][idx] for it in iterations])
        
        if base_logA is not None:
            base = base_logA[idx]
            delta = evo[-1] - base
            ratio = 10**evo[-1] / 10**base
        else:
            base = delta = ratio = None
        
        if len(evo) > 1:
            trend = "increase" if evo[-1] > evo[0] else "decrease" if evo[-1] < evo[0] else "stable"
            vol = np.std(evo)
            diffs = np.diff(evo)
            mono = "monotonic+" if np.all(diffs>0) else "monotonic-" if np.all(diffs<0) else "non-monotonic"
        else:
            trend = "single"; vol = 0; mono = "N/A"
        
        print(f"\nReaction {idx}: {name}")
        if base is not None: print(f"  Base: {base:.3f}")
        print(f"  Initial: {evo[0]:.3f}, Final: {evo[-1]:.3f}")
        if delta is not None: print(f"  Delta: {delta:+.3f} ({ratio:.2f}x)")
        print(f"  Trend: {trend}, Volatility: {vol:.3f}, Pattern: {mono}")
        
        evo_str = " -> ".join([f"{v:.2f}" for v in evo[:6]])
        if len(evo) > 6: evo_str += f" -> {evo[-1]:.2f}"
        print(f"  Sequence: {evo_str}")
    
    # Generate report
    print("\n" + "="*80)
    print("Generate Report")
    print("="*80)
    
    report = ["# A-Factor Evolution Report"]
    report.append(f"\nGenerated: {datetime.now().isoformat()}")
    report.append(f"Iterations: {len(iterations)}")
    report.append(f"Reactions: {n_rxn}")
    
    if base_logA is not None:
        final = iterations[-1]['logA']
        delta = final - base_logA
        top10 = np.argsort(np.abs(delta))[-10:][::-1]
        
        report.append("\n## Top 10 Changed Reactions")
        for rank, idx in enumerate(top10, 1):
            name = reactions[idx]['equation'][:60] if reactions else f"Rx{idx}"
            report.append(f"\n{rank}. Rx{idx}: {name}")
            report.append(f"   logA: {base_logA[idx]:.3f} -> {final[idx]:.3f} (d={delta[idx]:+.3f}, x={10**final[idx]/10**base_logA[idx]:.2f})")
    
    report.append("\n## Full Data")
    report.append("\n| Rx | Base | Final | Delta | Ratio |")
    report.append("|---|---|---|---|---|")
    
    for idx in range(n_rxn):
        if base_logA is not None:
            b = base_logA[idx]
            f = final[idx]
            d = f - b
            r = 10**f / 10**b
            report.append(f"| {idx} | {b:.3f} | {f:.3f} | {d:+.3f} | {r:.2f}x |")
    
    with open(f'{output_dir}/A_factor_evolution_report.md', 'w') as f:
        f.write('\n'.join(report))
    print(f"[OK] Saved: A_factor_evolution_report.md")
    
    # Save CSV
    data = []
    for idx in range(n_rxn):
        row = {'rx': idx}
        if base_logA is not None:
            row['base'] = base_logA[idx]
        for it in iterations:
            row[f'iter{it["iter"]}'] = it['logA'][idx]
        if base_logA is not None:
            row['delta'] = iterations[-1]['logA'][idx] - base_logA[idx]
            row['ratio'] = 10**iterations[-1]['logA'][idx] / 10**base_logA[idx]
        data.append(row)
    
    pd.DataFrame(data).to_csv(f'{output_dir}/A_factor_evolution.csv', index=False)
    print(f"[OK] Saved: A_factor_evolution.csv")
    
    print("\n[A-Factor Evolution Analysis Complete]")

if __name__ == "__main__":
    output_dir = sys.argv[1] if len(sys.argv) > 1 else 'output/active_learning'
    
    try:
        comp, summ, rxns = load_data(output_dir)
        analyze_logA_evolution(output_dir)
        print("\n" + "="*80)
        print("Analysis Complete")
        print("="*80)
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
