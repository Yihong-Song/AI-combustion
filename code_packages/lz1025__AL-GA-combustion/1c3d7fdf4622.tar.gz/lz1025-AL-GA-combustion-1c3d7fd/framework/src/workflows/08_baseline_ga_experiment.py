#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Baseline GA Experiment - Direct Cantera Evaluation
Purpose: Validate 6.8x acceleration claim through empirical comparison

Difference from AL-GA:
- NO surrogate model (direct Cantera evaluation)
- Simplified 10 generations (vs 80)
- Multiple runs for statistical confidence
"""

import sys
from pathlib import Path

# Add project root to path for imports
project_root = Path(__file__).resolve().parent.parent.parent
sys.path.insert(0, str(project_root))

# Force UTF-8 encoding for Windows compatibility
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

import numpy as np
import pandas as pd
import time
import json
import logging
import random
from typing import List, Tuple, Dict, Any
from concurrent.futures import ProcessPoolExecutor, as_completed

# Import existing modules
from src.core.cantera_validator import (
    validate_idt_batch_parallel,
    validate_lfs_batch_parallel,
    create_modified_solution,
    compute_validation_error
)
from src.core.afactor_manager import AFactorManager
from src.core.objective import compute_log_mse_error

logger = logging.getLogger(__name__)


def create_direct_cantera_evaluation_function(
    mech_path: str,
    reaction_indices: List[int],
    idt_conditions: pd.DataFrame,
    lfs_conditions: pd.DataFrame,
    idt_reference: np.ndarray,
    lfs_reference: np.ndarray,
    logA_base: np.ndarray,
    n_workers: int = 12,
    alpha: float = 0.6,
    lambda_reg: float = 0.0001,
    gamma_idt: float = 0.5,
    gamma_lfs: float = 0.5,
    use_max_error_penalty: bool = True,
    timing_callback: callable = None
) -> callable:
    """
    Create DEAP evaluation function using DIRECT Cantera evaluation (no surrogate).

    Parameters:
        mech_path: Mechanism YAML file path
        reaction_indices: List of 20 reaction indices to optimize
        idt_conditions: IDT condition DataFrame (64 conditions)
        lfs_conditions: LFS condition DataFrame (65 conditions)
        idt_reference: IDT ground truth values (seconds)
        lfs_reference: LFS ground truth values (m/s)
        logA_base: Baseline logA values from AFactorManager
        n_workers: Number of parallel workers for Cantera
        alpha: IDT weight (0.6 = focus on IDT)
        lambda_reg: Regularization coefficient
        gamma_idt: IDT max error penalty coefficient
        gamma_lfs: LFS max error penalty coefficient
        use_max_error_penalty: Whether to apply max error penalty
        timing_callback: Optional callback to record timing per individual

    Returns:
        evaluate: DEAP-compatible evaluation function returning (fitness,)
    """
    n_idt = len(idt_conditions)
    n_lfs = len(lfs_conditions)

    def evaluate(individual: list) -> Tuple[float]:
        """
        DEAP evaluation function: direct Cantera evaluation.
        """
        start_time = time.time()
        logA_array = np.array(individual)

        try:
            # IDT: Parallel Cantera calculation
            idt_results = validate_idt_batch_parallel(
                mech_path, reaction_indices, logA_array,
                idt_conditions, max_time=10.0, n_workers=n_workers
            )

            # LFS: Parallel Cantera calculation
            lfs_results = validate_lfs_batch_parallel(
                mech_path, reaction_indices, logA_array,
                lfs_conditions, max_time=5000.0, max_levels=4,
                n_workers=n_workers
            )

        except Exception as e:
            logger.error(f"Cantera evaluation failed: {e}")
            return (1000.0,)

        # Compute Fitness (Log-MSE)
        idt_valid_mask = np.isfinite(idt_results) & np.isfinite(idt_reference) & (idt_reference > 0)
        lfs_valid_mask = np.isfinite(lfs_results) & np.isfinite(lfs_reference) & (np.abs(lfs_reference) > 1e-30)

        if not np.any(idt_valid_mask):
            logger.warning("No valid IDT results from Cantera")
            return (1000.0,)

        # Log-space MSE for IDT
        log_idt_pred = np.log10(idt_results[idt_valid_mask])
        log_idt_ref = np.log10(idt_reference[idt_valid_mask])
        idt_error = compute_log_mse_error(log_idt_pred, log_idt_ref)

        # Log-space MSE for LFS
        if np.any(lfs_valid_mask):
            log_lfs_pred = np.log10(np.abs(lfs_results[lfs_valid_mask]))
            log_lfs_ref = np.log10(np.abs(lfs_reference[lfs_valid_mask]))
            lfs_error = compute_log_mse_error(log_lfs_pred, log_lfs_ref)
        else:
            lfs_error = 0.0

        # Weighted combination
        total_error = alpha * idt_error + (1 - alpha) * lfs_error

        # Regularization
        reg_term = lambda_reg * np.sum((logA_array - logA_base) ** 2)

        # Max error penalty
        max_error_penalty = 0.0
        if use_max_error_penalty:
            idt_log_errors = np.abs(log_idt_pred - log_idt_ref)
            idt_p95 = np.percentile(idt_log_errors, 95) if len(idt_log_errors) > 0 else 0.0

            if np.any(lfs_valid_mask):
                lfs_log_errors = np.abs(log_lfs_pred - log_lfs_ref)
                lfs_p95 = np.percentile(lfs_log_errors, 95) if len(lfs_log_errors) > 0 else 0.0
            else:
                lfs_p95 = 0.0

            max_error_penalty = gamma_idt * (idt_p95 ** 2) + gamma_lfs * (lfs_p95 ** 2)

        fitness = total_error + reg_term + max_error_penalty

        elapsed_time = time.time() - start_time
        if timing_callback:
            timing_callback(elapsed_time, idt_error, lfs_error)

        logger.debug(f"Fitness: {fitness:.6f}, IDT: {idt_error:.6f}, LFS: {lfs_error:.6f}, Time: {elapsed_time:.1f}s")

        return (fitness,)

    return evaluate


def compute_baseline_metrics(
    idt_results: np.ndarray,
    lfs_results: np.ndarray,
    idt_reference: np.ndarray,
    lfs_reference: np.ndarray
) -> Dict[str, float]:
    """
    Compute P95 and MSRE metrics for baseline comparison.
    """
    metrics = {}

    # IDT metrics
    idt_valid_mask = np.isfinite(idt_results) & np.isfinite(idt_reference) & (idt_reference > 0)
    if np.any(idt_valid_mask):
        log_idt_pred = np.log10(idt_results[idt_valid_mask])
        log_idt_ref = np.log10(idt_reference[idt_valid_mask])
        idt_log_errors = np.abs(log_idt_pred - log_idt_ref)

        metrics['idt_p95_percent'] = float(np.percentile(idt_log_errors, 95) * 100 / np.log10(2))
        metrics['idt_msre'] = float(np.mean(idt_log_errors ** 2))
        metrics['idt_valid_count'] = int(np.sum(idt_valid_mask))
    else:
        metrics['idt_p95_percent'] = np.inf
        metrics['idt_msre'] = np.inf
        metrics['idt_valid_count'] = 0

    # LFS metrics
    lfs_valid_mask = np.isfinite(lfs_results) & np.isfinite(lfs_reference) & (np.abs(lfs_reference) > 1e-30)
    if np.any(lfs_valid_mask):
        log_lfs_pred = np.log10(np.abs(lfs_results[lfs_valid_mask]))
        log_lfs_ref = np.log10(np.abs(lfs_reference[lfs_valid_mask]))
        lfs_log_errors = np.abs(log_lfs_pred - log_lfs_ref)

        metrics['lfs_p95_percent'] = float(np.percentile(lfs_log_errors, 95) * 100 / np.log10(2))
        metrics['lfs_msre'] = float(np.mean(lfs_log_errors ** 2))
        metrics['lfs_valid_count'] = int(np.sum(lfs_valid_mask))
    else:
        metrics['lfs_p95_percent'] = np.inf
        metrics['lfs_msre'] = np.inf
        metrics['lfs_valid_count'] = 0

    return metrics


def run_baseline_ga_experiment(
    config_path: str = "config/baseline_ga_config.yaml",
    run_id: int = 1,
    verbose: bool = True
) -> Dict[str, Any]:
    """
    Run single baseline GA experiment.

    Parameters:
        config_path: Configuration YAML file path
        run_id: Run identifier (1, 2, or 3)
        verbose: Whether to print progress

    Returns:
        results: Dictionary containing timing, fitness evolution, and metrics
    """
    import yaml
    import random
    from deap import base, tools

    from src.core.ga_optimizer import setup_toolbox, run_ga_with_callback
    from src.core.afactor_manager import AFactorManager

    # Load configuration
    with open(config_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    # Set random seed for reproducibility
    seeds = config.get('random_seeds', [42, 123, 456])
    seed = seeds[run_id - 1] if run_id <= len(seeds) else seeds[0] + run_id
    random.seed(seed)
    np.random.seed(seed)

    logger.info(f"=== Baseline GA Experiment Run {run_id} ===")
    logger.info(f"Random seed: {seed}")

    # Load mechanism and reaction indices
    mech_path = config['mechanism']['path']
    rxn_indices_file = config['mechanism']['reaction_indices_file']

    with open(rxn_indices_file, 'r', encoding='utf-8') as f:
        reaction_indices = []
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            # Format: "237  NH3 + O2 <=> HO2 + NH2" - extract first number
            parts = line.split()
            if parts:
                try:
                    reaction_indices.append(int(parts[0]))
                except ValueError:
                    continue

    # Get baseline logA from AFactorManager
    afactor_manager = AFactorManager(mech_path, reaction_indices)
    logA_base = afactor_manager.logA_base

    logger.info(f"Baseline logA range: [{logA_base.min():.3f}, {logA_base.max():.3f}]")

    # Load validation conditions
    idt_df = pd.read_csv(config['idt_conditions'], comment='#')
    lfs_df = pd.read_csv(config['lfs_conditions'], comment='#')

    # Extract reference values (in SI units)
    idt_reference = idt_df['reference_idt'].values  # seconds
    lfs_reference = lfs_df['reference_lfs'].values  # m/s

    logger.info(f"Conditions: IDT={len(idt_df)}, LFS={len(lfs_df)}, Total={len(idt_df)+len(lfs_df)}")

    # Create bounds (logA_base +/- 1.0)
    bounds = [(val - 1.0, val + 1.0) for val in logA_base]

    # Timing tracking
    timing_records = {
        'individual_times': [],
        'generation_times': [],
        'total_start': time.time()
    }

    def timing_callback(elapsed_time, idt_error, lfs_error):
        """Record timing for each individual evaluation."""
        timing_records['individual_times'].append({
            'time': elapsed_time,
            'idt_error': idt_error,
            'lfs_error': lfs_error
        })

    # Create direct Cantera evaluation function
    ga_config = config['genetic_algorithm']
    n_workers = config.get('parallel_workers', 12)

    evaluate_fn = create_direct_cantera_evaluation_function(
        mech_path=mech_path,
        reaction_indices=reaction_indices,
        idt_conditions=idt_df,
        lfs_conditions=lfs_df,
        idt_reference=idt_reference,
        lfs_reference=lfs_reference,
        logA_base=logA_base,
        n_workers=n_workers,
        alpha=config['objective']['alpha'],
        lambda_reg=config['objective']['lambda_reg'],
        gamma_idt=config['objective']['gamma_idt'],
        gamma_lfs=config['objective']['gamma_lfs'],
        use_max_error_penalty=config['objective']['use_max_error_penalty'],
        timing_callback=timing_callback
    )

    # Setup DEAP toolbox
    toolbox = setup_toolbox(bounds, evaluate_fn, ga_config, logA_base)

    # Fitness evolution tracking
    fitness_evolution = []

    def generation_callback(gen, best_ind, best_fitness):
        """Record fitness after each generation."""
        gen_time = time.time() - timing_records['total_start']
        if len(timing_records['generation_times']) > 0:
            gen_elapsed = gen_time - timing_records['generation_times'][-1]
        else:
            gen_elapsed = gen_time

        timing_records['generation_times'].append(gen_time)

        fitness_evolution.append({
            'generation': gen,
            'best_fitness': float(best_fitness),
            'generation_time': gen_elapsed,
            'cumulative_time': gen_time
        })

        if verbose and gen % 1 == 0:
            logger.info(f"Gen {gen}: best={best_fitness:.6f}, time={gen_elapsed:.1f}s, cumulative={gen_time:.1f}s")

    # Run GA
    logger.info(f"Starting GA: pop={ga_config['population_size']}, gen={ga_config['n_generations']}")

    best_ind, best_fitness, history = run_ga_with_callback(
        toolbox, ga_config,
        callback=generation_callback,
        verbose=verbose
    )

    total_time = time.time() - timing_records['total_start']

    # Final evaluation of best individual
    logger.info("Final evaluation of best individual...")
    best_logA = np.array(best_ind)

    idt_final = validate_idt_batch_parallel(
        mech_path, reaction_indices, best_logA,
        idt_df, max_time=10.0, n_workers=n_workers
    )
    lfs_final = validate_lfs_batch_parallel(
        mech_path, reaction_indices, best_logA,
        lfs_df, max_time=5000.0, max_levels=4,
        n_workers=n_workers
    )

    final_metrics = compute_baseline_metrics(idt_final, lfs_final, idt_reference, lfs_reference)

    # Compile results
    results = {
        'run_id': run_id,
        'seed': seed,
        'config': {
            'population_size': ga_config['population_size'],
            'n_generations': ga_config['n_generations'],
            'n_workers': n_workers,
            'n_conditions_idt': len(idt_df),
            'n_conditions_lfs': len(lfs_df)
        },
        'timing': {
            'total_wall_time_seconds': total_time,
            'per_generation_times': [e['generation_time'] for e in fitness_evolution],
            'avg_generation_time': np.mean([e['generation_time'] for e in fitness_evolution[1:]]),
            'avg_evaluation_time_ms': np.mean([t['time'] * 1000 for t in timing_records['individual_times']]),
            'total_cantera_calls': ga_config['population_size'] * ga_config['n_generations']
        },
        'fitness_evolution': fitness_evolution,
        'final_result': {
            'best_fitness': float(best_fitness),
            'best_logA': best_logA.tolist(),
            'idt_p95_percent': final_metrics['idt_p95_percent'],
            'lfs_p95_percent': final_metrics['lfs_p95_percent'],
            'idt_msre': final_metrics['idt_msre'],
            'lfs_msre': final_metrics['lfs_msre']
        }
    }

    logger.info(f"=== Run {run_id} Complete ===")
    logger.info(f"Total time: {total_time:.1f}s ({total_time/3600:.2f}h)")
    logger.info(f"Best fitness: {best_fitness:.6f}")
    logger.info(f"IDT P95: {final_metrics['idt_p95_percent']:.2f}%")
    logger.info(f"LFS P95: {final_metrics['lfs_p95_percent']:.2f}%")

    return results


def save_experiment_results(results: Dict, output_dir: str, run_id: int):
    """Save experiment results to JSON and CSV files."""
    output_path = Path(output_dir) / f"run_{run_id}"
    output_path.mkdir(parents=True, exist_ok=True)

    # Save timing log
    with open(output_path / "timing_log.json", 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, default=str)

    # Save fitness evolution as CSV
    fitness_df = pd.DataFrame(results['fitness_evolution'])
    fitness_df.to_csv(output_path / "fitness_evolution.csv", index=False)

    # Save final population logA values
    logA_df = pd.DataFrame({
        'reaction_idx': range(1, 21),
        'logA_final': results['final_result']['best_logA']
    })
    logA_df.to_csv(output_path / "best_logA.csv", index=False)

    logger.info(f"Results saved to {output_path}")


def main():
    """Main entry point for baseline GA experiment."""
    import argparse

    parser = argparse.ArgumentParser(description="Baseline GA Experiment")
    parser.add_argument('-c', '--config', default='config/baseline_ga_config.yaml',
                        help='Configuration file path')
    parser.add_argument('--run-id', type=int, default=1,
                        help='Run identifier (1, 2, or 3)')
    parser.add_argument('-v', '--verbose', action='store_true',
                        help='Verbose output')
    args = parser.parse_args()

    # Setup logging
    logging.basicConfig(
        level=logging.INFO if args.verbose else logging.WARNING,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )

    # Run experiment
    results = run_baseline_ga_experiment(
        config_path=args.config,
        run_id=args.run_id,
        verbose=args.verbose
    )

    # Save results
    save_experiment_results(
        results,
        output_dir="output/baseline_ga",
        run_id=args.run_id
    )

    return results


if __name__ == '__main__':
    main()
