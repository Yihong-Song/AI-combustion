# =============================================================================
# src/workflows/01_generate_conditions.py
# =============================================================================
# 工作流步骤 1/9: 生成机理变体参数和工况矩阵
# =============================================================================
# 
# 功能：
#   - 加载基线机理文件并提取Top 20关键反应的A因子
#   - 使用Sobol序列生成机理变体参数（logA扰动）
#   - 生成IDT（点火延迟时间）和LFS（层流火焰速度）计算工况矩阵
#   - 工况矩阵采用混合策略：实验锚定点 + Sobol全局采样
#
# 核心函数：
#   - run_generate_conditions(): 主流程函数
#   - save_variant_params(): 保存变体参数（JSON/CSV）
#   - save_conditions(): 保存工况矩阵
#
# 输入文件：
#   - config/config.yaml: 主配置文件
#   - 02-Reduced-Wang_fuel_2023.yaml: 基线机理文件
#   - data/top20_indices.json: Top 20反应索引
#   - data/experimental_anchors/: 实验锚定点数据
#
# 输出文件：
#   - output/conditions/variant_params_TIMESTAMP.json: 变体参数（JSON）
#   - output/conditions/variant_params_TIMESTAMP.csv: 变体参数（CSV）
#   - output/conditions/idt_conditions_TIMESTAMP.csv: IDT工况矩阵
#   - output/conditions/lfs_conditions_TIMESTAMP.csv: LFS工况矩阵
#   - output/conditions/summary_TIMESTAMP.json: 生成摘要
#
# 使用方法：
#   python src/workflows/01_generate_conditions.py -c config/config.yaml
#
# 后续步骤：
#   - 02_optimize_conditions.py: 工况去重
#   - 03_run_compute.py: 执行计算
#
# =============================================================================
# -*- coding: utf-8 -*-


import os
import sys
import json
import logging
from datetime import datetime

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from src.core.config_loader import load_config_with_override, load_top20_indices
from src.core.config_validator import ConfigValidator, ConfigValidationError
from src.core.variant_generator import (
    load_mechanism,
    validate_top20_indices,
    extract_top20_A,
    generate_sobol_perturbations,
    calc_log10A_matrix,
    prepare_variant_params
)
from src.core.condition_generator import (
    generate_idt_conditions,
    generate_lfs_conditions,
    generate_sobol_conditions,
    load_experimental_anchors,
    build_hybrid_idt_matrix,
    build_hybrid_idt_matrix_global,
    build_hybrid_lfs_matrix,
    build_hybrid_lfs_matrix_clustered
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    encoding='utf-8'
)
logger = logging.getLogger(__name__)

# 生成时间戳
# -*- coding: utf-8 -*-

TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

OUTPUT_DIR = "output/conditions"
OUTPUT_VARIANT_JSON = f"{OUTPUT_DIR}/variant_params_{TIMESTAMP}.json"
OUTPUT_VARIANT_CSV = f"{OUTPUT_DIR}/variant_params_{TIMESTAMP}.csv"
OUTPUT_IDT_CONDITIONS = f"{OUTPUT_DIR}/idt_conditions_{TIMESTAMP}.csv"
OUTPUT_LFS_CONDITIONS = f"{OUTPUT_DIR}/lfs_conditions_{TIMESTAMP}.csv"
OUTPUT_SUMMARY = f"{OUTPUT_DIR}/summary_{TIMESTAMP}.json"


def save_variant_params(variant_params, file_json, file_csv):
    """保存变体参数"""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # 转换为JSON可序列化的格式
    json_params = []
    for vp in variant_params:
        json_vp = {
            'variant_id': vp['variant_id'],
            'reaction_indices': vp['reaction_indices'],
            'A_values': [float(x) for x in vp['A_values']],
            'log10A_values': [float(x) for x in vp['log10A_values']]
        }
        json_params.append(json_vp)
    
    # 保存JSON
    with open(file_json, 'w') as f:
        json.dump(json_params, f, indent=2)
    logger.info(f"变体参数已保存: {file_json}")
    
    # 保存CSV
    df = pd.DataFrame(json_params)
    df.to_csv(file_csv, index=False)
    logger.info(f"变体参数已保存: {file_csv}")


def save_conditions(idt_df, lfs_df, idt_file, lfs_file):
    """保存工况矩阵"""
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    idt_df.to_csv(idt_file, index=False)
    logger.info(f"IDT工况已保存: {idt_file} ({len(idt_df)} 条)")
    
    lfs_df.to_csv(lfs_file, index=False)
    logger.info(f"LFS工况已保存: {lfs_file} ({len(lfs_df)} 条)")


def run_generate_conditions(config_path: str = 'config/config.yaml'):
    """
    阶段1: 生成工况矩阵
    
    参数:
        config_path: 配置文件路径
    """
    logger.info("=" * 70)
    logger.info("阶段1: 生成工况矩阵")
    logger.info("=" * 70)
    
    config = load_config_with_override(config_path)
    
    # 配置验证
    try:
        ConfigValidator.validate(config)
    except ConfigValidationError as e:
        logger.error(str(e))
        raise
    
    var_config = config['variant_generation']
    mech_file = var_config['mechanism_file']
    top20_file = var_config['top20_indices_file']
    uncertainty_factor = var_config['uncertainty_factor']
    n_variants = var_config['n_variants']
    random_seed = var_config.get('random_seed', None)
    
    logger.info(f"机理文件: {mech_file}")
    logger.info(f"变体数量: {n_variants}")
    logger.info(f"不确定性因子: {uncertainty_factor}")
    logger.info(f"随机种子：{random_seed}")
    
    # 文件存在性检查
    if not os.path.exists(mech_file):
        logger.error(f"机理文件不存在: {mech_file}")
        return
    
    if not os.path.exists(top20_file):
        logger.error(f"Top20索引文件不存在: {top20_file}")
        return
    
    logger.info("Step 1: 加载机理并提取Top 20 A值")
    base_solution = load_mechanism(mech_file)
    raw_top20_indices = load_top20_indices(top20_file)
    valid_indices, invalid_indices = validate_top20_indices(base_solution, raw_top20_indices)
    
    if len(valid_indices) == 0:
        logger.error("没有有效的反应索引!")
        return
    
    top20_indices = valid_indices
    base_A, _ = extract_top20_A(base_solution, top20_indices)
    logger.info(f"有效Top {len(top20_indices)}反应索引: {top20_indices}")
    
    logger.info("Step 2: 生成Sobol扰动矩阵")
    perturbations = generate_sobol_perturbations(n_variants, len(top20_indices), seed=random_seed)
    log10A_matrix = calc_log10A_matrix(base_A, perturbations)
    
    logger.info("Step 3: 准备变体参数")
    variant_params = prepare_variant_params(log10A_matrix, top20_indices)
    
    logger.info("Step 4: 生成工况矩阵")
    exp_anchors = None
    exp_config = config['conditions'].get('experimental_anchors', {})
    if exp_config.get('enabled', False):
        excel_file = exp_config.get('excel_file', '')
        if excel_file and os.path.exists(excel_file):
            try:
                exp_anchors = load_experimental_anchors(excel_file)
                logger.info(f"实验锚点加载成功: {len(exp_anchors)} 条")
            except Exception as e:
                logger.warning(f"实验锚点加载失败: {e}, 将只使用生成的工况")
    
    idt_conditions_df = build_hybrid_idt_matrix_global(
        n_variants, 
        config['conditions']['idt'], 
        exp_anchors if exp_anchors is not None else pd.DataFrame(),
        use_idt_anchors=exp_config.get('use_idt_anchors', False)
    )
    lfs_conditions_df = build_hybrid_lfs_matrix_clustered(
        n_variants, 
        config['conditions']['lfs'], 
        exp_anchors if exp_anchors is not None else pd.DataFrame(),
        use_lfs_anchors=exp_config.get('use_lfs_anchors', True)
    )
    
    logger.info(f"IDT工况总数: {len(idt_conditions_df)}")
    logger.info(f"LFS工况总数: {len(lfs_conditions_df)}")
    
    logger.info("Step 5: 保存结果")
    save_variant_params(variant_params, OUTPUT_VARIANT_JSON, OUTPUT_VARIANT_CSV)
    save_conditions(idt_conditions_df, lfs_conditions_df, OUTPUT_IDT_CONDITIONS, OUTPUT_LFS_CONDITIONS)
    
    summary = {
        'n_variants': n_variants,
        'n_reactions': len(top20_indices),
        'uncertainty_factor': uncertainty_factor,
        'n_idt_conditions': len(idt_conditions_df),
        'n_lfs_conditions': len(lfs_conditions_df),
        'reaction_indices': top20_indices,
        'timestamp': TIMESTAMP,
        'output_files': {
            'variant_params_json': OUTPUT_VARIANT_JSON,
            'variant_params_csv': OUTPUT_VARIANT_CSV,
            'idt_conditions': OUTPUT_IDT_CONDITIONS,
            'lfs_conditions': OUTPUT_LFS_CONDITIONS
        }
    }
    
    with open(OUTPUT_SUMMARY, 'w') as f:
        json.dump(summary, f, indent=2)
    
    logger.info("=" * 70)
    logger.info("阶段1完成! 工况矩阵已生成。")
    logger.info("=" * 70)
    
    return summary


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Phase 1: Generate conditions matrix')
    parser.add_argument('-c', '--config', default='config/config.yaml', help='Config file path')
    args = parser.parse_args()
    run_generate_conditions(args.config)
