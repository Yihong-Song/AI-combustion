"""
Test Sobol perturbation generation for reproducibility and correctness.

These tests verify that generate_sobol_perturbations() produces:
1. Reproducible results with same seed
2. Different results with different seeds
3. Correct output shape
4. Values in valid range [-1, 1]
5. Proper handling of non-power-of-2 sample counts
"""

import numpy as np
import pytest
from src.core.variant_generator import generate_sobol_perturbations


class TestSobolReproducibility:
    """Test suite for Sobol perturbation generation reproducibility."""

    def test_reproducibility_same_seed(self):
        """
        Verify that calling generate_sobol_perturbations with the same seed
        produces identical results.
        
        This test currently FAILS because the seed parameter is not passed
        to the Sobol sampler constructor (bug in variant_generator.py:248).
        """
        n_variants = 256
        n_reactions = 20
        seed = 42
        
        # Generate perturbations twice with same seed
        result1 = generate_sobol_perturbations(n_variants, n_reactions, seed=seed)
        result2 = generate_sobol_perturbations(n_variants, n_reactions, seed=seed)
        
        # Should be identical
        assert np.allclose(result1, result2), (
            f"Same seed {seed} should produce identical results, "
            f"but got different outputs (max diff: {np.max(np.abs(result1 - result2))})"
        )

    def test_different_seeds_different_results(self):
        """
        Verify that calling generate_sobol_perturbations with different seeds
        produces different results.
        
        This test currently FAILS because seeds are not properly utilized.
        """
        n_variants = 256
        n_reactions = 20
        seed1 = 42
        seed2 = 123
        
        # Generate perturbations with different seeds
        result1 = generate_sobol_perturbations(n_variants, n_reactions, seed=seed1)
        result2 = generate_sobol_perturbations(n_variants, n_reactions, seed=seed2)
        
        # Should be different
        assert not np.allclose(result1, result2), (
            f"Different seeds ({seed1} vs {seed2}) should produce different results, "
            f"but got identical outputs"
        )

    def test_output_shape(self):
        """
        Verify that the output shape is (n_variants, n_reactions).
        """
        test_cases = [
            (100, 10),
            (256, 20),
            (512, 15),
            (1000, 25),
        ]
        
        for n_variants, n_reactions in test_cases:
            result = generate_sobol_perturbations(n_variants, n_reactions, seed=42)
            
            expected_shape = (n_variants, n_reactions)
            assert result.shape == expected_shape, (
                f"Expected shape {expected_shape}, got {result.shape} "
                f"for n_variants={n_variants}, n_reactions={n_reactions}"
            )

    def test_output_range(self):
        """
        Verify that all output values are in the range [-1, 1].
        
        The transformation is: perturbations = 2 * samples - 1
        where samples are in [0, 1], so perturbations should be in [-1, 1].
        """
        n_variants = 512
        n_reactions = 20
        
        result = generate_sobol_perturbations(n_variants, n_reactions, seed=42)
        
        # Check all values are in [-1, 1]
        assert np.all(result >= -1.0), (
            f"Found values below -1: min={result.min()}, "
            f"count below -1: {np.sum(result < -1.0)}"
        )
        assert np.all(result <= 1.0), (
            f"Found values above 1: max={result.max()}, "
            f"count above 1: {np.sum(result > 1.0)}"
        )

    def test_power_of_two_handling(self):
        """
        Verify that non-power-of-2 n_variants are handled correctly.
        
        The current implementation has a bug: it uses sampler.random(n_variants)
        directly, which doesn't handle non-power-of-2 counts properly.
        The reference implementation (condition_generator.py:463-474) shows
        the correct approach: use random_base2(m) and slice to desired count.
        
        This test passes currently but may produce suboptimal Sobol sequences
        for non-power-of-2 counts.
        """
        # Test with non-power-of-2 counts
        non_power_of_2_counts = [100, 500, 1000, 1500]
        n_reactions = 20
        
        for n_variants in non_power_of_2_counts:
            result = generate_sobol_perturbations(n_variants, n_reactions, seed=42)
            
            # Should still produce correct shape
            assert result.shape == (n_variants, n_reactions), (
                f"Non-power-of-2 count {n_variants} should produce shape "
                f"({n_variants}, {n_reactions}), got {result.shape}"
            )
            
            # Should still be in valid range
            assert np.all(result >= -1.0) and np.all(result <= 1.0), (
                f"Non-power-of-2 count {n_variants} produced out-of-range values: "
                f"[{result.min()}, {result.max()}]"
            )
