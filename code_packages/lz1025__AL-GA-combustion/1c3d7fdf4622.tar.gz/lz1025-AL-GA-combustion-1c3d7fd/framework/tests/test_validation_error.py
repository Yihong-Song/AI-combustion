"""
Test script for P95 Log Error calculation in compute_validation_error()
Tests: p95_log_error key existence, P95 < Max comparison, edge cases
"""
import sys
import os
import pytest
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.core.cantera_validator import compute_validation_error


class TestValidationErrorP95:
    """Test suite for P95 Log Error calculation in compute_validation_error()"""
    
    def test_p95_calculation_normal(self):
        """Test P95 calculation with 100 samples and 1 outlier
        
        Creates 100 samples where 99 are close to ground truth and 1 is a large outlier.
        Verifies that:
        1. p95_log_error key exists in return dict
        2. P95 < Max Log Error (since outlier affects max but not P95)
        """
        np.random.seed(42)
        n_samples = 100
        
        # Generate ground truth values
        true_values = np.random.uniform(1.0, 10.0, n_samples)
        
        # Generate predictions: 99 close, 1 outlier
        pred_values = true_values.copy()
        pred_values[:99] = true_values[:99] * (1.0 + np.random.uniform(-0.05, 0.05, 99))  # ±5% error
        pred_values[99] = true_values[99] * 10.0  # 10x outlier (900% error)
        
        result = compute_validation_error(pred_values, true_values, error_type='idt', use_log_space=True)
        
        # Check p95_log_error key exists
        assert 'p95_log_error' in result, "Result dict must contain 'p95_log_error' key"
        
        # Check P95 < Max (outlier affects max but not P95)
        assert result['p95_log_error'] < result['max_log_error'], \
            f"P95 ({result['p95_log_error']}) should be less than Max ({result['max_log_error']}) with outlier"
        
        # Check P95 is reasonable (should be close to the ~5% log error)
        expected_p95_log_error = np.log10(1.05)  # ~0.021 for 5% error
        assert abs(result['p95_log_error'] - expected_p95_log_error) < 0.02, \
            f"P95 should be around {expected_p95_log_error}, got {result['p95_log_error']}"
    
    def test_p95_less_than_max(self):
        """General test that P95 is always <= Max Log Error
        
        This is a mathematical property: percentile 95 cannot exceed the maximum.
        """
        np.random.seed(123)
        n_samples = 50
        
        true_values = np.random.uniform(0.5, 20.0, n_samples)
        pred_values = true_values * np.random.uniform(0.8, 1.5, n_samples)  # -20% to +50% error
        
        result = compute_validation_error(pred_values, true_values, error_type='idt', use_log_space=True)
        
        assert 'p95_log_error' in result
        assert result['p95_log_error'] <= result['max_log_error'], \
            f"P95 ({result['p95_log_error']}) must be <= Max ({result['max_log_error']})"
    
    def test_p95_edge_case_small_sample(self):
        """Test edge case with N < 20 samples
        
        Small sample sizes may produce unstable P95 estimates.
        The function should either:
        1. Return a valid P95 value (even if less reliable)
        2. Emit a warning and use fallback
        """
        np.random.seed(456)
        n_samples = 10  # Small sample
        
        true_values = np.random.uniform(1.0, 5.0, n_samples)
        pred_values = true_values * np.random.uniform(0.9, 1.1, n_samples)  # ±10% error
        
        result = compute_validation_error(pred_values, true_values, error_type='idt', use_log_space=True)
        
        # Should still return p95_log_error (even if less meaningful with small N)
        assert 'p95_log_error' in result, "Must return p95_log_error even for small samples"
        assert np.isfinite(result['p95_log_error']), "P95 should be finite for valid small sample"
    
    def test_p95_idt_and_lfs(self):
        """Test that P95 works for both IDT and LFS error types"""
        np.random.seed(789)
        n_samples = 100
        
        true_values = np.random.uniform(1.0, 10.0, n_samples)
        pred_values = true_values * np.random.uniform(0.85, 1.15, n_samples)  # ±15% error
        
        # Test IDT
        result_idt = compute_validation_error(pred_values, true_values, error_type='idt', use_log_space=True)
        assert 'p95_log_error' in result_idt, "IDT must return p95_log_error"
        assert np.isfinite(result_idt['p95_log_error']), "IDT P95 should be finite"
        
        # Test LFS
        result_lfs = compute_validation_error(pred_values, true_values, error_type='lfs', use_log_space=True)
        assert 'p95_log_error' in result_lfs, "LFS must return p95_log_error"
        assert np.isfinite(result_lfs['p95_log_error']), "LFS P95 should be finite"
        
        # Both should give same result for same data (since both use log space)
        assert abs(result_idt['p95_log_error'] - result_lfs['p95_log_error']) < 1e-10, \
            "IDT and LFS should give same P95 for same data"
    
    def test_p95_all_same_values(self):
        """Test edge case where all predictions equal ground truth
        
        When pred == true, all errors should be 0.
        """
        n_samples = 50
        true_values = np.random.uniform(1.0, 10.0, n_samples)
        pred_values = true_values.copy()  # Perfect predictions
        
        result = compute_validation_error(pred_values, true_values, error_type='idt', use_log_space=True)
        
        assert 'p95_log_error' in result
        assert result['p95_log_error'] == 0.0, f"P95 should be 0 for perfect predictions, got {result['p95_log_error']}"
        assert result['max_log_error'] == 0.0, f"Max should be 0 for perfect predictions"
    
    def test_p95_with_negative_values_lfs(self):
        """Test LFS with negative values (relevant for flame speed)
        
        LFS can have negative values, which should be handled by abs() in log space.
        """
        np.random.seed(321)
        n_samples = 100
        
        # LFS can be negative in some cases
        true_values = np.random.uniform(-10.0, 10.0, n_samples)
        true_values = np.where(np.abs(true_values) < 0.1, 0.1, true_values)  # Avoid near-zero
        pred_values = true_values * np.random.uniform(0.9, 1.1, n_samples)
        
        result = compute_validation_error(pred_values, true_values, error_type='lfs', use_log_space=True)
        
        assert 'p95_log_error' in result, "LFS with negative values must return p95_log_error"
        assert np.isfinite(result['p95_log_error']), "P95 should be finite for LFS with negative values"
