"""
Test script for LFS subprocess timeout implementation
Tests: 1) Normal computation  2) Timeout protection
"""
import sys
import os
import json
import time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.compute_worker import compute_lfs_subprocess

def create_test_task():
    """Create a simple test task"""
    return {
        'task_type': 'LFS',
        'variant_id': 0,
        'A_values': [1.0] * 20,
        'log10A_values': [0.0] * 20,
        'reaction_indices': list(range(311, 331)),
        'mech_path': '02-Reduced-Wang_fuel_2023.yaml',
        'condition': {
            'temperature': 298,
            'pressure': 101325,
            'phi': 1.0,
            'fuel_composition': {'H2': 1.0},
            'oxidizer_composition': {'O2': 0.5, 'N2': 1.88}
        },
        'lfs_config': {
            'domain_width': 0.02,
            'max_grid_points': 5000,
            'max_levels': 4,
            'max_time': 1200,
            'convergence_threshold': 0.01,
            'auto': False,
            'loglevel': 0,
            'subprocess_timeout': 300
        }
    }

def test_normal_computation():
    """Test normal LFS computation"""
    print("=" * 60)
    print("Test 1: Normal LFS Computation")
    print("=" * 60)
    
    task = create_test_task()
    print(f"Task: variant_id={task['variant_id']}, T={task['condition']['temperature']}K, P={task['condition']['pressure']/1e5:.1f}bar")
    
    start = time.time()
    lfs, grid_points = compute_lfs_subprocess(task)
    elapsed = time.time() - start
    
    print(f"Result: LFS={lfs:.4f} m/s, grid_points={grid_points}")
    print(f"Time: {elapsed:.2f}s")
    
    if not np.isnan(lfs) and grid_points > 0:
        print("PASS: Normal computation successful")
        return True
    else:
        print("FAIL: Normal computation returned invalid result")
        return False

def test_timeout():
    """Test timeout protection"""
    print("\n" + "=" * 60)
    print("Test 2: Timeout Protection (1 second timeout)")
    print("=" * 60)
    
    task = create_test_task()
    task['lfs_config']['subprocess_timeout'] = 1  # Very short timeout
    task['condition']['temperature'] = 298  # Difficult condition
    task['condition']['phi'] = 0.6  # Extreme equivalence ratio
    
    print(f"Task: variant_id={task['variant_id']}, T={task['condition']['temperature']}K, phi={task['condition']['phi']}")
    print("Expected: Timeout after ~1 second")
    
    start = time.time()
    lfs, grid_points = compute_lfs_subprocess(task)
    elapsed = time.time() - start
    
    print(f"Result: LFS={lfs}, grid_points={grid_points}")
    print(f"Time: {elapsed:.2f}s")
    
    if np.isnan(lfs) and 0.9 < elapsed < 5:
        print("PASS: Timeout protection works correctly")
        return True
    else:
        print(f"FAIL: Expected timeout, got LFS={lfs}, time={elapsed:.2f}s")
        return False

if __name__ == "__main__":
    print("LFS Subprocess Timeout Test Suite")
    print("=" * 60)
    
    results = []
    
    # Run test 1 - normal computation
    results.append(("Normal Computation", test_normal_computation()))
    
    # Run test 2 - timeout protection
    results.append(("Timeout Protection", test_timeout()))
    
    # Summary
    print("\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    for name, passed in results:
        status = "PASS" if passed else "FAIL"
        print(f"  {name}: {status}")
    
    all_passed = all(r[1] for r in results)
    print(f"\nOverall: {'ALL TESTS PASSED' if all_passed else 'SOME TESTS FAILED'}")
    sys.exit(0 if all_passed else 1)
