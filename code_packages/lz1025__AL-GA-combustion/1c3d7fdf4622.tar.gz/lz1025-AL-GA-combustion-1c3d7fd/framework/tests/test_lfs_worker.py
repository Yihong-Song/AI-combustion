"""
Test script for LFS worker reaction modification functions
Tests: modify_reaction_A_flexible() for different reaction types
"""
import sys
import os
import pytest
import cantera as ct
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.core._lfs_worker import modify_reaction_A_flexible


class TestLfsWorker:
    """Test suite for modify_reaction_A_flexible function"""
    
    @pytest.fixture
    def gas(self):
        """Create a fresh gas object for each test"""
        return ct.Solution("02-Reduced-Wang_fuel_2023.yaml")
    
    def test_elementary_reaction_modification(self, gas):
        """Test modification of elementary reaction (reaction 237)"""
        rxn_idx = 237  # elementary reaction
        original_A = gas.reaction(rxn_idx).rate.pre_exponential_factor
        new_A = original_A * 2.0
        
        result = modify_reaction_A_flexible(gas, rxn_idx, new_A)
        
        assert result is True, "Modification should succeed"
        modified_A = gas.reaction(rxn_idx).rate.pre_exponential_factor
        assert abs(modified_A - new_A) / new_A < 1e-10, \
            f"Expected A={new_A}, got A={modified_A}"
    
    def test_elementary_reaction_different_ratio(self, gas):
        """Test elementary reaction with different modification ratio"""
        rxn_idx = 171  # another elementary reaction
        original_A = gas.reaction(rxn_idx).rate.pre_exponential_factor
        new_A = original_A * 0.5  # Reduce by half
        
        result = modify_reaction_A_flexible(gas, rxn_idx, new_A)
        
        assert result is True
        modified_A = gas.reaction(rxn_idx).rate.pre_exponential_factor
        assert abs(modified_A - new_A) / new_A < 1e-10
    
    def test_falloff_reaction_modification(self, gas):
        """Test modification of falloff reaction (reaction 13)
        
        Verifies that both high-P and low-P rate constants are modified
        with the same ratio to maintain consistency.
        """
        rxn_idx = 13  # falloff reaction
        original_rxn = gas.reaction(rxn_idx)
        original_high_A = original_rxn.rate.high_rate.pre_exponential_factor
        original_low_A = original_rxn.rate.low_rate.pre_exponential_factor
        
        # Modify by factor of 2
        new_high_A = original_high_A * 2.0
        expected_low_A = original_low_A * 2.0
        
        result = modify_reaction_A_flexible(gas, rxn_idx, new_high_A)
        
        assert result is True, "Falloff modification should succeed"
        
        modified_rxn = gas.reaction(rxn_idx)
        modified_high_A = modified_rxn.rate.high_rate.pre_exponential_factor
        modified_low_A = modified_rxn.rate.low_rate.pre_exponential_factor
        
        # Verify high-P rate constant
        assert abs(modified_high_A - new_high_A) / new_high_A < 1e-10, \
            f"High-P: Expected A={new_high_A}, got A={modified_high_A}"
        
        # Verify low-P rate constant was modified with same ratio
        assert abs(modified_low_A - expected_low_A) / expected_low_A < 1e-10, \
            f"Low-P: Expected A={expected_low_A}, got A={modified_low_A}"
    
    def test_falloff_reaction_reduce(self, gas):
        """Test falloff reaction with reduction (ratio < 1)"""
        rxn_idx = 26  # another falloff reaction
        original_rxn = gas.reaction(rxn_idx)
        original_high_A = original_rxn.rate.high_rate.pre_exponential_factor
        original_low_A = original_rxn.rate.low_rate.pre_exponential_factor
        
        # Reduce by factor of 0.3
        new_high_A = original_high_A * 0.3
        expected_low_A = original_low_A * 0.3
        
        result = modify_reaction_A_flexible(gas, rxn_idx, new_high_A)
        
        assert result is True
        
        modified_rxn = gas.reaction(rxn_idx)
        modified_high_A = modified_rxn.rate.high_rate.pre_exponential_factor
        modified_low_A = modified_rxn.rate.low_rate.pre_exponential_factor
        
        assert abs(modified_high_A - new_high_A) / new_high_A < 1e-10
        assert abs(modified_low_A - expected_low_A) / expected_low_A < 1e-10
    
    def test_three_body_reaction_modification(self, gas):
        """Test modification of three-body reaction (reaction 31)"""
        rxn_idx = 31  # three-body reaction
        original_A = gas.reaction(rxn_idx).rate.pre_exponential_factor
        new_A = original_A * 1.5
        
        result = modify_reaction_A_flexible(gas, rxn_idx, new_A)
        
        assert result is True, "Three-body modification should succeed"
        modified_A = gas.reaction(rxn_idx).rate.pre_exponential_factor
        assert abs(modified_A - new_A) / new_A < 1e-10, \
            f"Expected A={new_A}, got A={modified_A}"
    
    def test_falloff_reaction_index_10(self, gas):
        """Test another falloff reaction (reaction 10)"""
        rxn_idx = 10  # falloff reaction
        original_rxn = gas.reaction(rxn_idx)
        original_high_A = original_rxn.rate.high_rate.pre_exponential_factor
        original_low_A = original_rxn.rate.low_rate.pre_exponential_factor
        
        new_high_A = original_high_A * 1.8
        expected_low_A = original_low_A * 1.8
        
        result = modify_reaction_A_flexible(gas, rxn_idx, new_high_A)
        
        assert result is True
        
        modified_rxn = gas.reaction(rxn_idx)
        modified_high_A = modified_rxn.rate.high_rate.pre_exponential_factor
        modified_low_A = modified_rxn.rate.low_rate.pre_exponential_factor
        
        assert abs(modified_high_A - new_high_A) / new_high_A < 1e-10
        assert abs(modified_low_A - expected_low_A) / expected_low_A < 1e-10
    
    def test_falloff_reaction_index_56(self, gas):
        """Test another falloff reaction (reaction 56)"""
        rxn_idx = 56  # falloff reaction
        original_rxn = gas.reaction(rxn_idx)
        original_high_A = original_rxn.rate.high_rate.pre_exponential_factor
        original_low_A = original_rxn.rate.low_rate.pre_exponential_factor
        
        new_high_A = original_high_A * 0.7
        expected_low_A = original_low_A * 0.7
        
        result = modify_reaction_A_flexible(gas, rxn_idx, new_high_A)
        
        assert result is True
        
        modified_rxn = gas.reaction(rxn_idx)
        modified_high_A = modified_rxn.rate.high_rate.pre_exponential_factor
        modified_low_A = modified_rxn.rate.low_rate.pre_exponential_factor
        
        assert abs(modified_high_A - new_high_A) / new_high_A < 1e-10
        assert abs(modified_low_A - expected_low_A) / expected_low_A < 1e-10


class TestMultipleReactions:
    """Test modifying multiple reactions simultaneously"""
    
    @pytest.fixture
    def gas(self):
        return ct.Solution("02-Reduced-Wang_fuel_2023.yaml")
    
    def test_modify_multiple_elementary(self, gas):
        """Test modifying multiple elementary reactions"""
        reactions = [237, 171, 177]
        original_A_values = [gas.reaction(idx).rate.pre_exponential_factor 
                            for idx in reactions]
        new_A_values = [A * 2.0 for A in original_A_values]
        
        results = []
        for idx, new_A in zip(reactions, new_A_values):
            results.append(modify_reaction_A_flexible(gas, idx, new_A))
        
        assert all(results), "All modifications should succeed"
        
        for idx, expected_A in zip(reactions, new_A_values):
            actual_A = gas.reaction(idx).rate.pre_exponential_factor
            assert abs(actual_A - expected_A) / expected_A < 1e-10
    
    def test_modify_mixed_reaction_types(self, gas):
        """Test modifying different reaction types together"""
        # Elementary, falloff, three-body
        reactions = [237, 13, 31]
        
        # Get original values
        orig_elem_A = gas.reaction(237).rate.pre_exponential_factor
        orig_falloff_rxn = gas.reaction(13)
        orig_falloff_high_A = orig_falloff_rxn.rate.high_rate.pre_exponential_factor
        orig_falloff_low_A = orig_falloff_rxn.rate.low_rate.pre_exponential_factor
        orig_threebody_A = gas.reaction(31).rate.pre_exponential_factor
        
        # Modify all by factor of 1.5
        modify_reaction_A_flexible(gas, 237, orig_elem_A * 1.5)
        modify_reaction_A_flexible(gas, 13, orig_falloff_high_A * 1.5)
        modify_reaction_A_flexible(gas, 31, orig_threebody_A * 1.5)
        
        # Verify elementary
        assert abs(gas.reaction(237).rate.pre_exponential_factor - 
                   orig_elem_A * 1.5) / (orig_elem_A * 1.5) < 1e-10
        
        # Verify three-body
        assert abs(gas.reaction(31).rate.pre_exponential_factor - 
                   orig_threebody_A * 1.5) / (orig_threebody_A * 1.5) < 1e-10
        
        # Verify falloff (both high-P and low-P)
        mod_falloff_rxn = gas.reaction(13)
        assert abs(mod_falloff_rxn.rate.high_rate.pre_exponential_factor - 
                   orig_falloff_high_A * 1.5) / (orig_falloff_high_A * 1.5) < 1e-10
        assert abs(mod_falloff_rxn.rate.low_rate.pre_exponential_factor - 
                   orig_falloff_low_A * 1.5) / (orig_falloff_low_A * 1.5) < 1e-10


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
