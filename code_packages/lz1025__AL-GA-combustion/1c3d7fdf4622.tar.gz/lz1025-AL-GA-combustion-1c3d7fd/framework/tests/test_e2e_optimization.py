"""
End-to-end test for MechanismWriter.write_optimized() functionality.

Tests:
1. Basic write functionality with temporary directory
2. Verify output mechanism can be loaded by Cantera
3. Verify output file format is correct
"""
import sys
import os
import tempfile
import pytest
import cantera as ct
import numpy as np
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.core.mechanism_writer import MechanismWriter


class TestMechanismWriterE2E:
    """End-to-end test suite for MechanismWriter.write_optimized()"""
    
    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for test outputs"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir
    
    @pytest.fixture
    def base_gas(self):
        """Create a fresh gas object for reference"""
        return ct.Solution("02-Reduced-Wang_fuel_2023.yaml")
    
    def test_write_optimized_basic(self, temp_dir, base_gas):
        """
        Test basic write_optimized() functionality.
        
        Verifies:
        1. Method returns a valid file path
        2. Output file exists
        3. Output file can be loaded by Cantera
        """
        # Select a few test reactions (elementary, falloff, three-body)
        reaction_indices = [10, 31, 237]
        
        # Get original logA values
        original_logA = []
        for idx in reaction_indices:
            rxn = base_gas.reaction(idx)
            if hasattr(rxn.rate, 'pre_exponential_factor'):
                A = rxn.rate.pre_exponential_factor
            elif hasattr(rxn.rate, 'high_rate'):
                A = rxn.rate.high_rate.pre_exponential_factor
            else:
                raise ValueError(f"Reaction {idx} has unsupported rate type")
            original_logA.append(np.log10(A))
        
        original_logA = np.array(original_logA)
        
        # Create perturbed logA values (±10% modification)
        perturbation = np.array([0.1, -0.05, 0.15])
        new_logA = original_logA + perturbation
        
        # Initialize writer and write optimized mechanism
        writer = MechanismWriter("02-Reduced-Wang_fuel_2023.yaml")
        output_path = writer.write_optimized(
            reaction_indices=reaction_indices,
            logA_values=new_logA,
            output_path=Path(temp_dir) / "optimized_test.yaml"
        )
        
        # Verify output file exists
        assert Path(output_path).exists(), f"Output file {output_path} should exist"
        
        # Verify output file can be loaded by Cantera
        optimized_gas = ct.Solution(output_path)
        assert optimized_gas is not None, "Should be able to load optimized mechanism"
        
        # Verify number of reactions matches
        assert optimized_gas.n_reactions == base_gas.n_reactions, \
            "Number of reactions should match original"
        
        # Verify number of species matches
        assert optimized_gas.n_species == base_gas.n_species, \
            "Number of species should match original"
    
    def test_write_optimized_verifies_A_values(self, temp_dir, base_gas):
        """
        Test that write_optimized() correctly writes A values.
        
        Verifies:
        1. Written A values match expected values within 1% tolerance
        2. Unmodified reactions remain unchanged
        """
        # Test with 5 reactions
        reaction_indices = [10, 13, 31, 171, 237]
        
        # Get original logA values
        original_logA = []
        for idx in reaction_indices:
            rxn = base_gas.reaction(idx)
            if hasattr(rxn.rate, 'pre_exponential_factor'):
                A = rxn.rate.pre_exponential_factor
            elif hasattr(rxn.rate, 'high_rate'):
                A = rxn.rate.high_rate.pre_exponential_factor
            else:
                raise ValueError(f"Reaction {idx} has unsupported rate type")
            original_logA.append(np.log10(A))
        
        original_logA = np.array(original_logA)
        
        # Apply specific perturbations
        perturbation = np.array([0.1, -0.1, 0.2, -0.05, 0.15])
        new_logA = original_logA + perturbation
        
        # Write optimized mechanism
        writer = MechanismWriter("02-Reduced-Wang_fuel_2023.yaml")
        output_path = writer.write_optimized(
            reaction_indices=reaction_indices,
            logA_values=new_logA,
            output_path=Path(temp_dir) / "optimized_verified.yaml"
        )
        
        # Load and verify
        optimized_gas = ct.Solution(output_path)
        
        for i, rxn_idx in enumerate(reaction_indices):
            expected_A = 10 ** new_logA[i]
            rxn = optimized_gas.reaction(rxn_idx)
            
            # Extract actual A value
            if hasattr(rxn.rate, 'pre_exponential_factor'):
                actual_A = rxn.rate.pre_exponential_factor
            elif hasattr(rxn.rate, 'high_rate'):
                actual_A = rxn.rate.high_rate.pre_exponential_factor
            else:
                raise ValueError(f"Reaction {rxn_idx} has unsupported rate type")
            
            # Verify within 1% tolerance (same as _verify_written_file)
            relative_error = abs(actual_A - expected_A) / expected_A
            assert relative_error < 0.01, \
                f"Reaction {rxn_idx}: Expected A={expected_A:.4e}, got A={actual_A:.4e} " \
                f"(error: {relative_error*100:.2f}%)"
    
    def test_write_optimized_metadata(self, temp_dir):
        """
        Test that write_optimized() prepares metadata (logged, not stored in YAML).
        
        Note: Cantera Solution objects don't support storing custom metadata in YAML.
        This test verifies that the method runs without error.
        """
        reaction_indices = [237]
        logA_values = np.array([np.log10(1.0e10)])
        
        custom_metadata = {
            'test_name': 'test_write_optimized_metadata',
            'custom_field': 'test_value'
        }
        
        writer = MechanismWriter("02-Reduced-Wang_fuel_2023.yaml")
        output_path = writer.write_optimized(
            reaction_indices=reaction_indices,
            logA_values=logA_values,
            output_path=Path(temp_dir) / "optimized_with_metadata.yaml",
            metadata=custom_metadata
        )
        
        # Verify file was created (metadata is logged, not stored)
        assert Path(output_path).exists(), "Output file should exist"
        
        # Verify it can be loaded
        gas = ct.Solution(output_path)
        assert gas is not None
    
    def test_write_optimized_auto_path(self, temp_dir):
        """
        Test write_optimized() with automatic path generation.
        
        Verifies:
        1. Method generates valid path when output_path is None
        2. Generated path includes timestamp
        """
        reaction_indices = [237]
        logA_values = np.array([np.log10(1.0e10)])
        
        # Use absolute path for mechanism file
        mechanism_path = os.path.abspath("02-Reduced-Wang_fuel_2023.yaml")
        
        writer = MechanismWriter(mechanism_path)
        output_path = writer.write_optimized(
            reaction_indices=reaction_indices,
            logA_values=logA_values,
            output_path=None  # Use auto-generated path
        )
        
        # Verify file was created
        assert Path(output_path).exists(), "Auto-generated path should exist"
        
        # Verify path includes timestamp pattern
        assert 'OPTIMIZED' in output_path, "Auto-generated path should include 'OPTIMIZED'"
        assert '.yaml' in output_path, "Auto-generated path should have .yaml extension"
    
    def test_write_optimized_invalid_input(self, temp_dir):
        """
        Test write_optimized() with invalid inputs.
        
        Verifies:
        1. Raises ValueError when reaction_indices and logA_values lengths mismatch
        """
        reaction_indices = [10, 20, 30]
        logA_values = np.array([10.0, 11.0])  # Mismatched length
        
        writer = MechanismWriter("02-Reduced-Wang_fuel_2023.yaml")
        
        with pytest.raises(ValueError) as excinfo:
            writer.write_optimized(
                reaction_indices=reaction_indices,
                logA_values=logA_values,
                output_path=Path(temp_dir) / "should_fail.yaml"
            )
        
        assert "不匹配" in str(excinfo.value) or "mismatch" in str(excinfo.value).lower()
    
    def test_optimized_mechanism_loadable(self, temp_dir, base_gas):
        """
        Integration test: Verify optimized mechanism can be used for calculations.
        
        Verifies:
        1. Optimized mechanism can compute thermo properties
        2. Optimized mechanism can access reaction rates
        """
        reaction_indices = [237]
        
        # Get original logA and apply perturbation
        rxn = base_gas.reaction(237)
        original_A = rxn.rate.pre_exponential_factor
        new_logA = np.array([np.log10(original_A * 1.5)])
        
        # Write optimized mechanism
        writer = MechanismWriter("02-Reduced-Wang_fuel_2023.yaml")
        output_path = writer.write_optimized(
            reaction_indices=reaction_indices,
            logA_values=new_logA,
            output_path=Path(temp_dir) / "optimized_for_calc.yaml"
        )
        
        # Load optimized mechanism
        optimized_gas = ct.Solution(output_path)
        
        # Set a test state
        T = 1000  # K
        P = 101325  # Pa
        X = 'H2:2, O2:1, N2:3.76'
        
        optimized_gas.TPX = T, P, X
        
        # Verify we can compute thermo properties
        assert optimized_gas.T > 0, "Temperature should be set"
        assert optimized_gas.P > 0, "Pressure should be set"
        assert optimized_gas.density > 0, "Density should be computable"
        
        # Verify we can access reaction rates (using creation_rates instead of reactant_rates)
        creation_rates = optimized_gas.creation_rates
        assert creation_rates is not None, "Should be able to compute creation rates"


class TestWriteOptimizedFunction:
    """Test the convenience function write_optimized_mechanism()"""
    
    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for test outputs"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir
    
    def test_convenience_function(self, temp_dir):
        """
        Test write_optimized_mechanism() convenience function.
        
        Verifies:
        1. Function works as expected
        2. Returns valid output path
        """
        from src.core.mechanism_writer import write_optimized_mechanism
        
        reaction_indices = [237]
        logA_values = np.array([np.log10(1.0e10)])
        
        output_path = write_optimized_mechanism(
            mechanism_path="02-Reduced-Wang_fuel_2023.yaml",
            reaction_indices=reaction_indices,
            logA_values=logA_values,
            output_path=Path(temp_dir) / "convenience_test.yaml"
        )
        
        assert Path(output_path).exists(), "Output file should exist"
        
        # Verify it can be loaded
        gas = ct.Solution(output_path)
        assert gas is not None, "Should be able to load mechanism"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
