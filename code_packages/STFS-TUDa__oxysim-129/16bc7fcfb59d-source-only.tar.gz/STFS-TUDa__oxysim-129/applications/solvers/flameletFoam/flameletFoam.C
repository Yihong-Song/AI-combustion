/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | www.openfoam.com
     \\/     M anipulation  |
-------------------------------------------------------------------------------
    Copyright (C) 2011-2017 OpenFOAM Foundation
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

Application
    flameletFoam

Group
    grpCombustionSolvers

Description
    Solver for reactive gas-phase simulations with tabulated chemistry.

\*---------------------------------------------------------------------------*/

#include "fvCFD.H"
// #include "dynamicFvMesh.H"
#include "multivariateScheme.H"
#include "pimpleControl.H"
#include "pressureControl.H"
#include "fvOptions.H"
#include "localEulerDdtScheme.H"
#include "fvcSmooth.H"

// Turbulence model
#include "turbulentFluidThermoModel.H"

// Flamelet specific classes from STFS
#include "flameletThermo.H"
#include "EquationHandler.H"

#include "benchmarkUtility.H"

#define FLOW
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

int main(int argc, char* argv[])
{
    argList::addNote(
        "Solver for combustion using tabulated chemistry.");

#include "postProcess.H"

#include "addCheckCaseOptions.H"
#include "setRootCaseLists.H"
#include "createTime.H"
#include "createMesh.H" // Replace with dynamicFvMesh, if AMR is implemented.
// #include "createDynamicFvMesh.H"
#include "createControl.H"
#include "createTimeControls.H"
#include "initContinuityErrs.H"
#include "createFields.H"
#include "createInputVariableEquations.H"
// Is this needed?
#include "createRhoUfIfPresent.H"

#include "readGravitationalAcceleration.H"

    turbulence->validate();

    // if (!LTS)
    //{
#include "compressibleCourantNo.H"
#include "setInitialDeltaT.H"
    //}


    // * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //


    Info << "\nStarting time loop\n"
         << endl;

    while (runTime.run())
    {
        timer.startBenchmark("TotalTimeStep");

#include "readTimeControls.H"

        // if (LTS)
        //{
        //     #include "setRDeltaT.H"
        // }
        // else
        //{
#include "compressibleCourantNo.H"
#include "setDeltaT.H"
        //}
        ++runTime;
        Info << "Time = " << runTime.timeName() << nl << endl;

#include "rhoEqn.H"

        // --- Pressure-velocity PIMPLE corrector loop
        while (pimple.loop())
        {
#include "UEqn.H"

            // Call update functions for flamelet
            timer.startBenchmark("LookupAndSolve");
            equationHandler.solve();
            timer.stopBenchmark("LookupAndSolve");

            timer.startBenchmark("ThermoUpdate");
            thermo.update();
            timer.stopBenchmark("ThermoUpdate");

            // --- Pressure corrector loop
            timer.startBenchmark("Pressure");
            while (pimple.correct())
            {
                if (lowMachPressure)
                {
                    // Default option.
                    // Recommended for tables with constant pressure.
#include "pdEqn.H"
                }
                else
                {
                    // Tables with non-constant pressure.
                    // Or as a different option for pressure correction.
#include "pcEqn.H"
                }
            }

            if (pimple.turbCorr())
            {
                rho = thermo.rho();
                timer.startBenchmark("Turbulence");
                turbulence->correct();
                timer.stopBenchmark("Turbulence");
            }
            timer.stopBenchmark("Pressure");
        }

        rho = thermo.rho();

        Info << "mag(U) min/max   = " << min(mag(U)).value() << ", " << max(mag(U)).value() << endl;
        Info << "p min/max   = " << min(p).value() << ", " << max(p).value() << endl;
        Info << "T gas min/max   = " << min(T).value() << ", " << max(T).value() << endl;
        Info << "rho min/max : " << min(rho).value() << " " << max(rho).value() << endl;

        if (runTime.write())
        {
            // Write additional fields if needed.
        }

        runTime.printExecutionTime(Info);

        timer.stopBenchmark("TotalTimeStep");
        timer.printAndResetBenchmark();
    }

    Info << "End\n"
         << endl;

    return 0;
}


// ************************************************************************* //
