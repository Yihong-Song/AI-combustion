python moons.py
