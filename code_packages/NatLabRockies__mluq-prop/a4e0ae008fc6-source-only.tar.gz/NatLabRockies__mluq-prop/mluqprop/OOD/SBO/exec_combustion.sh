python combustion.py
