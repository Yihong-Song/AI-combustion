# iCRNN - Integral Chemical Reaction Neural Networks

This is the code accompanying the paper https://arxiv.org/abs/2609.21715 
